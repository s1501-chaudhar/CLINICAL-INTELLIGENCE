from __future__ import annotations
"""
hybrid_retriever.py
===================
Approach 3: Hybrid retrieval combining BM25, vector search, Boolean filters,
synonym expansion, negation handling, and score fusion.

Pipeline:
  1. BM25 candidates (synonym-expanded)
  2. Vector candidates (semantic intent)
  3. Union pool → combined candidate set
  4. Hard Boolean AND filter on must_include
  5. Negation-aware exclusion filter on must_exclude
  6. Score fusion (0.4 BM25 + 0.4 vector + 0.2 Boolean)
  7. Sort by hybrid_score desc

This is the recommended production approach.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from query.negation_handler import apply_exclusion_filter, is_concept_negated
from indexing.bm25_indexer import BM25Indexer
from indexing.vector_indexer import VectorIndexer
from postprocess.score_fusion import fuse_scores, pool_results


class HybridRetriever:
    """
    Best-of-all-worlds retriever combining BM25, vector search, and Boolean filters.

    Strengths:
      - Synonym coverage from BM25 + semantic coverage from vectors
      - Hard Boolean AND/NOT constraints respected
      - Negation-aware exclusion (literal or clinical concept mode)
      - Explainable via individual score components

    Usage:
        retriever = HybridRetriever()
        results = retriever.retrieve(structured_query)
    """

    def __init__(self):
        self._bm25 = BM25Indexer()
        self._vector_notes = VectorIndexer("notes")
        self._vector_loaded = False

    def _ensure_vector_loaded(self) -> None:
        if not self._vector_loaded:
            try:
                self._vector_notes.load()
                self._vector_loaded = True
            except FileNotFoundError:
                # Vector index not built — gracefully degrade to BM25-only
                self._vector_loaded = False

    def retrieve(self, query: StructuredQuery) -> list[dict]:
        """
        Execute hybrid retrieval.

        Args:
            query: Fully parsed and expanded StructuredQuery

        Returns:
            Ranked list of note dicts with hybrid_score, bm25_score, vector_score,
            boolean_score, matched_synonyms.
        """
        # ── Step 1: BM25 candidates ───────────────────────────────────────────
        all_include_syns = query.all_include_synonyms
        if all_include_syns:
            bm25_candidates = self._bm25.search_notes(all_include_syns, top_k=300)
        else:
            # Pure semantic / free-text query — use the intent text as BM25 input
            intent_words = (query.semantic_intent or query.raw_query).split()
            bm25_candidates = self._bm25.search_notes(intent_words, top_k=200)

        # ── Step 2: Vector candidates ─────────────────────────────────────────
        self._ensure_vector_loaded()
        search_text = query.semantic_intent
        vector_candidates = (
            self._vector_notes.search(search_text, top_k=200)
            if self._vector_loaded and search_text
            else []
        )

        # ── Step 3: Union pool ────────────────────────────────────────────────
        pooled = pool_results(bm25_candidates, vector_candidates)

        if not pooled:
            return []

        # ── Step 4: Hard Boolean AND filter ──────────────────────────────────
        if query.must_include:
            pooled = [
                n for n in pooled
                if all(
                    cg.matches(n["text"]) and not is_concept_negated(n["text"], cg.synonyms)
                    for cg in query.must_include
                )
            ]

        # ── Step 4b: Soft OR filter ───────────────────────────────────────────
        if query.or_include:
            pooled = [
                n for n in pooled
                if any(
                    cg.matches(n["text"]) and not is_concept_negated(n["text"], cg.synonyms)
                    for cg in query.or_include
                )
            ]

        # ── Step 5: Exclusion / NOT filter ───────────────────────────────────
        if query.must_exclude:
            pooled, excluded = apply_exclusion_filter(
                pooled,
                query.must_exclude,
                mode=query.negation_mode,
            )

        # ── Step 6: Boolean score annotation ─────────────────────────────────
        pooled = self._annotate_boolean_score(pooled, query)

        # ── Step 7: Score fusion + sort ───────────────────────────────────────
        fused = fuse_scores(pooled)

        return fused[: query.top_k]

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _apply_include_filter(
        self, candidates: list[dict], query: StructuredQuery
    ) -> list[dict]:
        """Keep only notes where ALL must_include concept groups are present."""
        kept = []
        for note in candidates:
            text_lower = note["text"].lower()
            all_match = all(
                any(syn.lower() in text_lower for syn in cg.synonyms)
                for cg in query.must_include
            )
            if all_match:
                kept.append(note)
        return kept

    def _annotate_boolean_score(
        self, notes: list[dict], query: StructuredQuery
    ) -> list[dict]:
        """
        Compute per-note boolean_score, matched_synonyms, and matched_concepts_detail.
        AND groups: fraction matched. OR groups: 1.0 if any matched, 0 if none.
        """
        total_and = len(query.must_include)
        result = []
        for note in notes:
            text_lower = note.get("text", "").lower()
            matched_syns: list[str] = []
            matched_detail: list[dict] = []
            and_matched = 0

            for idx, cg in enumerate(query.must_include):
                hits = [s for s in cg.synonyms if s.lower() in text_lower]
                if hits:
                    and_matched += 1
                    for h in hits:
                        matched_syns.append(h)
                        matched_detail.append({"synonym": h, "concept": cg.canonical, "color_index": idx % 3})

            or_matched = 0
            for idx, cg in enumerate(query.or_include):
                hits = [s for s in cg.synonyms if s.lower() in text_lower]
                if hits:
                    or_matched += 1
                    for h in hits:
                        matched_syns.append(h)
                        matched_detail.append({"synonym": h, "concept": cg.canonical, "color_index": (total_and + idx) % 3})

            and_score = and_matched / total_and if total_and > 0 else 1.0
            or_score  = (1.0 if or_matched > 0 else 0.0) if query.or_include else 1.0
            bool_score = (and_score + or_score) / 2 if query.or_include else and_score

            note = dict(note)
            note["boolean_score"] = bool_score
            note["matched_synonyms"] = list(set(matched_syns))
            note["matched_concepts_detail"] = matched_detail
            result.append(note)
        return result
