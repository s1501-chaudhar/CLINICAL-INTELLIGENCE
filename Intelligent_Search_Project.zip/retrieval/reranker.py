from __future__ import annotations
"""
reranker.py
===========
Uses an LLM (via OpenRouter or OpenAI) to rerank the final candidate notes
based on relevance to the user's query.
"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from config.settings import OPENAI_API_KEY, OPENROUTER_API_KEY, USE_LLM_RERANKER

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None


class LLMReranker:
    def __init__(self):
        self.enabled = USE_LLM_RERANKER and OpenAI is not None
        self.client = None
        self.model = "openai/gpt-4o-mini"

        if self.enabled:
            if OPENROUTER_API_KEY:
                self.client = OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=OPENROUTER_API_KEY,
                )
            elif OPENAI_API_KEY:
                self.client = OpenAI(api_key=OPENAI_API_KEY)
                self.model = "gpt-4o-mini"

    def rerank(self, query: StructuredQuery, candidates: list[dict]) -> list[dict]:
        """
        Reranks the top candidates using an LLM.
        """
        if not self.enabled or not self.client or not candidates:
            return candidates

        # Limit to top 20 candidates to save tokens and time
        top_candidates = candidates[:20]
        remaining = candidates[20:]

        prompt = f"User Query: {query.raw_query}\n\n"
        prompt += "Please evaluate the following clinical notes for their relevance to the user's query.\n"
        prompt += "Score each note from 0.0 to 1.0, where 1.0 is highly relevant and matches all clinical intent, and 0.0 is completely irrelevant or negated.\n"
        prompt += "Return a JSON object with a 'scores' array, where each element is an object with 'note_id' and 'score' keys.\n\n"

        for i, note in enumerate(top_candidates):
            n_id = note.get('note_id', str(i))
            prompt += f"--- Note ID: {n_id} ---\n"
            prompt += f"{note['text']}\n\n"

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a clinical NLP assistant. Output ONLY valid JSON array."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"} if "gpt-4" in self.model else None,
            )
            
            result_text = response.choices[0].message.content.strip()
            
            # If not using response_format, we might need to strip markdown
            if result_text.startswith("```json"):
                result_text = result_text[7:-3].strip()

            parsed_json = json.loads(result_text)
            scores_list = parsed_json.get("scores", [])
            
            # Create a lookup mapping note_id -> score
            score_map = {str(item.get("note_id", item.get("id"))): float(item["score"]) for item in scores_list if ("note_id" in item or "id" in item) and "score" in item}

            # Apply scores
            for i, note in enumerate(top_candidates):
                n_id = str(note.get("note_id", str(i)))
                llm_score = score_map.get(n_id, 0.5)
                # Blend the LLM score with the existing hybrid score (or just use LLM score)
                original_score = note.get("hybrid_score", note.get("boolean_score", 0.0))
                note["hybrid_score"] = (original_score * 0.3) + (llm_score * 0.7)
                note["llm_score"] = llm_score

            # Re-sort the top candidates
            top_candidates.sort(key=lambda x: x.get("hybrid_score", 0.0), reverse=True)

        except Exception as e:
            print(f"LLM Reranking failed: {e}", file=sys.stderr)
            # If it fails, just return original sorted candidates

        return top_candidates + remaining


class CrossEncoderReranker:
    def __init__(self):
        from config.settings import USE_CROSS_ENCODER, CROSS_ENCODER_MODEL
        self.enabled = USE_CROSS_ENCODER
        self.model = None
        
        if self.enabled:
            try:
                from sentence_transformers import CrossEncoder
                # By default uses cpu if gpu not available
                self.model = CrossEncoder(CROSS_ENCODER_MODEL)
            except Exception as e:
                print(f"Failed to load CrossEncoder: {e}", file=sys.stderr)
                self.enabled = False
                
    def rerank(self, query: StructuredQuery, candidates: list[dict]) -> list[dict]:
        """
        Reranks the top candidates using a local Cross-Encoder.
        """
        if not self.enabled or not self.model or not candidates:
            return candidates

        # Limit to top 20 candidates to keep it fast
        top_candidates = candidates[:20]
        remaining = candidates[20:]

        pairs = [[query.raw_query, note['text']] for note in top_candidates]

        try:
            import math
            scores = self.model.predict(pairs)
            
            # Apply scores
            for i, note in enumerate(top_candidates):
                raw_score = float(scores[i])
                # Normalize raw logits to 0-1 using sigmoid for easier blending
                try:
                    normalized_score = 1.0 / (1.0 + math.exp(-raw_score))
                except OverflowError:
                    normalized_score = 0.0 if raw_score < 0 else 1.0
                
                # Blend the Cross-Encoder score with the existing hybrid score
                original_score = note.get("hybrid_score", note.get("boolean_score", 0.0))
                note["hybrid_score"] = (original_score * 0.3) + (normalized_score * 0.7)
                note["cross_encoder_score"] = normalized_score

            # Re-sort the top candidates
            top_candidates.sort(key=lambda x: x.get("hybrid_score", 0.0), reverse=True)

        except Exception as e:
            print(f"Cross-Encoder Reranking failed: {e}", file=sys.stderr)

        return top_candidates + remaining

