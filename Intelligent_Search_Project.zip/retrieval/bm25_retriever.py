from __future__ import annotations
"""
bm25_retriever.py
=================
Approach 1: Pure Keyword Retrieval (BM25)

Strictly lexical search using the user's raw query terms. 
Does NOT use semantic search, synonym expansion, or Boolean filters.
Used primarily to demonstrate baseline keyword search capabilities.
"""

import sys
import re
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.bm25_indexer import BM25Indexer


class BM25Retriever:
    """
    Pure BM25 keyword retrieval.
    Strictly lexical, ignoring synonyms and semantic intent.
    """

    def __init__(self):
        self._bm25 = BM25Indexer()

    def retrieve(self, query: StructuredQuery) -> list[dict]:
        """
        Execute strict lexical BM25 retrieval.
        
        Args:
            query: Parsed StructuredQuery (we only use raw_query here)
            
        Returns:
            Ranked list of note dicts.
        """
        # Strip out explicit boolean operators to get just the raw keywords
        clean_query = re.sub(r'\b(AND|OR|NOT)\b', ' ', query.raw_query, flags=re.IGNORECASE)
        raw_terms = [t for t in clean_query.split() if t.strip()]
        
        if not raw_terms:
            return []
            
        # We use search_notes to ensure all fields (diagnoses, etc.) are returned
        raw_notes = self._bm25.search_notes(raw_terms, top_k=query.top_k)
        
        notes = []
        for n in raw_notes:
            notes.append({
                **n,
                "vector_score": 0,
                "boolean_score": 0,
                "hybrid_score": n.get("bm25_score", 0),
                "score": n.get("bm25_score", 0),
                "why_matched": "Strict Keyword Match",
                "highlighted_evidence": [n.get("text", "")[:200]]
            })
            
        return notes
