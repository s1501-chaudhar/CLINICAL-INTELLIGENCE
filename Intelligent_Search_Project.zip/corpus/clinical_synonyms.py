from __future__ import annotations
"""
clinical_synonyms.py
====================
Master clinical synonym dictionary for the Intelligent Search PoC.

Structure:
    CLINICAL_SYNONYMS: dict[str, list[str]]
        Maps a canonical concept name → list of all known synonyms,
        abbreviations, drug brand names, and clinical equivalents.

Usage:
    from corpus.clinical_synonyms import CLINICAL_SYNONYMS, expand_concept

    synonyms = expand_concept("pneumonia")
    # ["pneumonia", "CAP", "community acquired pneumonia", "LRTI", ...]
"""

# =============================================================================
# CLINICAL SYNONYM DICTIONARY
# =============================================================================

CLINICAL_SYNONYMS: dict[str, list[str]] = {

    # -------------------------------------------------------------------------
    # RESPIRATORY CONDITIONS
    # -------------------------------------------------------------------------
    "pneumonia": [
        "pneumonia", "CAP", "community acquired pneumonia",
        "community-acquired pneumonia", "LRTI",
        "lower respiratory tract infection", "chest infection",
        "pulmonary consolidation", "consolidation", "lobar pneumonia",
        "bronchopneumonia", "atypical pneumonia", "HAP",
        "hospital acquired pneumonia", "ventilator-associated pneumonia", "VAP",
        "bronchitis", "respiratory infection",
    ],
    "asthma": [
        "asthma", "bronchial asthma", "reactive airway disease",
        "wheezing", "bronchospasm", "asthmatic",
    ],
    "COPD": [
        "COPD", "chronic obstructive pulmonary disease",
        "emphysema", "chronic bronchitis", "obstructive lung disease",
        "COAD", "chronic airflow obstruction",
    ],
    "pulmonary_embolism": [
        "pulmonary embolism", "PE", "pulmonary thromboembolism",
        "lung clot", "DVT with PE",
    ],
    "pleural_effusion": [
        "pleural effusion", "hydrothorax", "fluid in chest",
        "pleural fluid", "exudative effusion", "transudative effusion",
    ],

    # -------------------------------------------------------------------------
    # CARDIOVASCULAR CONDITIONS
    # -------------------------------------------------------------------------
    "myocardial_infarction": [
        "myocardial infarction", "MI", "heart attack", "STEMI",
        "NSTEMI", "acute coronary syndrome", "ACS", "cardiac event",
        "ischemic heart disease", "IHD",
    ],
    "hypertension": [
        "hypertension", "HTN", "high blood pressure", "elevated BP",
        "hypertensive", "BP elevation", "raised blood pressure",
    ],
    "heart_failure": [
        "heart failure", "HF", "cardiac failure", "congestive heart failure",
        "CHF", "decompensated heart failure", "LVF",
        "left ventricular failure", "biventricular failure",
    ],
    "arrhythmia": [
        "arrhythmia", "AF", "atrial fibrillation", "atrial flutter",
        "tachycardia", "bradycardia", "palpitations", "irregular heartbeat",
        "SVT", "supraventricular tachycardia", "VT", "ventricular tachycardia",
    ],

    # -------------------------------------------------------------------------
    # DERMATOLOGICAL CONDITIONS & SYMPTOMS
    # -------------------------------------------------------------------------
    "blister": [
        "blister", "vesicle", "bullae", "bulla", "bullous",
        "bullous lesion", "skin blister", "fluid-filled lesion",
        "vesicular rash", "vesicular lesion", "blistering rash",
        "pemphigus", "pemphigoid", "epidermolysis",
    ],
    "rash": [
        "rash", "dermatitis", "skin eruption", "exanthem",
        "erythema", "urticaria", "hives", "maculopapular rash",
        "erythematous rash", "skin lesion",
    ],
    "wound": [
        "wound", "ulcer", "sore", "laceration", "abrasion",
        "pressure ulcer", "bedsore", "decubitus ulcer",
    ],

    # -------------------------------------------------------------------------
    # ONCOLOGY
    # -------------------------------------------------------------------------
    "cancer": [
        "cancer", "malignancy", "tumor", "tumour", "carcinoma",
        "neoplasm", "neoplasia", "sarcoma", "lymphoma", "leukemia",
        "leukaemia", "oncology", "metastasis", "metastatic",
        "malignant", "adenocarcinoma", "squamous cell carcinoma",
    ],
    "chemotherapy": [
        "chemotherapy", "chemo", "cytotoxic therapy",
        "antineoplastic therapy", "oncotherapy",
    ],

    # -------------------------------------------------------------------------
    # RENAL CONDITIONS
    # -------------------------------------------------------------------------
    "renal_failure": [
        "renal failure", "kidney failure", "AKI",
        "acute kidney injury", "CKD", "chronic kidney disease",
        "acute renal failure", "ARF", "end-stage renal disease", "ESRD",
        "nephropathy", "renal impairment", "reduced GFR",
        "elevated creatinine", "azotemia",
    ],
    "diabetes": [
        "diabetes", "DM", "T2DM", "T1DM", "type 2 diabetes",
        "type 1 diabetes", "diabetes mellitus", "hyperglycaemia",
        "hyperglycemia", "diabetic", "pre-diabetes", "NIDDM", "IDDM",
    ],

    # -------------------------------------------------------------------------
    # NEUROLOGICAL CONDITIONS
    # -------------------------------------------------------------------------
    "stroke": [
        "stroke", "CVA", "cerebrovascular accident", "TIA",
        "transient ischemic attack", "brain attack", "ischemic stroke",
        "haemorrhagic stroke", "hemorrhagic stroke", "TACS", "PACS",
    ],
    "seizure": [
        "seizure", "epilepsy", "convulsion", "fit", "tonic-clonic",
        "absence seizure", "focal seizure", "status epilepticus",
    ],

    # -------------------------------------------------------------------------
    # GASTROINTESTINAL CONDITIONS
    # -------------------------------------------------------------------------
    "GI_bleed": [
        "GI bleed", "gastrointestinal bleeding", "GI hemorrhage",
        "hematemesis", "haematemesis", "melena", "melaena",
        "rectal bleeding", "hematochezia", "upper GI bleed",
    ],
    "appendicitis": [
        "appendicitis", "acute abdomen", "right iliac fossa pain",
        "RIF pain", "inflamed appendix",
    ],

    # -------------------------------------------------------------------------
    # MEDICATIONS — ANALGESICS / NSAIDS
    # -------------------------------------------------------------------------
    "ibuprofen": [
        "ibuprofen", "Advil", "Brufen", "NSAID",
        "Nurofen", "Motrin", "non-steroidal anti-inflammatory",
        "anti-inflammatory", "nonsteroidal",
    ],
    "paracetamol": [
        "paracetamol", "acetaminophen", "Tylenol", "Calpol",
        "Panadol", "Dolo", "panadeine", "paracetamol-codeine",
    ],
    "aspirin": [
        "aspirin", "ASA", "acetylsalicylic acid",
        "low-dose aspirin", "Disprin", "Ecotrin",
    ],
    "morphine": [
        "morphine", "opioid", "opiate", "MST", "oramorph",
        "codeine", "tramadol", "fentanyl", "oxycodone", "hydrocodone",
    ],

    # -------------------------------------------------------------------------
    # MEDICATIONS — ANTIBIOTICS
    # -------------------------------------------------------------------------
    "amoxicillin": [
        "amoxicillin", "amoxycillin", "Amoxil", "co-amoxiclav",
        "Augmentin", "penicillin", "amoxicillin-clavulanate",
    ],
    "doxycycline": [
        "doxycycline", "Vibramycin", "tetracycline", "minocycline",
    ],

    # -------------------------------------------------------------------------
    # MEDICATIONS — CARDIAC
    # -------------------------------------------------------------------------
    "metformin": [
        "metformin", "Glucophage", "biguanide", "Fortamet",
    ],
    "atorvastatin": [
        "atorvastatin", "Lipitor", "statin", "rosuvastatin",
        "simvastatin", "Crestor", "pravastatin",
    ],

    # -------------------------------------------------------------------------
    # SYMPTOMS / FINDINGS
    # -------------------------------------------------------------------------
    "fever": [
        "fever", "pyrexia", "febrile", "temperature", "hyperthermia",
        "elevated temperature", "high temperature",
    ],
    "dyspnea": [
        "dyspnea", "dyspnoea", "shortness of breath", "SOB",
        "breathlessness", "difficulty breathing", "respiratory distress",
    ],
    "chest_pain": [
        "chest pain", "chest tightness", "chest discomfort",
        "retrosternal pain", "pleuritic pain", "angina",
    ],
    "edema": [
        "edema", "oedema", "swelling", "pitting edema",
        "peripheral oedema", "bilateral leg swelling", "ankle swelling",
    ],
    "nausea": [
        "nausea", "vomiting", "nausea and vomiting", "N&V",
        "emesis", "retching", "vomitted",
    ],
}

# =============================================================================
# NEGATION CUES
# Used by negation_handler.py to detect negated clinical concepts
# =============================================================================

NEGATION_CUES: list[str] = [
    "no", "not", "denies", "without", "absent", "ruled out",
    "negative for", "no evidence of", "no history of", "never had",
    "no known", "no prior", "non-", "unremarkable for", "free of",
    "does not have", "did not have", "has not had", "had no",
]


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def expand_concept(concept: str) -> list[str]:
    """
    Returns the synonym list for a given canonical concept name.
    Falls back to a single-item list with the concept itself if not found.

    Args:
        concept: Canonical concept name (e.g., "pneumonia", "ibuprofen")

    Returns:
        List of synonyms including the concept itself.
    """
    # Direct match
    if concept.lower() in CLINICAL_SYNONYMS:
        return CLINICAL_SYNONYMS[concept.lower()]

    # Fuzzy match: check if concept appears in any synonym list
    for canonical, synonyms in CLINICAL_SYNONYMS.items():
        if concept.lower() in [s.lower() for s in synonyms]:
            return synonyms

    # Fallback: return just the concept
    return [concept]


def get_all_synonyms_flat() -> list[str]:
    """Returns all synonyms across all concepts as a flat list."""
    return [syn for synonyms in CLINICAL_SYNONYMS.values() for syn in synonyms]


def find_concept_for_synonym(synonym: str):
    """Given a synonym, return the canonical concept name."""
    for canonical, synonyms in CLINICAL_SYNONYMS.items():
        if synonym.lower() in [s.lower() for s in synonyms]:
            return canonical
    return None


if __name__ == "__main__":
    # Quick test
    print("Pneumonia synonyms:", expand_concept("pneumonia"))
    print("Ibuprofen synonyms:", expand_concept("ibuprofen"))
    print("Advil canonical:", find_concept_for_synonym("Advil"))
    print("Total concepts:", len(CLINICAL_SYNONYMS))
    print("Total synonyms:", len(get_all_synonyms_flat()))
