import json
import random

f = 'd:\\Jayesh\\Intelligent_Search_Final_v2\\data\\raw\\clinical_notes\\notes.json'
with open(f, 'r') as file:
    data = json.load(file)

used = set()
for n in data:
    while True:
        new_id = f"N-{random.randint(100, 999):03d}"
        if new_id not in used:
            used.add(new_id)
            n['note_id'] = new_id
            break

with open(f, 'w') as file:
    json.dump(data, file, indent=4)
print("Updated note IDs successfully!")
