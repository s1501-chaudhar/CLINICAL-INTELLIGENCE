# 🎤 Presentation Split: 3-Person Handoff Guide

Since there are 3 of you presenting, the most professional and logical way to divide this project is to split it into the **Three Core Stages of a Search Engine**. This way, each person becomes an expert on a specific slice of the pie, and you can seamlessly hand the microphone to the next person as the query flows through the system.

Here is exactly how you should divide the project, what each person needs to learn, and which files they own.

---

## 🗣️ Speaker 1: The "Interpreter" (Query Parsing & NLP)
**Your Job:** Explain how the system understands what the doctor actually typed before it ever touches a database. 

**Your Story:** "Doctors don't speak in code. They type messy, natural language sentences like *'patient having severe pneumonia but not cancer'*. My part of the engine is responsible for reading that sentence, throwing away filler words, expanding medical synonyms, and translating it into a highly structured mathematical contract that the databases can understand."

**Files You Must Understand:**
1.  **`query/query_parser.py`:** You need to understand how the Regex works to strip out "stop words" (like the words *patient* and *having*), and how it groups words into `must_include` and `must_exclude` buckets.
2.  **`query/synonym_expander.py`:** You need to explain the Vocabulary Mismatch problem (e.g. Heart Attack vs Myocardial Infarction) and how this script fixes it.
3.  **`api/routes/search.py`:** You briefly explain how this is the FastAPI entry point that catches the text from the browser.

---

## 🗣️ Speaker 2: The "Engines" (Databases & Search Algorithms)
**Your Job:** Explain the two completely different databases we built, how they are indexed, and the two algorithms (Keyword vs AI) used to search them.

**Your Story:** "Once Speaker 1 translates the query, we have to actually search the millions of medical records. But we don't just do one search, we do two simultaneous searches using two radically different technologies: The Lexical Engine and The Semantic Engine."

**Files You Must Understand:**
1.  **`indexing/bm25_indexer.py` & `retrieval/bm25_retriever.py`:** You must explain **Whoosh** (our local lexical database) and the **BM25 algorithm**. Explain why we use BM25 instead of simple counting (BoW) because BM25 has "term saturation" so long documents can't cheat the score.
2.  **`indexing/vector_indexer.py` & `retrieval/semantic_retriever.py`:** You must explain the AI. Explain **Sentence-Transformers**, how it turns sentences into 384-dimensional vectors (arrays of numbers), and how we use **FAISS** (Facebook AI Similarity Search) to calculate the geometric distance between the query vector and the note vectors. Mention privacy (why we run it locally instead of using OpenAI).

---

## 🗣️ Speaker 3: The "Judge" (Hybrid Merge, Safety, & UI)
**Your Job:** Explain how we take two completely different lists of results, enforce strict medical safety rules, mathematically merge them, and send them to the screen.

**Your Story:** "Speaker 2 just gave me two lists of top candidates: one from the keyword engine, and one from the AI engine. My job is to merge them into a single perfect list. But first, I have to fix the AI's mistakes. AI is notoriously bad at the word 'NOT'. If you search 'NOT cancer', the AI will return cancer documents. I have to enforce strict medical safety, delete hallucinated documents, score them fairly, and light up the UI."

**Files You Must Understand:**
1.  **`retrieval/hybrid_retriever.py` & `query/negation_handler.py`:** Explain how you pool the results together, and then run a strict "Hard Boolean AND/NOT" filter to delete any document that violates the doctor's explicit instructions, acting as an AI safety net.
2.  **`postprocess/score_fusion.py`:** You must explain **Reciprocal Rank Fusion (RRF)**. Explain why you cannot simply add a BM25 score (e.g., `15.5`) to an AI vector score (e.g., `0.85`). Explain how RRF fixes this by ignoring the raw scores and only looking at the *Leaderboard Rank* (1st place, 2nd place, etc.).
3.  **`postprocess/evidence_extractor.py` & UI:** Explain how your Python code wraps the matching words in hidden tags, and how the Javascript (`app.js`) catches those tags and turns them green/blue on the doctor's screen so they know *why* the AI picked that note.

---

### 💡 Presentation Tip
During the presentation, use this handoff script:
*   *(Speaker 1 finishes)*: "...and now that we have a perfectly structured query, I will hand it over to [Speaker 2] to explain how we actually search the clinical databases."
*   *(Speaker 2 finishes)*: "...so now we have our top BM25 candidates and our top Vector candidates. I will pass it to [Speaker 3] to explain how we merge them, filter out the AI hallucinations, and show them to the user."
