# 🏥 Intelligent Search across Clinical Notes and Medical Research

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.111-green.svg)](https://fastapi.tiangolo.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A hybrid clinical search assistant that lets doctors query **synthetic clinical notes** and **medical research abstracts** using Boolean logic, clinical synonym expansion, semantic embeddings, and negation-aware filtering.

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m nltk.downloader punkt
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env if you want to change the embedding model or add an OpenAI key
```

### 3. Build indexes
```bash
python indexing/hybrid_indexer.py --build-all
```

### 4. Run the API

```bash
uvicorn api.main:app --reload --port 8000
```

### 5. Open the Dashboard

Navigate to `http://localhost:8000` in your browser.

---

## 🏗️ Architecture

```
Doctor Query → Query Parser → Synonym Expander
                                    ↓
                    ┌─────────────────────────────────┐
                    │  BM25 (Whoosh) + FAISS Vectors  │
                    └──────────────┬──────────────────┘
                                   ↓
                    Boolean Filters + Negation Handler
                                   ↓
                    Score Fusion (0.4 BM25 + 0.4 Vec + 0.2 Bool)
                                   ↓
                    Reranker + Evidence Extractor
                                   ↓
                    Notes Results + Research Results
```

---

## 🔍 Supported Query Types

| Query | Type | Example |
|---|---|---|
| Boolean AND | `pneumonia AND ibuprofen` | Keyword + synonym |
| Boolean NOT | `blister NOT cancer` | Exclusion filter |
| Semantic | `patients with respiratory infection using painkillers` | Meaning-based |
| Natural language | `notes that do not contain cancer but contain blister` | NL → structured |

---

## 📂 Project Structure

```
Intelligent_Search/
├── corpus/           # Clinical synonym dictionary
├── data/             # Raw and processed data
├── indexing/         # BM25 and FAISS index builders
├── query/            # Query parser, synonym expander, negation handler
├── retrieval/        # Boolean, semantic, and hybrid retrievers
├── postprocess/      # Score fusion, evidence extraction, formatting
├── research/         # Research abstract retrieval
├── evaluation/       # Metrics: Precision@k, Recall, MRR, Boolean accuracy
├── api/              # FastAPI backend
├── ui/               # Search dashboard (HTML/CSS/JS)
└── config/           # Settings and logging
```

---

## 🧪 Evaluation

```bash
python evaluation/test_runner.py
```

Target metrics (Hybrid approach):
- **Precision@5** > 0.85
- **Boolean accuracy** > 0.95
- **Synonym recall** > 0.85
- **Negation accuracy** > 0.90

---

## 📚 Detailed Documentation

See [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) for the complete architecture, component deep-dives, evaluation framework, and implementation roadmap.

---

## ⚙️ Configuration

All parameters are configurable via `.env`:

| Variable | Default | Description |
|---|---|---|
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | Embedding model for semantic search |
| `DEFAULT_APPROACH` | `hybrid` | Search approach: boolean / semantic / hybrid |
| `DEFAULT_NEGATION_MODE` | `clinical_concept` | Negation mode: literal / clinical_concept |
| `BM25_WEIGHT` | `0.40` | Weight for BM25 score in hybrid fusion |
| `VECTOR_WEIGHT` | `0.40` | Weight for vector similarity in hybrid fusion |
| `NUM_CLINICAL_NOTES` | `1500` | Notes to generate |

---

*Built as part of the Intelligent Search PoC — Hospitals AI Hackathon*
