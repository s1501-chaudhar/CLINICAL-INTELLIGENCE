from __future__ import annotations
"""
hybrid_indexer.py
=================
Orchestrates building both BM25 and FAISS indexes in one command.

Usage:
    python indexing/hybrid_indexer.py --build-all
    python indexing/hybrid_indexer.py --build-all --skip-vector  # BM25 only
    python indexing/hybrid_indexer.py --status
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from indexing.bm25_indexer import BM25Indexer
from indexing.vector_indexer import VectorIndexer


def build_all(skip_vector: bool = False) -> None:
    print("=" * 60)
    print("  Intelligent Search — Index Builder")
    print("=" * 60)

    # BM25 indexes
    print("\n[1/4] Building BM25 notes index...")
    bm25 = BM25Indexer()
    bm25.build_notes_index()

    print("\n[2/4] Building BM25 research index...")
    bm25.build_research_index()

    if not skip_vector:
        # FAISS indexes
        print("\n[3/4] Building FAISS notes vector index...")
        VectorIndexer("notes").build()

        print("\n[4/4] Building FAISS research vector index...")
        VectorIndexer("research").build()
    else:
        print("\n[3/4] Skipping FAISS notes index (--skip-vector)")
        print("[4/4] Skipping FAISS research index (--skip-vector)")

    print("\n" + "=" * 60)
    print("✅ All indexes built successfully!")
    print("=" * 60)


def print_status() -> None:
    bm25 = BM25Indexer()
    notes_vi = VectorIndexer("notes")
    research_vi = VectorIndexer("research")

    print("\n📊 Index Status:")
    print(f"  BM25 Notes     : {'✅ exists' if bm25.index_exists('notes') else '❌ not built'}")
    print(f"  BM25 Research  : {'✅ exists' if bm25.index_exists('research') else '❌ not built'}")
    print(f"  FAISS Notes    : {'✅ exists' if notes_vi.index_exists() else '❌ not built'}")
    print(f"  FAISS Research : {'✅ exists' if research_vi.index_exists() else '❌ not built'}")


def main():
    parser = argparse.ArgumentParser(description="Build all search indexes")
    parser.add_argument("--build-all", action="store_true", help="Build all indexes")
    parser.add_argument("--skip-vector", action="store_true",
                        help="Skip FAISS vector index build (BM25 only)")
    parser.add_argument("--status", action="store_true", help="Show index status")
    args = parser.parse_args()

    if args.status:
        print_status()
    elif args.build_all:
        build_all(skip_vector=args.skip_vector)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
