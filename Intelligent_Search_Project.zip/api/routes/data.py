import json
from pathlib import Path
from fastapi import APIRouter

router = APIRouter()

DATA_DIR = Path(__file__).parent.parent.parent / "data" / "raw"
NOTES_FILE = DATA_DIR / "clinical_notes" / "notes.json"
ABSTRACTS_FILE = DATA_DIR / "research_abstracts" / "abstracts.json"

@router.get("/stats")
def get_stats():
    with open(NOTES_FILE, "r") as f:
        notes = json.load(f)
    with open(ABSTRACTS_FILE, "r") as f:
        abstracts = json.load(f)
    
    counts = {}
    for n in notes:
        counts[n["note_type"]] = counts.get(n["note_type"], 0) + 1
        
    return {
        "notes": counts,
        "research": len(abstracts)
    }

@router.get("/notes")
def get_notes(type: str, limit: int = 20):
    with open(NOTES_FILE, "r") as f:
        notes = json.load(f)
    filtered = [n for n in notes if n["note_type"].lower() == type.lower()]
    return filtered[:limit]

@router.get("/research")
def get_research(limit: int = 20):
    with open(ABSTRACTS_FILE, "r") as f:
        abstracts = json.load(f)
    return abstracts[:limit]
