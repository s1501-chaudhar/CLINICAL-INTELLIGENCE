from __future__ import annotations
"""
negation_handler.py
===================
Detects and handles negated clinical concepts in note text.

Two modes are supported:

  LITERAL:
      Any note containing a synonym of the excluded concept is excluded,
      regardless of grammatical context. Fast but may exclude "no cancer" notes.

  CLINICAL_CONCEPT:
      A note is only excluded if the concept is present AND is NOT preceded by
      a negation cue within a configurable word window. This retains notes
      where the concept is explicitly denied ("no history of cancer").
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from corpus.clinical_synonyms import NEGATION_CUES
from query.structured_query import ConceptGroup, NegationMode

# Window of words AFTER a negation cue to check for the concept
DEFAULT_NEGATION_WINDOW = 6


def _sentence_tokenize(text: str) -> list[str]:
    """Simple sentence splitter (avoids NLTK dependency at import time)."""
    return re.split(r'(?<=[.!?])\s+', text)


def is_negated_in_sentence(sentence: str, concept_term: str, window: int = DEFAULT_NEGATION_WINDOW) -> bool:
    """
    Check if a clinical term is negated within a single sentence.

    Algorithm:
        1. Tokenise sentence into words
        2. Find positions of negation cues
        3. For each cue, check if concept_term appears within `window` words after it
        4. If yes → negated; if no → present

    Args:
        sentence:     A single sentence from a clinical note
        concept_term: The synonym to check (e.g., "cancer", "malignancy")
        window:       Number of tokens after negation cue to search

    Returns:
        True if the term is negated in this sentence, False otherwise
    """
    sentence_lower = sentence.lower()
    term_lower = concept_term.lower()

    if term_lower not in sentence_lower:
        return False  # term not in sentence at all

    # Check multi-word negation cues first (e.g., "no evidence of", "no history of")
    sorted_cues = sorted(NEGATION_CUES, key=len, reverse=True)

    for cue in sorted_cues:
        # Use word boundaries around the cue to prevent substring matches (e.g. 'no' inside 'diagnosed')
        # If the cue ends in a non-word char (like '-'), don't enforce trailing \b
        cue_regex = r'\b' + re.escape(cue.lower()) + (r'\b' if cue[-1].isalnum() else '')
        for match in re.finditer(cue_regex, sentence_lower):
            cue_end = match.end()
            # Take the slice of text from after the cue to window words
            remaining = sentence_lower[cue_end:].strip()
            # Count words to enforce window
            window_text = " ".join(remaining.split()[:window])
            if term_lower in window_text:
                return True

    return False


def is_concept_negated(text: str, synonyms: list[str], window: int = DEFAULT_NEGATION_WINDOW) -> bool:
    """
    Check if ALL occurrences of any synonym in the text are negated.

    Returns True (negated = safe to include) only if every occurrence of
    every matching synonym is preceded by a negation cue.
    Returns False if any occurrence is present without negation.

    Args:
        text:     Full note text
        synonyms: List of synonyms to check (from ConceptGroup)
        window:   Negation window in words

    Returns:
        True  → concept is negated throughout (note may be kept in clinical mode)
        False → concept is actively present (note should be excluded)
    """
    sentences = _sentence_tokenize(text)

    for sentence in sentences:
        sentence_lower = sentence.lower()
        for syn in synonyms:
            if syn.lower() in sentence_lower:
                # Found a matching synonym — check if it's negated
                if not is_negated_in_sentence(sentence, syn, window):
                    return False  # concept is present and NOT negated

    return True  # no active (non-negated) occurrence found


# ── Main filter function ─────────────────────────────────────────────────────

def apply_exclusion_filter(
    notes: list[dict],
    excluded_concepts: list[ConceptGroup],
    mode: NegationMode = NegationMode.CLINICAL_CONCEPT,
    window: int = DEFAULT_NEGATION_WINDOW,
) -> tuple[list[dict], list[dict]]:
    """
    Filter notes based on excluded concept groups.

    Args:
        notes:             List of note dicts with a "text" field
        excluded_concepts: ConceptGroups that should trigger exclusion
        mode:              LITERAL or CLINICAL_CONCEPT
        window:            Negation window (clinical_concept mode only)

    Returns:
        (kept_notes, excluded_notes) tuple
    """
    if not excluded_concepts:
        return notes, []

    kept: list[dict] = []
    excluded: list[dict] = []

    for note in notes:
        text = note.get("text", "")
        should_exclude = False
        exclude_reason = ""

        for concept in excluded_concepts:
            text_lower = text.lower()

            # Check if any synonym appears at all
            matching_syns = [s for s in concept.synonyms if s.lower() in text_lower]
            if not matching_syns:
                continue  # concept not mentioned → safe

            if mode == NegationMode.LITERAL:
                # Literal: any mention → exclude
                should_exclude = True
                exclude_reason = (
                    f"Literal mode: '{matching_syns[0]}' found for excluded concept '{concept.canonical}'"
                )
                break

            elif mode == NegationMode.CLINICAL_CONCEPT:
                # Clinical concept: only exclude if concept is NOT negated
                all_negated = is_concept_negated(text, matching_syns, window)
                if not all_negated:
                    should_exclude = True
                    exclude_reason = (
                        f"Clinical concept mode: '{concept.canonical}' is actively present "
                        f"(not negated) via '{matching_syns[0]}'"
                    )
                    break
                # else: negated → keep note

        if should_exclude:
            note = dict(note)  # don't mutate original
            note["_exclude_reason"] = exclude_reason
            excluded.append(note)
        else:
            kept.append(note)

    return kept, excluded


# ── Quick test ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    test_cases = [
        ("Blister over left foot. No history of cancer.", ["cancer", "malignancy"], True),
        ("History of lung cancer with blistering rash.", ["cancer", "malignancy"], False),
        ("No evidence of carcinoma on biopsy.", ["cancer", "carcinoma"], True),
        ("Known malignancy. Admitted for chemotherapy.", ["cancer", "malignancy"], False),
        ("Patient denies cancer. Blister on arm.", ["cancer"], True),
    ]

    print("Negation Detection Tests:")
    print("-" * 70)
    for text, syns, expected_negated in test_cases:
        result = is_concept_negated(text, syns)
        status = "✅" if result == expected_negated else "❌"
        print(f"{status} negated={result} (expected={expected_negated})")
        print(f"   Text: {text[:80]}")
        print()
