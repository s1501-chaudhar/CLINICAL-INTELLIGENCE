from __future__ import annotations
"""
synonym_expander.py
===================
Expands a raw concept term into a ConceptGroup with all clinical synonyms.

Strategy:
  1. Direct match in CLINICAL_SYNONYMS keys
  2. Reverse lookup: find the canonical key whose synonym list contains the term
  3. Fuzzy partial match on synonyms
  4. Fallback: return just the original term
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from corpus.clinical_synonyms import CLINICAL_SYNONYMS, find_concept_for_synonym
from query.structured_query import ConceptGroup


class SynonymExpander:
    """
    Expands a raw query term to a ConceptGroup with clinical synonyms.

    Examples:
        expand("pneumonia")   → ConceptGroup(canonical="pneumonia", synonyms=[...15 terms...])
        expand("Advil")       → ConceptGroup(canonical="ibuprofen", synonyms=["ibuprofen","Advil",...])
        expand("LRTI")        → ConceptGroup(canonical="pneumonia", synonyms=[...])
        expand("headache")    → ConceptGroup(canonical="headache", synonyms=["headache"])  # fallback
    """

    def __init__(self, custom_synonyms: dict[str, list[str]] | None = None):
        """
        Args:
            custom_synonyms: Optional additional {concept: [synonyms]} to merge
                             with the built-in CLINICAL_SYNONYMS dictionary.
        """
        self.synonyms: dict[str, list[str]] = dict(CLINICAL_SYNONYMS)
        if custom_synonyms:
            for key, syns in custom_synonyms.items():
                self.synonyms[key.lower()] = syns

        # Build reverse lookup: synonym (lower) → canonical key
        self._reverse: dict[str, str] = {}
        for canonical, syns in self.synonyms.items():
            for syn in syns:
                self._reverse[syn.lower()] = canonical

    def expand(self, term: str) -> ConceptGroup:
        """
        Expand a raw term to a ConceptGroup.

        Args:
            term: A clinical concept term as entered by the user or extracted
                  by the query parser. May be lowercase, uppercase, mixed,
                  abbreviation, brand name, etc.

        Returns:
            ConceptGroup with canonical name + full synonym list.
        """
        term_lower = term.lower().strip()

        # 1. Direct key match
        if term_lower in self.synonyms:
            return ConceptGroup(
                canonical=term_lower,
                synonyms=self.synonyms[term_lower],
                original_term=term,
            )

        # 2. Reverse lookup: is this term a synonym of a known canonical?
        if term_lower in self._reverse:
            canonical = self._reverse[term_lower]
            return ConceptGroup(
                canonical=canonical,
                synonyms=self.synonyms[canonical],
                original_term=term,
            )

        # 3. Partial match: does the term appear as a substring in any canonical key?
        for canonical, syns in self.synonyms.items():
            if term_lower in canonical or canonical in term_lower:
                return ConceptGroup(
                    canonical=canonical,
                    synonyms=syns,
                    original_term=term,
                )

        # 4. Partial match against synonym strings
        for syn_lower, canonical in self._reverse.items():
            if term_lower in syn_lower or syn_lower in term_lower:
                return ConceptGroup(
                    canonical=canonical,
                    synonyms=self.synonyms[canonical],
                    original_term=term,
                )

        # 5. Fallback: return term as its own single-synonym group
        return ConceptGroup(
            canonical=term_lower,
            synonyms=[term],
            original_term=term,
        )

    def expand_many(self, terms: list[str]) -> list[ConceptGroup]:
        """Expand a list of terms to ConceptGroups."""
        return [self.expand(t) for t in terms]

    def list_all_concepts(self) -> list[str]:
        """Return all canonical concept keys."""
        return list(self.synonyms.keys())


# ── Module-level singleton ───────────────────────────────────────────────────
_expander: SynonymExpander | None = None


def get_expander() -> SynonymExpander:
    global _expander
    if _expander is None:
        _expander = SynonymExpander()
    return _expander


# ── Quick test ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    exp = SynonymExpander()

    test_terms = [
        "pneumonia", "Advil", "LRTI", "CAP", "cancer",
        "blister", "bullae", "ibuprofen", "Brufen",
        "diabetes", "headache",  # headache → fallback
    ]

    for term in test_terms:
        cg = exp.expand(term)
        print(f"{term!r:20s} → canonical={cg.canonical!r}, synonyms={cg.synonyms[:4]}...")
