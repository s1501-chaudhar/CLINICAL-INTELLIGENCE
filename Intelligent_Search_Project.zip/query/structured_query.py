from __future__ import annotations
"""
structured_query.py
====================
Dataclass representing a parsed, expanded search query.

This is the central data contract passed between:
  QueryParser → SynonymExpander → NegationHandler → Retrievers → Reranker
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class NegationMode(str, Enum):
    """
    Controls how must_exclude concepts are enforced.

    LITERAL:
        Exclude any note that contains ANY synonym of the excluded concept
        anywhere in the text, even if negated ("no cancer history" → EXCLUDED).

    CLINICAL_CONCEPT:
        Exclude only notes where the excluded concept is present and NOT negated.
        "No cancer history" → INCLUDED (cancer is negated).
        "History of lung cancer" → EXCLUDED (cancer is active).
    """
    LITERAL = "literal"
    CLINICAL_CONCEPT = "clinical_concept"


class SearchApproach(str, Enum):
    """Which retrieval approach to use."""
    KEYWORD  = "keyword"
    BOOLEAN  = "boolean"
    SEMANTIC = "semantic"
    HYBRID   = "hybrid"


class BooleanOperator(str, Enum):
    """How a concept group combines with others."""
    AND = "AND"    # Hard filter: note MUST contain this concept
    OR = "OR"      # Soft filter: note SHOULD contain at least one OR concept
    NOT = "NOT"    # Exclusion: note must NOT contain this concept


@dataclass
class ConceptGroup:
    """
    Represents a single clinical concept with its synonym expansion.

    Attributes:
        canonical:     The canonical/normalized name (e.g., "pneumonia")
        synonyms:      All known synonyms including the canonical form
        original_term: The raw term as typed by the user
        operator:      How this concept combines with others (AND/OR)
    """
    canonical: str
    synonyms: list[str]
    original_term: str = ""
    operator: BooleanOperator = BooleanOperator.AND

    def matches(self, text: str) -> bool:
        """Check if any synonym appears in the given text (case-insensitive)."""
        text_lower = text.lower()
        return any(syn.lower() in text_lower for syn in self.synonyms)

    def find_matching_synonyms(self, text: str) -> list[str]:
        """Return all synonyms found in the text."""
        text_lower = text.lower()
        return [syn for syn in self.synonyms if syn.lower() in text_lower]


@dataclass
class StructuredQuery:
    """
    The central query object produced by the QueryParser.

    Attributes:
        raw_query:       Original user input string
        must_include:    Concept groups joined by AND (ALL must be present)
        or_include:      Concept groups joined by OR (ANY must be present)
        must_exclude:    Concept groups that MUST NOT be present (per mode)
        semantic_intent: Natural language reformulation for embedding search
        negation_mode:   LITERAL or CLINICAL_CONCEPT exclusion mode
        approach:        Which search approach to use
        top_k:           Maximum number of results to return
    """
    raw_query: str
    must_include: list[ConceptGroup] = field(default_factory=list)
    or_include: list[ConceptGroup] = field(default_factory=list)
    must_exclude: list[ConceptGroup] = field(default_factory=list)
    semantic_intent: str = ""
    negation_mode: NegationMode = NegationMode.CLINICAL_CONCEPT
    approach: SearchApproach = SearchApproach.HYBRID
    top_k: int = 10

    @property
    def expanded_terms(self) -> dict[str, list[str]]:
        """Convenience property for display in API response."""
        result = {}
        for cg in self.must_include:
            result[cg.canonical] = cg.synonyms
        for cg in self.or_include:
            result[cg.canonical] = cg.synonyms
        for cg in self.must_exclude:
            result[cg.canonical] = cg.synonyms
        return result

    @property
    def all_include_synonyms(self) -> list[str]:
        """Flat list of all synonyms from must_include AND or_include groups."""
        syns = [syn for cg in self.must_include for syn in cg.synonyms]
        syns += [syn for cg in self.or_include for syn in cg.synonyms]
        return syns

    @property
    def all_exclude_synonyms(self) -> list[str]:
        """Flat list of all synonyms from must_exclude groups."""
        return [syn for cg in self.must_exclude for syn in cg.synonyms]

    @property
    def has_or_logic(self) -> bool:
        return len(self.or_include) > 0

    def to_display_dict(self) -> dict:
        """Serialise to the response format shown in the project brief."""
        return {
            "must_include": [{"concept": cg.canonical, "synonyms": cg.synonyms} for cg in self.must_include],
            "or_include": [{"concept": cg.canonical, "synonyms": cg.synonyms} for cg in self.or_include],
            "must_exclude": [{"concept": cg.canonical, "synonyms": cg.synonyms} for cg in self.must_exclude],
            "semantic_intent": self.semantic_intent,
            "raw_query": self.raw_query,
            "mode": self.negation_mode.value,
            "approach": self.approach.value,
            "logic": "OR" if self.has_or_logic and not self.must_include else "AND",
        }
