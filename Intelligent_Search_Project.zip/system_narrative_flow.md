# The Complete System Narrative Flow
**A step-by-step chronological guide to the Intelligent Medical Search Engine.**

This document walks through exactly what happens when a doctor presses "Search," explaining every single technology, algorithm, and AI model encountered along the way, including *why* we chose it and *what* it actually is.

---

## Step 1: The Request Hits the Server
*A doctor types "patient having severe pneumonia" and hits Enter.*

### 🛠️ Technology Encountered: FastAPI
*   **What is it?** A modern web **Framework** for Python.
*   **Why we used it:** It is incredibly fast, handles asynchronous requests (multiple users at once) effortlessly, and automatically generates API documentation. 
*   **Why not others?** *Flask* is too old and synchronous (slower). *Django* is way too massive and bloated for a simple search API.

---

## Step 2: Query Parsing & NLP (Natural Language Processing)
*The raw text "patient having severe pneumonia" goes into `query_parser.py`.*

### 🧠 Algorithm Encountered: Rule-Based Regex (Regular Expressions)
*   **What is it?** A standard computer science **Algorithm/Logic** used to find patterns in text.
*   **Why we used it:** We use custom Regex rules to strip out "stop words" (like the words *patient* and *having*). If we don't delete these words, the search engine will refuse to show documents unless they contain the exact word "patient," which destroys the search. We also use Regex to look for explicit boolean words like `AND`, `OR`, `NOT`.
*   **Why not others?** We could have used a massive AI model (like ChatGPT) to parse the query, but that is too slow, costs money, and introduces unpredictable latency. Regex is instant, free, and perfectly predictable.

---

## Step 3: Synonym Expansion
*The remaining core concept ("pneumonia") needs to be expanded.*

### 📁 Data Structure Encountered: Hardcoded Dictionary Map
*   **What is it?** A static Python **Dictionary** located in `corpus/clinical_synonyms.py`.
*   **Why we used it:** It instantly maps "pneumonia" to `["CAP", "LRTI", "pneumonia"]`. It happens in 0.0001 seconds.
*   **Why not others?** We could have used an external Medical Ontology API (like UMLS), but that requires network calls which slow down the search and creates a dependency on an external server.

---

## Step 4: Routing to the Search Databases
*The system now splits the query and sends it down TWO separate paths at the exact same time (The Hybrid Approach).*

---

### Path A: The Lexical Keyword Search
*It takes the exact words `["CAP", "LRTI", "pneumonia"]` and looks for exact text matches in the clinical notes.*

#### 🗄️ Technology Encountered: Whoosh
*   **What is it?** A pure-Python Lexical **Database Library**. It builds an "Inverted Index" (like the index at the back of a textbook).
*   **Why we used it:** It is completely serverless. It just creates local files on your hard drive. It requires zero setup and is very fast for medium-sized datasets.
*   **Why not others?** *Elasticsearch* is the industry giant, but it requires Java, massive amounts of RAM, and a complex server setup. It is too bloated for a local medical application.

#### 🧮 Algorithm Encountered: BM25 (Best Matching 25)
*   **What is it?** A mathematical scoring **Algorithm** used by Whoosh to rank keyword matches.
*   **Why we used it:** BM25 uses "Term Frequency Saturation." This means it prevents long, spammy documents from cheating the system. If a document mentions "pneumonia" 5 times, it gets a high score. But if a 50-page document mentions it 100 times, the score stops increasing, preventing it from unfairly dominating the top spot.
*   **Why not others?** *Bag of Words (BoW)* just counts words and is easily fooled by the word "the". *TF-IDF* is better but doesn't have saturation, so extremely long documents always win unfairly.

---

### Path B: The Semantic AI Search
*At the exact same time, it takes the natural language intent ("Find clinical notes about pneumonia") and searches based on meaning, not spelling.*

#### 🤖 Model Encountered: Sentence-Transformers (`all-MiniLM-L6-v2`)
*   **What is it?** An open-source, BERT-based **AI Machine Learning Model**.
*   **Why we used it:** It converts a human sentence into a mathematical array of 384 numbers (a vector). This model is highly optimized to run locally on your computer's CPU. It is free and guarantees that patient queries never leave the hospital's local network (HIPAA compliant).
*   **Why not others?** *OpenAI (ChatGPT) Embeddings* cost money per search, take hundreds of milliseconds of network latency, and require sending sensitive medical queries over the open internet. *Word2Vec* is too old and only understands single words, not full sentences.

#### 🗄️ Database Encountered: FAISS (Facebook AI Similarity Search)
*   **What is it?** A C++ **Vector Database** library created by Meta/Facebook. 
*   **Why we used it:** Once the AI creates the 384-number vector for the query, we need to compare it against thousands of patient note vectors. FAISS runs completely in your RAM (memory) and uses mathematical geometry (Cosine Similarity) to find the closest matching vectors in milliseconds.
*   **Why not others?** Cloud vector databases like *Pinecone* or *Weaviate* suffer from network latency and break our rule of keeping everything local and private.

---

## Step 5: Post-Processing & The Hybrid Merge
*Now we have two lists of results. A top 300 list from Whoosh (BM25) and a top 200 list from FAISS (Semantic). We pool them together.*

### 🧮 Algorithm Encountered: Reciprocal Rank Fusion (RRF)
*   **What is it?** A mathematical sorting **Algorithm**.
*   **Why we used it:** You cannot simply add a BM25 score (which might be `15.5`) to a Vector score (which is a percentage like `0.85`). The math doesn't work. RRF ignores the raw scores entirely and looks only at the **Leaderboard Rank**. If Note A got 1st place in Keyword search, and 4th place in AI search, RRF mathematically fuses those placements to create a master leaderboard.
*   **Why not others?** *Linear Combination* (Score A + Score B) is mathematically unstable because BM25 scores have no maximum limit, meaning they often completely overpower and delete the AI scores.

### 🛡️ Logic Encountered: Negation Handling (The AI Safety Net)
*   **What is it?** A custom Python **Logic Rule**.
*   **Why we used it:** AI Vector models are notoriously stupid when it comes to the word "NOT". If you search `"asthma NOT pneumonia"`, the AI sees the vector for "pneumonia" and actually returns notes about pneumonia! To fix this, after the results are pooled, our Python code physically deletes any note that contains the forbidden word, overriding the AI's hallucination.

---

## Step 6: Final Output
*The final fused, filtered, and sorted list is formatted into a JSON payload and sent back through FastAPI to the User Interface, where Javascript highlights the matching words in green.*
