# 🏆 The Ultimate Architecture & Flow Guide: Intelligent Medical Search

This document is your **master cheat sheet and comprehensive guide** for the entire Intelligent Medical Search project. It contains the high-level elevator pitch, a visual flow diagram of exactly how the system processes data, and a deep, file-by-file breakdown of the entire codebase.

If anyone asks you a question during your presentation, the answer is in this document.

---

## Phase 1: The Basics (Explain it to a 5-year-old)

Before diving into code, here is the "elevator pitch" of what this project does:

*   **The Problem:** Hospitals use "Keyword Search" (like hitting `Ctrl+F` on a document). If a doctor searches for "Heart Attack", the computer only looks for those exact words. It completely misses a note that says "Myocardial Infarction" because the words are spelled differently.
*   **The Solution:** We built an AI-powered search engine. 
    *   First, it has a **Medical Dictionary** built-in, so it knows synonyms.
    *   Second, it uses **Semantic Search (AI)** to understand the *meaning* of sentences, not just the spelling.
    *   Third, it uses **Hybrid Search** to combine the strict accuracy of keywords with the deep understanding of AI.

---

## Phase 2: Search Pipeline Flow Structure

This diagram outlines exactly how a query travels from the user typing it to the final ranked clinical notes.

```mermaid
flowchart TD
    %% ── USER INPUT ──
    User[fa:fa-user User Input Query] --> API[FastAPI /search Endpoint]
    
    %% ── PARSING & NLP ──
    subgraph parsing [1. Query Parsing & NLP Engine]
        direction TB
        API --> QP[QueryParser]
        QP --> NLP{Does it match NLP Patterns?}
        NLP -- Yes --> Extract[Extract Concepts & Boolean Logic]
        NLP -- No --> Fallback[Clean Text / Pure Semantic Fallback]
        
        Extract --> Syn[SynonymExpander]
        Fallback --> Syn
        
        Syn --> SQ[StructuredQuery Object]
        SQ -.-> |must_include| AND[Hard AND Filters]
        SQ -.-> |must_exclude| NOT[Negation Filters]
        SQ -.-> |semantic_intent| Intent[Natural Language Sentence]
        SQ -.-> |all_include_synonyms| Syns[Flattened Synonym List]
    end
    
    %% ── ROUTING ──
    SQ --> Router{Which Approach?}
    Router -- "approach=keyword" --> BM25Ret[BM25 Retriever]
    Router -- "approach=semantic" --> SemRet[Semantic Retriever]
    Router -- "approach=hybrid" --> HybRet[Hybrid Retriever]
    
    %% ── APPROACH: BM25 (STRICT LEXICAL) ──
    subgraph Keyword [Approach: Pure Keyword]
        direction TB
        BM25Ret --> Strip[Strip Boolean Operators]
        Strip --> RawTerms[Raw User Terms]
        RawTerms --> BM25Index1[(Whoosh BM25 Index)]
    end
    
    %% ── APPROACH: SEMANTIC ──
    subgraph Semantic [Approach: Pure Semantic]
        direction TB
        SemRet --> Encoder1[SentenceTransformer Encode]
        Encoder1 --> FAISS1[(FAISS Vector Index)]
    end
    
    %% ── APPROACH: HYBRID ──
    subgraph Hybrid [Approach: Hybrid Retriever]
        direction TB
        HybRet --> BM25Hyb[BM25 Step\nUses ALL Synonyms]
        HybRet --> VecHyb[Vector Step\nUses Semantic Intent]
        
        BM25Hyb --> BM25Index2[(Whoosh BM25 Index)]
        VecHyb --> Encoder2[SentenceTransformer] --> FAISS2[(FAISS Vector Index)]
        
        BM25Index2 --> Pool[Union Pool]
        FAISS2 --> Pool
        
        Pool --> FilterAND[Apply Hard Boolean AND Filter]
        FilterAND --> FilterNOT[Apply Negation/Exclusion Filter]
        FilterNOT --> Fuse[Fuse Scores & Sort]
    end
    
    BM25Index1 --> Out[Final Ranked JSON Response]
    FAISS1 --> Out
    Fuse --> Out
    
    %% Styling
    classDef index fill:#f9f,stroke:#333,stroke-width:2px;
    class BM25Index1,BM25Index2,FAISS1,FAISS2 index;
```

### Detailed Step-by-Step Flow Explanation
1. **User Input:** The user types a query (e.g., `"patient having pneumonia"`).
2. **Query Parsing:** The `QueryParser` reads the raw string, identifies boolean logic, strips out clinical stop words (`"patient"`, `"having"`), and groups the remaining concepts.
3. **Synonym Expansion:** The concepts hit a dictionary to expand synonyms (e.g., `"pneumonia"` -> `["CAP", "LRTI", "pneumonia"]`).
4. **Intent Building:** The parser builds a clean natural language sentence representing the semantic intent.
5. **Retrieval Routing:** The query goes to the selected retriever (Keyword, Semantic, or Hybrid).
6. **Execution & Pooling:** Results are extracted from the databases (Whoosh for keywords, FAISS for vectors), pooled together, and heavily filtered.
7. **Scoring & Output:** Results are fused together mathematically using RRF and sent back to the user.

---

## Phase 3: Comprehensive File-by-File Breakdown

Here is exactly what every major folder and file in this repository is responsible for.

### 1. `api/` (The Server & Routing)
*   **`main.py`**: The entry point for the FastAPI server. It mounts the UI and exposes the endpoints.
*   **`routes/search.py`**: The main controller. It catches the `POST` request from the UI, hands the raw text to the `QueryParser`, and then routes the parsed query to `bm25_retriever`, `semantic_retriever`, or `hybrid_retriever` based on the user's dropdown selection in the UI.

### 2. `query/` (The Intelligence & Parsing Engine)
This module acts as the "brain" before any database is touched.
*   **`query_parser.py`**: A complex, rule-based NLP parser. It uses regex to look for implicit and explicit logic (like "X but not Y"). It strips clinical stop words (e.g., "patient", "diagnosed with") so they don't break strict Boolean searches.
*   **`structured_query.py`**: A Data Class defining the contract between the parser and the retrievers. It holds lists of `must_include` concepts, `must_exclude` concepts, and the `semantic_intent` string.
*   **`synonym_expander.py`**: Injects medical synonyms into the query. It looks up canonical terms and adds known abbreviations to broaden the search net.
*   **`negation_handler.py`**: AI Vector databases are notoriously bad at understanding the word "NOT". If you search `asthma NOT pneumonia`, the AI will likely return notes about pneumonia because the vector for the word "pneumonia" is physically in the query. This file strictly deletes any note containing forbidden words *after* the retrieval phase, completely solving the AI's hallucination problem.

### 3. `indexing/` (Database Generation)
We do not use standard SQL because it is too slow for unstructured medical text. Instead, we compile JSON files into highly optimized search indexes.
*   **`bm25_indexer.py`**: Compiles clinical notes into a **Whoosh Lexical Index**. This is an "inverted index" (just like the index at the back of a textbook). It allows the computer to instantly find which notes contain the exact word "ibuprofen".
*   **`vector_indexer.py`**: Compiles clinical notes into a **FAISS Vector Database**. The AI reads a medical note and converts the meaning of that note into an array of 384 numbers (a vector). It plots that vector as a point in a 384-dimensional space. We use Facebook's FAISS library to store and instantly query these points based on mathematical proximity.

### 4. `retrieval/` (The Core Search Algorithms)
This is where the actual search happens against the databases.
*   **`bm25_retriever.py`**: The **Pure Keyword Approach**. It takes exactly what the user typed, intentionally ignores `SynonymExpander` and semantic intent, and runs a strict lexical match. Used to demonstrate traditional, rigid search engine limitations.
*   **`semantic_retriever.py`**: The **Pure AI Approach**. It converts the user's query into a vector using `SentenceTransformers` and asks FAISS for the physically closest notes in the mathematical space. Excellent at understanding concepts, but sometimes hallucinates or misses exact IDs.
*   **`hybrid_retriever.py`**: The **Best of Both Worlds (Production Recommended)**. 
    1. It pulls a massive candidate pool using all synonyms from Whoosh.
    2. It pulls a massive candidate pool using semantic intent from FAISS.
    3. It pools them together (Union).
    4. It strictly applies the `must_include` and `must_exclude` filters.
    5. It scores them based on a weighted fusion equation.


### 5. `postprocess/` (Formatting, UX, and Math)
*   **`score_fusion.py`**: You cannot simply add a BM25 score (e.g., 14.5) to a Vector score (e.g., 0.82) because the math is completely different. We use normalization and **Reciprocal Rank Fusion (RRF)** to merge their rankings fairly based on their positions on the leaderboard, rather than their raw scores.
*   **`evidence_extractor.py`**: When the backend finds a winning note, it scans the text of that note looking for the specific words that caused it to win. It returns details that allow the UI to highlight those words (e.g., in green or blue), proving to the doctor *why* the AI chose that note.
*   **`result_formatter.py`**: Formats the final payload into a clean JSON structure for the frontend JavaScript to consume.

### 6. `ui/` (The User Interface)
*   **`index.html`**: The HTML layout of the search interface.
*   **`js/app.js`**: The JavaScript that sends the async `fetch()` request to `/api/search` and dynamically builds the HTML cards, progress bars, and CSS highlights on the screen when the data returns.

---

## Phase 4: Key Code Snippets to Memorize

If you need to show the code doing the heavy lifting, point to these.

**The Hybrid Union (Pooling BM25 and Vector Search)**
*From `retrieval/hybrid_retriever.py`*
```python
# ── Step 1: BM25 candidates ───────────────────────────────────────────
all_include_syns = query.all_include_synonyms
bm25_candidates = self._bm25.search_notes(all_include_syns, top_k=300)

# ── Step 2: Vector candidates ─────────────────────────────────────────
search_text = query.semantic_intent
vector_candidates = self._vector_notes.search(search_text, top_k=200)

# ── Step 3: Union pool ────────────────────────────────────────────────
pooled = pool_results(bm25_candidates, vector_candidates)
```

**The Semantic FAISS Search (Sentence Transformers)**
*From `indexing/vector_indexer.py`*
```python
def search(self, query_text):
    # 1. Convert user's text into a mathematical vector
    query_vector = self.model.encode([query_text])
    
    # 2. Ask FAISS to find the closest matching vectors (notes)
    distances, indices = self.index.search(query_vector, top_k=50)
    return top_results
```

**Reciprocal Rank Fusion (Combining Scores)**
*From `postprocess/score_fusion.py`*
```python
def fuse_results(bm25_results, semantic_results, k=60):
    fused_scores = {}
    
    # Process BM25 rankings
    for rank, note in enumerate(bm25_results):
        # RRF Formula: 1 / (60 + rank)
        fused_scores[note.id] += 1.0 / (k + rank)
        
    # Process FAISS rankings
    for rank, note in enumerate(semantic_results):
        fused_scores[note.id] += 1.0 / (k + rank)
        
    # Sort notes by their new combined RRF score
    return sorted_notes
```
