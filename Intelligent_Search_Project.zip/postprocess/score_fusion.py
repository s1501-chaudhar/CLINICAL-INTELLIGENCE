from __future__ import annotations
"""
score_fusion.py
===============
Normalises and fuses BM25, vector similarity, and Boolean scores
into a single hybrid_score per result.

Formula:
    hybrid_score = w_bm25 * norm(bm25) + w_vec * norm(vector) + w_bool * boolean

Weights are loaded from config/settings.py (default: 0.4 / 0.4 / 0.2).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import BM25_WEIGHT, VECTOR_WEIGHT, BOOLEAN_WEIGHT


def _min_max_normalize(values: list[float]) -> list[float]:
    """Normalise a list of floats to [0, 1] range."""
    if not values:
        return []
    mn, mx = min(values), max(values)
    if mx == mn:
        return [1.0] * len(values)
    return [(v - mn) / (mx - mn) for v in values]


def fuse_scores(
    results: list[dict],
    w_bm25: float = BM25_WEIGHT,
    w_vec: float = VECTOR_WEIGHT,
    w_bool: float = BOOLEAN_WEIGHT,
) -> list[dict]:
    """
    Fuse BM25, vector, and Boolean scores into a single hybrid_score.

    Normalises each score dimension independently before fusion.

    Args:
        results:  List of note dicts containing bm25_score, vector_score,
                  boolean_score fields (missing fields default to 0.0)
        w_bm25:   Weight for BM25 score component
        w_vec:    Weight for vector similarity component
        w_bool:   Weight for Boolean match component

    Returns:
        Same list with hybrid_score added/updated, sorted by hybrid_score desc.
    """
    if not results:
        return []

    bm25_scores = [r.get("bm25_score", 0.0) for r in results]
    vec_scores = [r.get("vector_score", 0.0) for r in results]
    bool_scores = [r.get("boolean_score", 0.0) for r in results]

    norm_bm25 = _min_max_normalize(bm25_scores)
    norm_vec = _min_max_normalize(vec_scores)
    # Boolean score is already in [0,1]

    fused = []
    for i, result in enumerate(results):
        result = dict(result)
        result["norm_bm25_score"] = norm_bm25[i]
        result["norm_vector_score"] = norm_vec[i]
        result["hybrid_score"] = (
            w_bm25 * norm_bm25[i]
            + w_vec * norm_vec[i]
            + w_bool * bool_scores[i]
        )
        fused.append(result)

    fused.sort(key=lambda x: -x["hybrid_score"])
    return fused


def pool_results(
    bm25_results: list[dict],
    vector_results: list[dict],
    id_field: str = "note_id",
) -> list[dict]:
    """
    Union-pool BM25 and vector results, merging scores for duplicates.

    When a note appears in both result sets, its scores are combined
    (BM25 and vector scores are both retained).

    Args:
        bm25_results:   Results from BM25 search
        vector_results: Results from semantic search
        id_field:       The primary key field name

    Returns:
        Merged list with all unique notes, scores combined where overlap.
    """
    pooled: dict[str, dict] = {}

    for note in bm25_results:
        note_id = note[id_field]
        pooled[note_id] = dict(note)
        pooled[note_id].setdefault("vector_score", 0.0)

    for note in vector_results:
        note_id = note[id_field]
        if note_id in pooled:
            # Merge: keep BM25 score, add vector score
            pooled[note_id]["vector_score"] = note.get("vector_score", 0.0)
        else:
            merged = dict(note)
            merged.setdefault("bm25_score", 0.0)
            pooled[note_id] = merged

    return list(pooled.values())
