from __future__ import annotations
"""
research_retriever.py
=====================
Retrieves relevant research abstracts for a given StructuredQuery.

Uses both BM25 (keyword match) and vector similarity, then fuses results.
Returns the top-k most relevant abstracts alongside clinical note results.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.bm25_indexer import BM25Indexer
from indexing.vector_indexer import VectorIndexer
from postprocess.score_fusion import pool_results, fuse_scores


class ResearchRetriever:
    """
    Retrieves relevant research abstracts in parallel with clinical note search.

    Uses both BM25 and vector search against the separate research index.
    """

    def __init__(self):
        self._bm25 = BM25Indexer()
        self._vector = VectorIndexer("research")
        self._vector_loaded = False

    def _ensure_vector_loaded(self) -> None:
        if not self._vector_loaded:
            try:
                self._vector.load()
                self._vector_loaded = True
            except FileNotFoundError:
                self._vector_loaded = False

    def retrieve(self, query: StructuredQuery, approach: str = "hybrid", top_k: int = 5) -> list[dict]:
        """
        Retrieve top-k relevant research abstracts.

        Args:
            query:  The StructuredQuery (uses synonyms + semantic intent)
            approach: "keyword", "semantic", or "hybrid"
            top_k:  Maximum abstracts to return

        Returns:
            List of abstract dicts with relevance scores
        """
        all_syns = query.all_include_synonyms or [query.raw_query]

        # BM25 search
        bm25_results = []
        if approach in ["keyword", "hybrid"]:
            bm25_results = self._bm25.search_research(all_syns, top_k=top_k * 3)

        # Vector search
        vector_results = []
        if approach in ["semantic", "hybrid"]:
            self._ensure_vector_loaded()
            search_text = query.semantic_intent
            if search_text:
                vector_results = (
                    self._vector.search(search_text, top_k=top_k * 2)
                    if self._vector_loaded
                    else []
                )

        # Pool BM25 and Vector results
        pooled = pool_results(bm25_results, vector_results, id_field="abstract_id")

        # Inject "text" for Boolean filtering
        for n in pooled:
            if "text" not in n:
                n["text"] = f"{n.get('title', '')}. {n.get('abstract', '')}"

        from query.negation_handler import is_concept_negated, apply_exclusion_filter

        # Semantic approach does not enforce hard boolean AND/OR limits
        if approach != "semantic":
            # ── Step 4a: Hard AND filter ──────────────────────────────────────────
            if query.must_include:
                pooled = [
                    n for n in pooled
                    if all(
                        cg.matches(n["text"]) and not is_concept_negated(n["text"], cg.synonyms)
                        for cg in query.must_include
                    )
                ]

            # ── Step 4b: Soft OR filter ───────────────────────────────────────────
            if query.or_include:
                pooled = [
                    n for n in pooled
                    if any(
                        cg.matches(n["text"]) and not is_concept_negated(n["text"], cg.synonyms)
                        for cg in query.or_include
                    )
                ]

        # ── Step 5: Exclusion / NOT filter ───────────────────────────────────
        if query.must_exclude:
            pooled, _ = apply_exclusion_filter(
                pooled,
                query.must_exclude,
                mode=query.negation_mode,
            )

        # ── Step 6: Boolean score annotation ─────────────────────────────────
        pooled = self._annotate_boolean_score(pooled, query)

        # Fuse scores and return top_k
        fused = fuse_scores(pooled)
        return fused[:top_k]

    def _annotate_boolean_score(
        self, notes: list[dict], query: StructuredQuery
    ) -> list[dict]:
        """
        Compute per-note boolean_score and matched_synonyms.
        """
        total_and = len(query.must_include)
        result = []
        for note in notes:
            text_lower = note.get("text", "").lower()
            matched_syns: list[str] = []
            matched_detail: list[dict] = []
            and_matched = 0

            for idx, cg in enumerate(query.must_include):
                hits = [s for s in cg.synonyms if s.lower() in text_lower]
                if hits:
                    and_matched += 1
                    for h in hits:
                        matched_syns.append(h)
                        matched_detail.append({"synonym": h, "concept": cg.canonical, "color_index": idx % 3})

            or_matched = 0
            for idx, cg in enumerate(query.or_include):
                hits = [s for s in cg.synonyms if s.lower() in text_lower]
                if hits:
                    or_matched += 1
                    for h in hits:
                        matched_syns.append(h)
                        matched_detail.append({"synonym": h, "concept": cg.canonical, "color_index": (total_and + idx) % 3})

            and_score = and_matched / total_and if total_and > 0 else 1.0
            or_score  = (1.0 if or_matched > 0 else 0.0) if query.or_include else 1.0
            bool_score = (and_score + or_score) / 2 if query.or_include else and_score

            note = dict(note)
            note["boolean_score"] = bool_score
            note["matched_synonyms"] = list(set(matched_syns))
            note["matched_concepts_detail"] = matched_detail
            result.append(note)
        return result

