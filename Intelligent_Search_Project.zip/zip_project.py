import zipfile
import os

def create_zip():
    zip_filename = "Intelligent_Search_Project.zip"
    exclude_dirs = {".git", "venv", "__pycache__", ".pytest_cache", ".gemini", ".idea", ".vscode"}
    exclude_exts = {".pyc", ".pyo", ".pyd", ".zip"}

    print(f"Creating {zip_filename}...")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk("."):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if any(file.endswith(ext) for ext in exclude_exts):
                    continue
                
                file_path = os.path.join(root, file)
                # Store relative path inside zip
                arcname = os.path.relpath(file_path, ".")
                zipf.write(file_path, arcname)
                print(f"Added: {arcname}")

    print(f"\nDone! Project saved to {zip_filename}")
    print("NOTE: The 'venv' directory was excluded. The recipient will need to run 'pip install -r requirements.txt'.")

if __name__ == "__main__":
    create_zip()
