# Developer Handoff: Intelligent Medical Search Engine

**Target Audience:** Software Engineers, ML Engineers, and Technical Reviewers.
**Purpose:** Provide complete, unabridged context of the system architecture, technology stack, and request lifecycle so a new developer can immediately understand and contribute to the codebase.

---

## 1. System Overview

The Intelligent Medical Search Engine is a specialized retrieval system designed for clinical notes and research abstracts. Traditional hospital systems rely on strict keyword matching (e.g., TF-IDF or basic BoW), which suffers from the "Vocabulary Mismatch Problem" (e.g., failing to match "heart attack" with "myocardial infarction"). 

To solve this, our system implements a **Hybrid Search Pipeline** that combines:
1. **Lexical Retrieval (BM25)** for exact keyword and ID matching.
2. **Semantic Retrieval (Dense Vectors)** for conceptual sentence understanding.
3. **Hard Boolean & Negation Filtering** to strictly enforce medical rules (e.g., "NOT cancer").
4. **Reciprocal Rank Fusion (RRF)** to mathematically merge the two distinct scoring systems.

---

## 2. Technology Stack & Design Decisions

Every technology in this stack was chosen to prioritize **speed, local execution, and privacy** (no patient data sent to 3rd-party APIs).

| Component | Technology | Rationale |
| :--- | :--- | :--- |
| **Backend API** | FastAPI (Python) | High performance, async-native, self-documenting (Swagger), and lightweight. |
| **Keyword Search** | BM25 (via Whoosh) | BM25 is the industry standard lexical algorithm. Unlike TF-IDF, it uses Term Frequency Saturation so that long, spammy documents don't dominate results. Whoosh was chosen over Elasticsearch because it is pure Python, serverless, and runs entirely on local files without heavy JVM overhead. |
| **Semantic Model** | Sentence-Transformers (`all-MiniLM-L6-v2`) | A BERT-based embedding model that runs 100% locally on CPU. Chosen over OpenAI/Cohere embeddings to guarantee HIPAA compliance (zero network calls) and eliminate API costs. |
| **Vector Database** | FAISS (Facebook AI Similarity Search) | The gold-standard C++ library for dense vector similarity search. Chosen over Pinecone/Weaviate because it runs entirely in-memory on the local machine with near-zero latency. |
| **Score Fusion** | Reciprocal Rank Fusion (RRF) | Linear score combinations (e.g., BM25 Score + Vector Score) fail because BM25 scores are unbounded and Vector Cosine scores are bounded (0-1). RRF merges results based purely on their leaderboard rank, ensuring mathematically robust hybrid sorting. |

---

## 3. Architecture & Request Lifecycle

Below is the exact path a user's text query takes through the system.

```mermaid
flowchart TD
    %% ── USER INPUT ──
    User[fa:fa-user User Input Query] --> API[FastAPI /search Endpoint]
    
    %% ── PARSING & NLP ──
    subgraph parsing [1. Query Parsing & NLP Engine]
        direction TB
        API --> QP[QueryParser]
        QP --> NLP{Does it match NLP Patterns?}
        NLP -- Yes --> Extract[Extract Concepts & Boolean Logic]
        NLP -- No --> Fallback[Clean Text / Pure Semantic Fallback]
        
        Extract --> Syn[SynonymExpander]
        Fallback --> Syn
        
        Syn --> SQ[StructuredQuery Object]
        SQ -.-> |must_include| AND[Hard AND Filters]
        SQ -.-> |must_exclude| NOT[Negation Filters]
        SQ -.-> |semantic_intent| Intent[Natural Language Sentence]
        SQ -.-> |all_include_synonyms| Syns[Flattened Synonym List]
    end
    
    %% ── ROUTING ──
    SQ --> Router{Which Approach?}
    Router -- "approach=keyword" --> BM25Ret[BM25 Retriever]
    Router -- "approach=semantic" --> SemRet[Semantic Retriever]
    Router -- "approach=hybrid" --> HybRet[Hybrid Retriever]
    
    %% ── APPROACH: HYBRID ──
    subgraph Hybrid [Approach: Hybrid Retriever]
        direction TB
        HybRet --> BM25Hyb[BM25 Step\nUses ALL Synonyms]
        HybRet --> VecHyb[Vector Step\nUses Semantic Intent]
        
        BM25Hyb --> BM25Index2[(Whoosh BM25 Index)]
        VecHyb --> Encoder2[SentenceTransformer] --> FAISS2[(FAISS Vector Index)]
        
        BM25Index2 --> Pool[Union Pool]
        FAISS2 --> Pool
        
        Pool --> FilterAND[Apply Hard Boolean AND Filter]
        FilterAND --> FilterNOT[Apply Negation/Exclusion Filter]
        FilterNOT --> Fuse[Fuse Scores (RRF) & Sort]
    end
    
    Fuse --> Out[Final Ranked JSON Response]
    BM25Ret --> Out
    SemRet --> Out
```

### Detailed Request Flow:
1. **API Intercept:** `api/routes/search.py` catches the query.
2. **Parsing (`query/query_parser.py`):** Uses Regex to identify explicit (`AND`, `OR`, `NOT`) and implicit natural language rules (e.g., "notes containing X but not Y"). It aggressively strips medical stop words (e.g., "patient", "diagnosed") to prevent them from becoming mandatory search keywords.
3. **Expansion (`query/synonym_expander.py`):** Injects clinical synonyms (e.g., "heart attack" -> "myocardial infarction", "MI") to ensure lexical search has maximum coverage.
4. **Intent Building:** Reconstructs a clean semantic sentence (ignoring boolean operators) specifically designed to be passed to the SentenceTransformer.
5. **Retrieval (`retrieval/hybrid_retriever.py`):**
    * **Lexical Phase:** Passes all synonyms to Whoosh (OR logic) to get top 300 candidates.
    * **Semantic Phase:** Embeds the semantic intent and queries FAISS to get top 200 candidates.
6. **Filtering:** The two pools are unioned. Any note that violates a `must_include` (Hard AND) or `must_exclude` (Negation) rule is immediately dropped from the pool. This solves the classic AI hallucination issue where dense vectors accidentally return negated concepts.
7. **Fusion (`postprocess/score_fusion.py`):** RRF math is applied to the remaining notes, and they are sorted by `hybrid_score`.

---

## 4. Codebase Directory Structure

```text
Intelligent_Search_Final_v2/
│
├── api/                     
│   ├── main.py              # Application entry point.
│   └── routes/search.py     # Request router and endpoint logic.
│
├── config/                  
│   └── settings.py          # Global configurations, file paths, model selection.
│
├── corpus/                  
│   └── clinical_synonyms.py # Hardcoded medical dictionary for synonym expansion.
│
├── data/raw/                
│   ├── clinical_notes/      # Raw JSON input files for patient notes.
│   └── research_abstracts/  # Raw JSON input files for medical abstracts.
│
├── indexing/                
│   ├── bm25_indexer.py      # Script to parse JSON and build Whoosh indexes.
│   ├── vector_indexer.py    # Script to parse JSON, run embedding model, and build FAISS.
│   └── index_store/         # Ignored in git; holds the physical generated database files.
│
├── query/                   
│   ├── query_parser.py      # Core NLP engine for boolean/stopword extraction.
│   ├── structured_query.py  # Data contract definition (StructuredQuery object).
│   ├── synonym_expander.py  # Maps concepts to corpus/clinical_synonyms.py.
│   └── negation_handler.py  # Evaluates text to ensure excluded terms are truly absent.
│
├── retrieval/               
│   ├── bm25_retriever.py    # Standalone strict lexical retriever (No AI/Synonyms).
│   ├── semantic_retriever.py# Standalone pure AI vector retriever.
│   └── hybrid_retriever.py  # The primary production retriever (pools, filters, fuses).
│
├── postprocess/             
│   ├── score_fusion.py      # Reciprocal Rank Fusion (RRF) logic.
│   ├── evidence_extractor.py# Locates matched terms in text for UI highlighting.
│   └── result_formatter.py  # Normalizes output payload for the frontend.
│
└── ui/                      
    └── index.html, js/app.js# Frontend UI built with vanilla JS and CSS.
```

---

## 5. Key System Behaviors to Note

* **Vector Database Lazy Loading:** SentenceTransformers and FAISS are large dependencies. They are lazy-loaded to ensure the API boots up instantly and gracefully degrades to BM25-only if the environment lacks the necessary Python packages (like PyTorch).
* **The "Lexical Strict" BM25 Retriever:** `bm25_retriever.py` deliberately bypasses synonym expansion. It takes the user's raw input, strips out boolean operators, and queries Whoosh directly. This is strictly designed to act as a baseline for comparison against the Hybrid model.
* **Implicit Boolean Fallback:** If a user types a completely unstructured sentence (e.g., "patient with high blood pressure"), the `QueryParser` will strip words like "patient" and "with". It will then assign "high blood pressure" as a `must_include` (Hard AND) concept. If no medical terms are found after stripping stopwords, the entire string acts as a soft semantic intent.
