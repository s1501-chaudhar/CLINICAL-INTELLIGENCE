# 🎤 Speaker 3 Master Guide: The "Judge"

Congratulations, you have the most important job! Speaker 1 translated the query, and Speaker 2 ran the massive database searches. Now, they are handing you two massive, raw lists of results. 

Your job is to **filter out the AI's mistakes**, **mathematically score the final list**, and **light up the User Interface**.

Here is your detailed, simple explanation of exactly how your part of the code works.

---

## 🛡️ 1. The Safety Net: Fixing AI Hallucinations
**Files you own:** `retrieval/hybrid_retriever.py` and `query/negation_handler.py`

### The Problem
AI Vector databases (like FAISS) are brilliant at understanding concepts, but they are incredibly stupid when it comes to the word **"NOT"**. If a doctor searches for `"patients with asthma but NOT pneumonia"`, the AI sees the mathematical vector for "pneumonia" in the query, and it will confidently return dozens of clinical notes about pneumonia. In a hospital, that mistake could be fatal.

### How Your Code Fixes It
In `hybrid_retriever.py`, the very first thing you do is take Speaker 2's two lists (BM25 and Vector) and smash them together into one giant pool. 

Then, you run a **Hard Boolean Filter**. This acts as an iron-clad safety net. Your Python code literally loops through every single note in the pool. If the doctor said `NOT pneumonia`, your code calls `negation_handler.py` to scan the text. If it finds the word pneumonia, it physically deletes that note from the pool, completely overriding the AI's hallucination.

**The Code Explanation:**
```python
# From: retrieval/hybrid_retriever.py
# 1. Smash the two lists together
pooled = pool_results(bm25_candidates, vector_candidates)

# 2. The Safety Net! Loop through the pooled notes. 
if query.must_exclude:
    # If the doctor said "NOT X", this function strictly deletes any note containing "X"
    pooled, excluded = apply_exclusion_filter(pooled, query.must_exclude)
```

---

## 🧮 2. The Math: Reciprocal Rank Fusion (RRF)
**File you own:** `postprocess/score_fusion.py`

### The Problem
Now that you have a clean, filtered pool of notes, you need to sort them from best to worst. 
But you have a massive mathematical problem:
*   The **Keyword Engine (BM25)** gives scores based on frequency. A score could be `1.5` or it could be `45.2`. It has no maximum limit.
*   The **AI Engine (Vector)** gives scores based on geometry (Cosine Similarity). Its scores are strictly percentages, like `0.85` or `0.92`.

**You cannot add 45.2 to 0.85.** If you try, the Keyword engine will completely overpower the AI engine every single time. 

### How Your Code Fixes It
You use an industry-standard algorithm called **Reciprocal Rank Fusion (RRF)**. 
RRF says: *"Throw away the raw scores! We don't care about 45.2 or 0.85. We only care about the Leaderboard Rank."*

If Note A came in 1st place in the Keyword search, and 3rd place in the AI search, RRF uses a simple fraction formula: `1 / (60 + rank)`. It gives the note points based purely on its ranking position. This perfectly and fairly merges the two completely different search engines.

**The Code Explanation:**
```python
# From: postprocess/score_fusion.py
def fuse_scores(pooled_notes):
    # Loop through the notes and calculate their new Rank Score
    for note in pooled_notes:
        # Get the note's rank (1st, 2nd, 3rd) from the Keyword search
        bm25_rank = note.get("bm25_rank")
        # Get the note's rank from the AI search
        vector_rank = note.get("vector_rank")
        
        # Apply the RRF Formula: 1 / (60 + Rank)
        rrf_score = (1.0 / (60 + bm25_rank)) + (1.0 / (60 + vector_rank))
        
        note["hybrid_score"] = rrf_score
```

---

## ✨ 3. The User Interface: Evidence Extraction
**Files you own:** `postprocess/evidence_extractor.py` and `ui/js/app.js`

### The Problem
Doctors do not trust AI blindly. If your search engine says *"This is the best note,"* the doctor will ask *"Why?"*. You need to prove to them exactly why the AI chose that specific note by highlighting the exact words that matched their query.

### How Your Code Fixes It
Before you send the final JSON data to the web browser, `evidence_extractor.py` scans the text of the winning notes. When it finds the words the doctor searched for (or their synonyms!), it injects hidden tags into the text, like `<<green:myocardial infarction>>`.

When the data arrives at the browser, your Javascript file (`app.js`) intercepts those hidden tags and replaces them with beautiful CSS HTML code: `<span class="hl-green">myocardial infarction</span>`. 

This makes the words light up in bright green on the doctor's screen, instantly building trust because they can visually see exactly why the algorithm made its decision!

**The Code Explanation:**
```javascript
// From: ui/js/app.js
// The browser receives the text: "Patient suffered <<green:myocardial infarction>>."

// Javascript looks for the hidden <<green: >> tags
const regex = /<<green:(.*?)>>/g;

// It replaces them with actual HTML styling so it glows on the screen
formattedText = rawText.replace(regex, '<span class="hl-green">$1</span>');
```
