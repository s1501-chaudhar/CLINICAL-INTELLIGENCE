# clinical_synonyms.py
# Restored strictly for UI Evidence Highlighting purposes!

NEGATION_CUES = [
    "no", "not", "none", "no evidence of", "without", "denies", "negative for", 
    "no history of", "free of", "absent"
]

SYNONYM_DB = {
    "heart attack": ["myocardial infarction", "stemi", "nstemi", "mi"],
    "pneumonia": ["cap", "community acquired pneumonia", "lung infection", "bronchopneumonia", "LRTI"],
    "asthma": ["reactive airway disease", "bronchospasm", "wheezing", "bronchitis"],
    "ibuprofen": ["advil", "motrin", "nsaid", "non-steroidal anti-inflammatory"],
    "hypertension": ["htn", "high blood pressure"],
    "diabetes": ["t2dm", "t1dm", "diabetes mellitus"],
}

def get_synonyms(word: str) -> list[str]:
    """Returns a list of synonyms for a given word."""
    word = word.lower().strip()
    syns = [word]
    for key, values in SYNONYM_DB.items():
        if word == key or word in values:
            syns.append(key)
            syns.extend(values)
    return list(set(syns))
