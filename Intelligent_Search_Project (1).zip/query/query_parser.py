import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery

class QueryParser:
    def parse(self, raw_query: str, top_k: int = 10, **kwargs) -> StructuredQuery:
        """
        Extremely simple parser for student project.
        Understands 'X AND Y', 'X OR Y', 'X NOT Y'.
        Otherwise falls back to semantic intent.
        """
        q = raw_query.strip().lower()
        must_include = []
        or_include = []
        must_exclude = []
        
        # Simple AND split
        if " and " in q:
            parts = q.split(" and ")
            for part in parts:
                part = part.strip()
                if part.startswith("not "):
                    must_exclude.append(part[4:].strip())
                elif " not " in part:
                    sub_parts = part.split(" not ")
                    must_include.append(sub_parts[0].strip())
                    must_exclude.append(sub_parts[1].strip())
                else:
                    must_include.append(part)
                    
        # Simple OR split
        elif " or " in q:
            parts = q.split(" or ")
            for part in parts:
                part = part.strip()
                if part.startswith("not "):
                    must_exclude.append(part[4:].strip())
                elif " not " in part:
                    sub_parts = part.split(" not ")
                    or_include.append(sub_parts[0].strip())
                    must_exclude.append(sub_parts[1].strip())
                else:
                    or_include.append(part)
                    
        # Simple NOT split
        elif " not " in q or q.startswith("not "):
            if q.startswith("not "):
                must_exclude.append(q[4:].strip())
            else:
                parts = q.split(" not ")
                must_include.append(parts[0].strip())
                must_exclude.append(parts[1].strip())
            
        else:
            # Just a regular semantic search
            must_include.append(q)

        # Remove empty strings
        must_include = [t for t in must_include if t]
        or_include = [t for t in or_include if t]
        must_exclude = [t for t in must_exclude if t]

        return StructuredQuery(
            raw_query=raw_query,
            must_include=must_include,
            or_include=or_include,
            must_exclude=must_exclude,
            semantic_intent=raw_query,
            top_k=top_k
        )
