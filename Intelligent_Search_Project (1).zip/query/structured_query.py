from dataclasses import dataclass, field
from enum import Enum

class NegationMode(Enum):
    LITERAL = "literal"
    CLINICAL_CONCEPT = "clinical_concept"

class SearchApproach(Enum):
    KEYWORD = "keyword"
    SEMANTIC = "semantic"
    HYBRID = "hybrid"

@dataclass
class ConceptGroup:
    canonical: str
    synonyms: list[str]

@dataclass
class StructuredQuery:
    """
    The central query object produced by the QueryParser.
    """
    raw_query: str
    must_include: list[str] = field(default_factory=list)
    or_include: list[str] = field(default_factory=list)
    must_exclude: list[str] = field(default_factory=list)
    semantic_intent: str = ""
    top_k: int = 10

    def to_display_dict(self) -> dict:
        return {
            "must_include": self.must_include,
            "or_include": self.or_include,
            "must_exclude": self.must_exclude,
            "semantic_intent": self.semantic_intent,
            "raw_query": self.raw_query,
            "logic": "OR" if self.or_include else "AND",
        }
