import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.bm25_indexer import BM25Indexer
from indexing.vector_indexer import VectorIndexer
from postprocess.score_fusion import fuse_scores, pool_results
from corpus.clinical_synonyms import get_synonyms
from query.negation_handler import apply_exclusion_filter
from query.structured_query import ConceptGroup, NegationMode

class HybridRetriever:
    """
    Very simple hybrid retriever.
    Combines BM25 exact keyword search with FAISS Semantic search.
    """

    def __init__(self):
        self._bm25 = BM25Indexer()
        self._vector_notes = VectorIndexer("notes")
        try:
            self._vector_notes.load()
            self._vector_loaded = True
        except Exception:
            self._vector_loaded = False

    def retrieve(self, query: StructuredQuery, approach: str = "hybrid", mode_str: str = "clinical_concept") -> list[dict]:
        
        # Step 1: Keyword search (BM25)
        bm25_candidates = []
        if approach in ["keyword", "hybrid"]:
            if approach == "keyword":
                terms = query.raw_query.split()
            else:
                terms = query.must_include + query.or_include
                
            # For BM25, we MUST remove 'AND', 'OR', 'NOT' if they somehow sneak in
            # otherwise Whoosh's QueryParser will internally apply boolean logic.
            clean_terms = [t for t in terms if t.upper() not in ("AND", "OR", "NOT")]
            
            if clean_terms:
                bm25_candidates = self._bm25.search_notes(clean_terms, top_k=query.top_k * 3)

        # Step 2: Semantic search (FAISS)
        vector_candidates = []
        if approach in ["semantic", "hybrid"] and self._vector_loaded and query.semantic_intent:
            vector_candidates = self._vector_notes.search(query.semantic_intent, top_k=query.top_k * 3)

        # Step 3: Combine them together
        pooled = pool_results(bm25_candidates, vector_candidates)

        if not pooled:
            return []

        # Step 4: Boolean filters (ONLY FOR HYBRID)
        if approach == "hybrid":
            # AND filter (must_include)
            if query.must_include:
                filtered_and = []
                for note in pooled:
                    text = note.get("text", "").lower()
                    # Check if at least one synonym for each required term is present
                    all_present = True
                    for term in query.must_include:
                        syns = get_synonyms(term)
                        if not any(s.lower() in text for s in syns):
                            all_present = False
                            break
                    if all_present:
                        filtered_and.append(note)
                pooled = filtered_and

            # OR filter (or_include)
            if query.or_include:
                filtered_or = []
                for note in pooled:
                    text = note.get("text", "").lower()
                    any_present = False
                    for term in query.or_include:
                        syns = get_synonyms(term)
                        if any(s.lower() in text for s in syns):
                            any_present = True
                            break
                    if any_present:
                        filtered_or.append(note)
                pooled = filtered_or
                
            # NOT filter (must_exclude) using negation handler
            if query.must_exclude:
                excluded_concepts = [
                    ConceptGroup(canonical=bad_word, synonyms=get_synonyms(bad_word))
                    for bad_word in query.must_exclude
                ]
                
                try:
                    mode_enum = NegationMode(mode_str.lower())
                except ValueError:
                    mode_enum = NegationMode.CLINICAL_CONCEPT
                    
                pooled, _ = apply_exclusion_filter(
                    notes=pooled, 
                    excluded_concepts=excluded_concepts,
                    mode=mode_enum
                )

        # Step 5: Mix the scores and sort
        fused = fuse_scores(pooled)

        return fused[: query.top_k]
