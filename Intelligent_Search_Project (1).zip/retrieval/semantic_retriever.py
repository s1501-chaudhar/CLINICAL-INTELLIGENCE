import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.vector_indexer import VectorIndexer

class SemanticRetriever:
    """
    Pure FAISS semantic search.
    No BM25 keyword search, no boolean filtering.
    """
    def __init__(self):
        self._vector_notes = VectorIndexer("notes")
        try:
            self._vector_notes.load()
            self._vector_loaded = True
        except Exception:
            self._vector_loaded = False

    def retrieve(self, query: StructuredQuery) -> list[dict]:
        top_k = query.top_k if hasattr(query, 'top_k') and query.top_k else 10
        
        results = []
        if self._vector_loaded and query.semantic_intent:
            results = self._vector_notes.search(query.semantic_intent, top_k=top_k)
            
        # Standardize output format
        for note in results:
            note["hybrid_score"] = note.get("vector_score", 0.0)
            note["bm25_score"] = 0.0
            
        return results
