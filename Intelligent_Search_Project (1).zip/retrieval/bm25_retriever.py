import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.bm25_indexer import BM25Indexer

class BM25Retriever:
    """
    Pure BM25 keyword search.
    No synonym expansion, no semantic search, no boolean filtering.
    """
    def __init__(self):
        self._bm25 = BM25Indexer()

    def retrieve(self, query: StructuredQuery) -> list[dict]:
        top_k = query.top_k if hasattr(query, 'top_k') and query.top_k else 10
        
        # Pure lexical search using raw words
        terms = query.raw_query.split()
        
        # Remove boolean operators to avoid whoosh logic confusion
        clean_terms = [t for t in terms if t.upper() not in ("AND", "OR", "NOT")]
        
        results = []
        if clean_terms:
            results = self._bm25.search_notes(clean_terms, top_k=top_k)
            
        # Standardize output format
        for note in results:
            note["hybrid_score"] = note.get("bm25_score", 0.0)
            note["vector_score"] = 0.0
            
        return results
