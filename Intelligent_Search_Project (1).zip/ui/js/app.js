/* ============================================================
   app.js — ClinicalSearch AI v6
   Keyword · Boolean · Semantic · Hybrid · Comparison mode
   Expandable notes · Expandable research · Full note text
   ============================================================ */

const API_BASE = '/api';
const COLORS = ['green', 'blue', 'purple', 'orange', 'teal'];

// ── Theme Management ──────────────────────────────────────────
function initTheme() {
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcon(savedTheme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const newTheme = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  updateThemeIcon(newTheme);
}

function updateThemeIcon(theme) {
  const btn = document.getElementById('theme-toggle');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

document.addEventListener('DOMContentLoaded', initTheme);
initTheme(); // Run immediately as well

// ── State ─────────────────────────────────────────────────────
const state = {
  approach: 'hybrid',
  mode: 'clinical_concept',
  topK: 10,
  includeResearch: true,
  compareOpen: false,
  lastQuery: '',
};

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('search-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') triggerSearch();
  });
  initSidebar();
  initResearchSearch();
});

// ── Sidebar & Navigation ──────────────────────────────────────
async function initSidebar() {
  const el = document.getElementById(id);
  const icon = document.getElementById(id + '-icon');
  if (el.style.display === 'none' || !el.style.display) {
    el.style.display = 'block';
    if(icon) icon.textContent = '▲';
  } else {
    el.style.display = 'none';
    if(icon) icon.textContent = '▼';
  }
}

function showSearchView() {
  document.getElementById('search-view').style.display = 'block';
  document.getElementById('explorer-view').style.display = 'none';
  
  // Update active states
  document.querySelectorAll('.sidebar-nav-item, .sidebar-sub-item').forEach(b => b.classList.remove('active'));
  document.getElementById('nav-search').classList.add('active');
}

// ── Explorer View ───────────────────────────────────────────────
async function loadDataExplorer(e, typeId, typeLabel) {
  document.getElementById('search-view').style.display = 'none';
  document.getElementById('explorer-view').style.display = 'block';
  
  const searchContainer = document.getElementById('research-search-container');
  if (searchContainer) {
    searchContainer.style.display = typeId === 'Medical research' ? 'flex' : 'none';
  }
  
  // Update active states
  document.querySelectorAll('.sidebar-nav-item, .sidebar-sub-item').forEach(b => b.classList.remove('active'));
  if (e && e.currentTarget) {
    e.currentTarget.classList.add('active');
  }
  
  const title = document.getElementById('explorer-title');
  const sub = document.getElementById('explorer-subtitle');
  const grid = document.getElementById('explorer-grid');
  
  grid.innerHTML = '<div class="loading-spinner"></div>';
  
  if (typeId === 'Medical research') {
    title.textContent = 'Medical research';
    sub.textContent = 'Linked literature surfaced alongside matching clinical notes.';
    
    try {
      const res = await fetch(`/api/data/research?limit=10`);
      const data = await res.json();
      grid.innerHTML = data.map(renderResearchCardExplorer).join('');
    } catch(err) {
      grid.innerHTML = '<div class="error">Failed to load research data.</div>';
    }
  } else {
    title.textContent = typeLabel;
    // Map subtypes to subheadings
    const subs = {
      'OPD': 'Outpatient consults',
      'Emergency': 'ER admissions',
      'ICU Progress': 'Ward day-to-day',
      'Discharge Summary': 'End of stay',
      'Nursing': 'Observation logs',
      'Radiology': 'Imaging reads',
      'Referral': 'Specialist handoff'
    };
    sub.textContent = subs[typeId] || 'Clinical records';
    
    try {
      if (typeId === 'Demo Notes') {
        const data = [
          { note_id: 'N-EMR-101', department: 'Emergency', date: '2024-06-01', 
            text: 'Patient complains of severe crushing chest pain radiating to left arm. Suspect __heart attack__.', 
            doctor: 'Dr. Patel', patient_id: 'P-1122' },
          { note_id: 'N-CARD-202', department: 'Cardiology', date: '2024-06-01', 
            text: 'EKG confirms anterior __STEMI__. Rushed to cath lab for emergency PCI.', 
            doctor: 'Dr. Smith', patient_id: 'P-1122' },
          { note_id: 'N-ICU-305', department: 'ICU', date: '2024-06-03', 
            text: 'Patient recovering post-stent placement for __acute myocardial infarction__. Stable.', 
            doctor: 'Dr. Lee', patient_id: 'P-1122' },
          { note_id: 'N-BILL-410', department: 'Billing', date: '2024-06-04', 
            text: 'Coding records updated. Primary diagnosis logged as __ICD-121__.', 
            doctor: 'Dr. Clark', patient_id: 'P-1122' },
          { note_id: 'N-OPD-801', department: 'General', date: '2024-06-10', 
            text: 'Routine follow-up. Patient history shows previous __ICD-121__ event. Prescribed beta-blockers.', 
            doctor: 'Dr. Lee', patient_id: 'P-8888' },
          { note_id: 'N-EMR-802', department: 'Emergency', date: '2024-06-12', 
            text: 'Patient presents with severe shortness of breath. No signs of __MI__. Suspect asthma exacerbation.', 
            doctor: 'Dr. Lee', patient_id: 'P-3333' },
          { note_id: 'N-OPD-901', department: 'Pulmonology', date: '2024-06-15', 
            text: 'Routine follow-up for chronic asthma. Patient reports increased wheezing. No cardiac symptoms.', 
            doctor: 'Dr. Singh', patient_id: 'P-7777' }
        ];
        data.forEach(n => {
           n.highlighted_evidence = [n.text];
        });
        grid.innerHTML = data.map(renderNoteCardExplorer).join('');
      } else {
        const res = await fetch(`/api/data/notes?type=${typeId}&limit=10`);
        const data = await res.json();
        grid.innerHTML = data.map(renderNoteCardExplorer).join('');
      }
    } catch(err) {
      grid.innerHTML = '<div class="error">Failed to load note data.</div>';
    }
  }
}

function renderNoteCardExplorer(note) {

  return `
    <div style="background:rgba(255,255,255,0.72);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(28,34,48,0.06);border-radius:14px;padding:16px 18px;box-shadow:0 6px 24px rgba(28,34,48,0.04);display:flex;flex-direction:column;">
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <div style="display:flex;gap:8px;align-items:baseline;">
          <span style="font-size:13px;font-weight:600;color:#1c2230;">${note.note_id}</span>
          <span style="font-size:12px;color:#a4abb8;">${note.department}</span>
        </div>
        <span style="font-size:11.5px;color:#a4abb8;">${note.date}</span>
      </div>
      <p style="font-size:13.5px;line-height:1.65;color:#3d4456;margin:0 0 10px;">${note.highlighted_evidence ? colorize(note.highlighted_evidence[0]) : note.text}</p>
      <div style="font-size:11px;color:#a4abb8;margin-top:auto;">
        ${note.doctor || 'Dr. Mehta'} · ${note.patient_id || 'P-219'}
      </div>
    </div>
  `;
}

function renderResearchCardExplorer(doc) {
  return `
    <div style="background:rgba(255,255,255,0.72);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(28,34,48,0.06);border-radius:14px;padding:18px 20px;box-shadow:0 6px 24px rgba(28,34,48,0.04);display:flex;flex-direction:column;">
      <div style="font-size:14px;font-weight:600;margin-bottom:4px;color:var(--text-primary);">${doc.title}</div>
      <div style="font-size:11.5px;color:#a4abb8;margin-bottom:10px;">
        ${(doc.authors || []).join(', ')} · ${doc.journal} · ${doc.year}
      </div>
      <p style="font-size:13.5px;line-height:1.65;color:#3d4456;margin:0 0 10px;">${doc.abstract}</p>
    </div>
  `;
}

// ── Control setters ───────────────────────────────────────────
function setApproach(a) {
  state.approach = a;
  ['keyword','hybrid','semantic'].forEach(x =>
    document.getElementById(`btn-${x}`).classList.toggle('active', x === a)
  );
  
  // If there is an active search, re-trigger it with the new approach
  const currentQuery = document.getElementById('search-input').value.trim();
  if (currentQuery && currentQuery === state.lastQuery) {
    triggerSearch();
  }
}

function useExample(query) {
  document.getElementById('search-input').value = query;
  triggerSearch();
}

// ── Search ────────────────────────────────────────────────────
async function triggerSearch() {
  const query = document.getElementById('search-input').value.trim();
  if (!query) return;

  state.topK = 10; // Hardcoded default since UI dropdown was removed
  state.lastQuery = query;
  setLoading(true);
  document.getElementById('empty-state').style.display = 'none';

  try {
    const dynamicMode = (state.approach === 'keyword' || state.approach === 'boolean') ? 'literal' : 'clinical_concept';
    const data = await doSearch(query, state.approach, dynamicMode, state.topK, state.includeResearch);
    render(data);
  } catch (err) {
    renderError(err.message);
  } finally {
    setLoading(false);
  }
}

async function doSearch(query, approach, mode, topK, includeResearch) {
  const res = await fetch(`${API_BASE}/search`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, approach, mode, top_k: topK, include_research: includeResearch }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || 'Search failed');
  }
  return res.json();
}

// ── Old Comparison Mode (Removed) ─────────────────────────────
// Replaced by unified backend endpoint.

// ── Main render ───────────────────────────────────────────────
function render(data) {
  try {
    document.getElementById('results-area').style.display = 'block';

    const count = data.total_results || 0;
    const ms = (data.search_time_ms || 0).toFixed(0);
    document.getElementById('status-text').innerHTML =
      `<strong>${count}</strong> notes · ${ms} ms`;

    const approach = data.approach_used || state.approach;
    const badge = document.getElementById('approach-badge');
    badge.className = `approach-badge approach-${approach}`;
    badge.textContent = approach.toUpperCase();



    const list = document.getElementById('results-list');
    const noR  = document.getElementById('no-results');
    list.innerHTML = '';
    if (!data.matching_notes || data.matching_notes.length === 0) {
      noR.style.display = 'block';
    } else {
      noR.style.display = 'none';
      data.matching_notes.forEach((note, i) => {
        list.appendChild(buildNoteCard(note, i));
      });
    }

    renderResearch(data.research_results || []);
  } catch (e) {
    console.error('Render error:', e);
    document.getElementById('results-list').innerHTML =
      `<div style="padding:16px;color:var(--c-red)">⚠️ Render Error: ${esc(e.message)}</div>`;
  }
}





// ── Note card (expandable) ────────────────────────────────────
function buildNoteCard(note, index) {

  const delay      = Math.min(index * 0.04, 0.3);
  const fullText   = note.highlighted_text || note.text || '';

  const card = document.createElement('div');
  card.className = 'note-card expanded';
  card.style.animationDelay = `${delay}s`;

  card.innerHTML = `
    <div class="note-header" onclick="toggleNote(this.parentElement)">
      <div>
        <div class="note-ids">
          <div class="note-id">${esc(note.note_id)}</div>
          <div class="note-patient">Patient ${esc(note.patient_id || '—')}</div>
        </div>
        <div class="note-meta-tags" style="margin-top:5px;">
          ${note.note_type   ? `<span class="meta-tag">${esc(note.note_type)}</span>`   : ''}
          ${note.department  ? `<span class="meta-tag">${esc(note.department)}</span>`  : ''}
          ${note.date        ? `<span class="meta-tag">${esc(note.date)}</span>`        : ''}
          ${note.doctor      ? `<span class="meta-tag">👨‍⚕️ ${esc(note.doctor)}</span>`  : ''}
        </div>
      </div>
      <div class="note-right">
        <div class="expand-icon">▼</div>
      </div>
    </div>

    <div class="note-body">
      ${fullText ? `
        <div style="margin-top:10px;">
          <div class="note-full-text-label">📄 Full Note Text</div>
          <div class="note-full-text">${colorize(fullText)}</div>
        </div>
      ` : ''}

    </div>
  `;

  return card;
}

function toggleNote(card) {
  card.classList.toggle('expanded');
}



// ── Color marker parser ───────────────────────────────────────
function colorize(text) {
  if (!text) return '';
  const VALID_COLORS = new Set(['green','blue','purple','orange','teal','light','light-blue']);
  const spans = [];
  const PLACEHOLDER = i => `CLRSPAN${i}ENDSPAN`;

  let t = text.replace(/<<([\w-]+):\s*([^>]*?)\s*>>/g, (_, color, term) => {
    const cls = VALID_COLORS.has(color) ? `hl-${color}` : 'hl-green';
    const i = spans.length;
    spans.push(`<span class="${cls}">${esc(term)}</span>`);
    return PLACEHOLDER(i);
  });

  t = t.replace(/\*\*([^*]+)\*\*/g, (_, term) => {
    const i = spans.length;
    spans.push(`<span class="hl-green">${esc(term)}</span>`);
    return PLACEHOLDER(i);
  });

  t = t.replace(/__([^_]+)__/g, (_, term) => {
    const i = spans.length;
    spans.push(`<span style="font-weight: 500; color: #4b5563; background: #f3f4f6; padding: 2px 4px; border-radius: 4px;">${esc(term)}</span>`);
    return PLACEHOLDER(i);
  });

  let safe = esc(t);
  for (let i = 0; i < spans.length; i++) {
    safe = safe.replace(esc(PLACEHOLDER(i)), spans[i]);
  }
  return safe;
}

function formatWhyMatched(text) {
  if (!text) return '';
  return esc(text).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
}

// ── Research panel (expandable) ───────────────────────────────
function renderResearch(abstracts) {
  const panel = document.getElementById('side-panel');
  const body = document.getElementById('research-body');
  const countEl = document.getElementById('research-count');
  
  if (!panel || !body) return;

  if (!abstracts || abstracts.length === 0) {
    panel.style.display = 'none';
    body.innerHTML = `<p style="font-size:11px;color:var(--text-muted);padding:4px;">No research abstracts matched.</p>`;
    if (countEl) countEl.textContent = '';
    return;
  }
  
  panel.style.display = 'block';
  if (countEl) countEl.textContent = `${abstracts.length} found`;

  body.innerHTML = abstracts.map((ab, i) => {

    const abstract = ab.highlighted_abstract || ab.abstract || ab.text || ab.why_relevant || '';
    
    return `
      <div class="research-item expanded" onclick="toggleResearch(this)" style="animation-delay:${i * 0.05}s">
        <div class="research-item-header">
          <div class="research-title">${esc(ab.title)}</div>
          <div class="research-expand-icon">▼</div>
        </div>
        <div class="research-meta">
          <span class="research-meta-tag">📖 ${esc(ab.journal || ab.source || 'Dataset')}</span>
          ${ab.year ? `<span class="research-meta-tag">${ab.year}</span>` : ''}
        </div>
        ${ab.why_relevant ? `<div class="research-why">💡 ${esc(ab.why_relevant)}</div>` : ''}
        ${abstract ? `<div class="research-body-text">${colorize(abstract)}</div>` : ''}
      </div>
    `;
  }).join('');
}

function toggleResearch(item) {
  item.classList.toggle('expanded');
}

// ── Stats panel ───────────────────────────────────────────────
function renderStats(data) {
  const interp = data.interpreted_query || {};
  document.getElementById('stats-body').innerHTML = `
    <div class="stat-row"><span class="stat-key">Notes found</span><span class="stat-val">${data.total_results}</span></div>
    <div class="stat-row"><span class="stat-key">Research</span><span class="stat-val">${data.total_research || 0}</span></div>
    <div class="stat-row"><span class="stat-key">Latency</span><span class="stat-val">${(data.search_time_ms || 0).toFixed(1)} ms</span></div>
    <div class="stat-row"><span class="stat-key">Approach</span><span class="stat-val">${(data.approach_used || '—').toUpperCase()}</span></div>
    <div class="stat-row"><span class="stat-key">Negation</span><span class="stat-val">${(interp.mode || '—').replace('_',' ')}</span></div>
    <div class="stat-row"><span class="stat-key">AND concepts</span><span class="stat-val">${(interp.must_include || []).length}</span></div>
    <div class="stat-row"><span class="stat-key">OR concepts</span><span class="stat-val">${(interp.or_include || []).length}</span></div>
    <div class="stat-row"><span class="stat-key">Excluded</span><span class="stat-val">${(interp.must_exclude || []).length}</span></div>
  `;
}

// ── JSON panel ────────────────────────────────────────────────
function renderJsonPanel(interp) {
  const pre = document.getElementById('json-preview');
  if (!interp) { pre.textContent = ''; return; }
  pre.textContent = JSON.stringify({
    must_include: interp.must_include,
    or_include:   interp.or_include,
    must_exclude: interp.must_exclude,
    mode:         interp.mode,
    approach:     interp.approach,
  }, null, 2);
}

// ── Error state ───────────────────────────────────────────────
function renderError(msg) {
  document.getElementById('results-area').style.display = 'block';
  document.getElementById('results-list').innerHTML = `
    <div style="background:rgba(248,81,73,.07);border:1px solid rgba(248,81,73,.25);
      border-radius:var(--radius-lg);padding:20px;color:var(--c-red);font-size:13px;">
      <strong>⚠️ Search Error</strong><br/>
      <span style="color:var(--text-secondary);font-size:12px;display:block;margin-top:6px;">
        ${esc(msg)}<br/><br/>
        Server: <code style="font-family:monospace">uvicorn api.main:app --reload</code>
      </span>
    </div>
  `;
  document.getElementById('no-results').style.display = 'none';
  document.getElementById('negation-info').style.display = 'none';
}

// ── Loading ───────────────────────────────────────────────────
function setLoading(on) {
  const btn = document.getElementById('search-btn');
  btn.disabled = on;
  btn.innerHTML = on ? '⏳ Searching…' : '⚡ Search';
  document.getElementById('loading-state').style.display = on ? 'flex' : 'none';
  if (on) document.getElementById('results-area').style.display = 'none';
}

// ── Helpers ───────────────────────────────────────────────────
function esc(s) {
  if (!s) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}



function initResearchSearch() {
  const input = document.getElementById('research-search-input');
  const btn = document.getElementById('research-search-btn');
  if (!input || !btn) return;
  
  const doSearch = async () => {
    const query = input.value.trim();
    if (!query) return;
    
    const grid = document.getElementById('explorer-grid');
    grid.innerHTML = '<div class="loading-spinner"></div>';
    
    try {
      const res = await fetch(`${API_BASE}/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query,
          mode: 'clinical_concept',
          approach: 'hybrid',
          top_k: 10,
          include_research: true
        })
      });
      if (!res.ok) throw new Error('API Error');
      const data = await res.json();
      
      if (data.research_results && data.research_results.length > 0) {
        grid.innerHTML = data.research_results.map(renderResearchCardExplorer).join('');
      } else {
        grid.innerHTML = '<div class="no-results" style="display:block; text-align:center; padding: 40px; color: var(--text-secondary);">🔍 No matching research found.</div>';
      }
    } catch (err) {
      grid.innerHTML = '<div class="error" style="text-align:center; padding: 20px; color: var(--danger-color);">Error searching research.</div>';
      console.error(err);
    }
  };
  
  btn.addEventListener('click', doSearch);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') doSearch();
  });
}
