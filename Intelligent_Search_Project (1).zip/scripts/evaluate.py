from __future__ import annotations
import sys
import json
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from query.query_parser import QueryParser
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.bm25_retriever import BM25Retriever
from retrieval.semantic_retriever import SemanticRetriever
from query.structured_query import SearchApproach, NegationMode

# --- GOLDEN DATASET ---
# A small set of test queries mapped to the exact Note IDs they SHOULD return.
# In a real-world scenario, this dataset would be manually curated by doctors (50-100 queries).
GOLDEN_DATASET = [
    {
        "query": "chronic kidney disease",
        "expected_notes": ["N-571", "N-788"],
        "description": "Standard medical concept"
    },
    {
        "query": "heart attack",
        "expected_notes": ["N-690", "N-414", "N-914"],
        "description": "Semantic catches myocardial infarction (N-414, N-914) that Keyword misses, Hybrid gets both."
    },
    {
        "query": "asthma NOT pneumonia",
        "expected_notes": ["N-679"],
        "description": "Semantic fails to respect the NOT operator and returns pneumonia cases at rank 1. Hybrid explicitly filters them out, jumping to perfect MRR."
    }
]

def calculate_metrics(results: list[dict], expected: list[str], k: int = 10) -> tuple[float, float, float]:
    """Calculates Precision@K, Recall@K, and MRR."""
    if not expected:
        return 0.0, 0.0, 0.0

    top_k_ids = [r.get("note_id") for r in results[:k]]
    
    # True Positives in top K
    tp = sum(1 for note_id in top_k_ids if note_id in expected)
    
    precision = tp / k if k > 0 else 0.0
    recall = tp / len(expected)
    
    # MRR calculation
    mrr = 0.0
    for rank, note_id in enumerate(top_k_ids, 1):
        if note_id in expected:
            mrr = 1.0 / rank
            break
            
    return precision, recall, mrr

def run_evaluation():
    output_lines = []
    
    def log(msg):
        print(msg)
        output_lines.append(msg)
        
    log("=" * 60)
    log("INTELLIGENT CLINICAL SEARCH EVALUATION SUITE")
    log("=" * 60)
    
    retriever_hybrid = HybridRetriever()
    retriever_keyword = BM25Retriever()
    retriever_semantic = SemanticRetriever()
    
    approaches = [
        ("Keyword (BM25)", SearchApproach.KEYWORD),
        ("Semantic (FAISS)", SearchApproach.SEMANTIC),
        ("Hybrid Search", SearchApproach.HYBRID)
    ]
    
    for approach_name, approach_enum in approaches:
        log(f"\nEvaluating: {approach_name}")
        log("-" * 40)
        
        total_p = 0.0
        total_r = 0.0
        total_mrr = 0.0
        
        for item in GOLDEN_DATASET:
            q_text = item["query"]
            expected = item["expected_notes"]
            
            # Parse query (QueryParser parse doesn't take approach)
            structured_query = QueryParser().parse(q_text, top_k=10)
            
            # Retrieve using the exact correct retriever
            if approach_enum == SearchApproach.KEYWORD:
                results = retriever_keyword.retrieve(structured_query)
            elif approach_enum == SearchApproach.SEMANTIC:
                results = retriever_semantic.retrieve(structured_query)
            else:
                results = retriever_hybrid.retrieve(structured_query, approach="hybrid")
                
            p, r, mrr = calculate_metrics(results, expected, k=5)
            log(f"    Query: '{q_text}' -> MRR: {mrr:.2f}")
            
            total_p += p
            total_r += r
            total_mrr += mrr
            
        n = len(GOLDEN_DATASET)
        avg_p = total_p / n
        avg_r = total_r / n
        avg_mrr = total_mrr / n
        
        # F1 Score
        if avg_p + avg_r == 0:
            f1 = 0.0
        else:
            f1 = 2 * (avg_p * avg_r) / (avg_p + avg_r)
            
        log(f"Metrics (Average over {n} queries):")
        log(f"  Precision@5 : {avg_p:.2f}")
        log(f"  Recall@5    : {avg_r:.2f}")
        log(f"  MRR         : {avg_mrr:.2f}")
        log(f"  F1-Score    : {f1:.2f}")
        
    # Write to evaluate.md
    md_path = Path(__file__).parent.parent / "evaluate.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("```text\n")
        f.write("\n".join(output_lines))
        f.write("\n```\n")
    print(f"\n✅ Evaluation results successfully saved to {md_path.absolute()}")

if __name__ == "__main__":
    run_evaluation()
