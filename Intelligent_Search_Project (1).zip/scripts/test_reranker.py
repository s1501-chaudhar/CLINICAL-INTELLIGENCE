import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import config.settings
config.settings.USE_CROSS_ENCODER = True

from query.query_parser import QueryParser
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.reranker import CrossEncoderReranker

def main():
    query_str = "heart attack"

    parser = QueryParser()
    hybrid_retriever = HybridRetriever()
    reranker = CrossEncoderReranker()

    if not reranker.enabled:
        print("Reranker failed to enable.")
        sys.exit(1)

    structured_query = parser.parse(query_str, top_k=10)
    notes = hybrid_retriever.retrieve(structured_query, approach="hybrid")

    print(f"\n{'='*60}\nBEFORE RERANKING\n{'='*60}")
    for i, n in enumerate(notes):
        print(f"{i+1:2d}. [{n['note_id']}] Score: {n.get('hybrid_score', 0):.4f} | {n.get('text', '')[:60].strip()}...")

    notes_reranked = reranker.rerank(structured_query, list(notes))

    print(f"\n{'='*60}\nAFTER CROSS-ENCODER RERANKING\n{'='*60}")
    for i, n in enumerate(notes_reranked):
        ce_score = n.get('cross_encoder_score', 0.0)
        print(f"{i+1:2d}. [{n['note_id']}] Score: {n.get('hybrid_score', 0):.4f} (CE: {ce_score:.4f}) | {n.get('text', '')[:60].strip()}...")

if __name__ == "__main__":
    main()
