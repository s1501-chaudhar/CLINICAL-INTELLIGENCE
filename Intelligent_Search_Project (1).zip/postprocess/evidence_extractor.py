import re
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from corpus.clinical_synonyms import get_synonyms

COLOR_NAMES = ["green", "blue", "purple", "orange", "teal"]

def _sentence_split(text: str) -> list[str]:
    text = re.sub(r'(Dr|Mr|Mrs|Ms|Prof|No|Hx|Dx|Rx|vs|i\.e|e\.g|Fig|approx|Approx)\.', lambda m: m.group(0).replace('.', '<!DOT!>'), text)
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text)
    return [s.replace('<!DOT!>', '.').strip() for s in sentences if s.strip()]

def _highlight_term(sentence: str, term: str, color: str) -> str:
    term = ' '.join(term.strip().split())
    pattern = re.compile(r'\b' + re.escape(term) + r'\b', re.IGNORECASE)
    return pattern.sub(lambda m: f"<<{color}:{m.group(0)}>>", sentence)

def annotate_results_with_evidence(results: list[dict], query: StructuredQuery, approach: str = "hybrid", max_snippets: int = 3) -> list[dict]:
    annotated = []
    
    # Primary terms from query
    primary_terms = list(query.must_include) + list(query.or_include)
    
    # Expand with synonyms for highlighting purposes ONLY if not dumb keyword
    expanded_terms = []
    if approach != "keyword":
        for term in primary_terms:
            expanded_terms.extend(get_synonyms(term))
            
        if not expanded_terms and query.semantic_intent:
            words = [w for w in query.semantic_intent.split() if len(w) > 3]
            for w in words:
                expanded_terms.extend(get_synonyms(w))
            
    # Sort by length descending to prevent sub-string tagging
    expanded_terms = sorted(list(set(expanded_terms)), key=len, reverse=True)
    fallback_terms = [w for w in query.raw_query.split() if len(w) > 3]
        
    for note in results:
        note = dict(note)
        text = note.get("text", "")
        text_lower = text.lower()
        
        highlighted_full_text = text
        evidence_snippets = []
        matched_terms = []
        
        # 1. Highlight semantic synonym exact matches
        for idx, term in enumerate(expanded_terms):
            if term.lower() in text_lower:
                # Don't double tag
                if not any(term.lower() in applied.lower() for applied in matched_terms):
                    color = COLOR_NAMES[idx % len(COLOR_NAMES)]
                    highlighted_full_text = _highlight_term(highlighted_full_text, term, color)
                    matched_terms.append(term)
                
        # 2. Fallback to individual word highlights
        if not matched_terms:
            for idx, term in enumerate(fallback_terms):
                if term.lower() in text_lower:
                    if not any(term.lower() in applied.lower() for applied in matched_terms):
                        color = COLOR_NAMES[idx % len(COLOR_NAMES)]
                        highlighted_full_text = _highlight_term(highlighted_full_text, term, color)
                        matched_terms.append(term)
                
        note["highlighted_text"] = highlighted_full_text
        
        # Extract snippets
        sentences = _sentence_split(text)
        for sent in sentences:
            sent_lower = sent.lower()
            sent_highlighted = sent
            sent_matched = []
            
            terms_to_search = matched_terms if matched_terms else fallback_terms
            
            for idx, term in enumerate(terms_to_search):
                if term.lower() in sent_lower:
                    color = COLOR_NAMES[idx % len(COLOR_NAMES)]
                    sent_highlighted = _highlight_term(sent_highlighted, term, color)
                    sent_matched.append(term)
                    
            if sent_matched:
                evidence_snippets.append({
                    "snippet": sent,
                    "highlighted_snippet": sent_highlighted,
                    "matched_terms": sent_matched,
                    "concepts": sent_matched
                })
                
            if len(evidence_snippets) >= max_snippets:
                break
                
        if not evidence_snippets and sentences:
            first_sent = sentences[0].strip()
            evidence_snippets = [{
                "snippet": first_sent,
                "highlighted_snippet": first_sent,
                "matched_terms": [],
                "concepts": []
            }]
            
        note["matched_evidence"] = [e["snippet"] for e in evidence_snippets]
        note["highlighted_evidence"] = [e["highlighted_snippet"] for e in evidence_snippets]
        
        if matched_terms:
            if approach == "keyword":
                note["why_matched"] = f"Keyword match found for: {', '.join(matched_terms)}"
            else:
                note["why_matched"] = f"Semantic match found for: {', '.join(matched_terms)}"
        else:
            note["why_matched"] = "Matched via AI Semantic Similarity."
            
        annotated.append(note)
        
    return annotated
