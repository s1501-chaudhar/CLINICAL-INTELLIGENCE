def pool_results(bm25_results: list[dict], vector_results: list[dict]) -> list[dict]:
    """Combines results from BM25 and FAISS, merging scores if the item is in both."""
    pooled = {}

    for item in bm25_results:
        item_id = item.get("note_id") or item.get("abstract_id")
        if item_id:
            pooled[item_id] = dict(item)
            pooled[item_id]["vector_score"] = 0.0

    for item in vector_results:
        item_id = item.get("note_id") or item.get("abstract_id")
        if item_id:
            if item_id in pooled:
                pooled[item_id]["vector_score"] = item.get("vector_score", 0.0)
            else:
                merged = dict(item)
                merged["bm25_score"] = 0.0
                pooled[item_id] = merged

    return list(pooled.values())

def fuse_scores(results: list[dict]) -> list[dict]:
    """Normalizes BM25 and Vector scores to 0-1 range and adds them."""
    if not results:
        return []

    # Calculate min/max for BM25
    bm25_scores = [r.get("bm25_score", 0.0) for r in results]
    min_bm25, max_bm25 = min(bm25_scores), max(bm25_scores)
    
    # Calculate min/max for Vector
    vector_scores = [r.get("vector_score", 0.0) for r in results]
    min_vec, max_vec = min(vector_scores), max(vector_scores)

    fused = []
    for result in results:
        result = dict(result)
        
        # Normalize BM25
        b_score = result.get("bm25_score", 0.0)
        if max_bm25 > min_bm25:
            norm_bm25 = (b_score - min_bm25) / (max_bm25 - min_bm25)
        else:
            norm_bm25 = 0.5 if max_bm25 > 0 else 0.0
            
        # Normalize Vector
        v_score = result.get("vector_score", 0.0)
        if max_vec > min_vec:
            norm_vec = (v_score - min_vec) / (max_vec - min_vec)
        else:
            norm_vec = 0.5 if max_vec > 0 else 0.0
            
        result["hybrid_score"] = norm_bm25 + norm_vec
        fused.append(result)

    fused.sort(key=lambda x: -x["hybrid_score"])
    return fused
