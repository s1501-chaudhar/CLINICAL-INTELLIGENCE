import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from postprocess.evidence_extractor import annotate_results_with_evidence

def format_response(
    query: StructuredQuery,
    notes: list[dict],
    research: list[dict],
    search_time_ms: float = 0.0,
    approach_used: str = "hybrid",
) -> dict:
    
    # Annotate notes and research with highlights
    annotated_notes = annotate_results_with_evidence(notes, query, approach_used)
    
    for ab in research:
        ab["text"] = ab.get("abstract", "")
    annotated_research = annotate_results_with_evidence(research, query, approach_used)

    # Format notes
    formatted_notes = []
    for note in annotated_notes:
        formatted_notes.append({
            "note_id":              note.get("note_id", ""),
            "patient_id":           note.get("patient_id", ""),
            "note_type":            note.get("note_type", ""),
            "department":           note.get("department", ""),
            "doctor":               note.get("doctor", ""),
            "date":                 note.get("date", ""),
            "text":                 note.get("text", ""),
            "highlighted_text":     note.get("highlighted_text", ""),
            "score":                round(note.get("hybrid_score", 0.0), 4),
            "bm25_score":           round(note.get("bm25_score", 0.0), 4),
            "vector_score":         round(note.get("vector_score", 0.0), 4),
            "matched_evidence":     note.get("matched_evidence", []),
            "highlighted_evidence": note.get("highlighted_evidence", []),
            "why_matched":          note.get("why_matched", ""),
        })

    # Format research
    formatted_research = []
    for ab in annotated_research:
        formatted_research.append({
            "abstract_id":    ab.get("abstract_id", ""),
            "title":          ab.get("title", ""),
            "journal":        ab.get("journal", ""),
            "year":           ab.get("year", ""),
            "source":         ab.get("source", "Synthetic PubMed Dataset"),
            "doi":            ab.get("doi", ""),
            "abstract":       ab.get("abstract", ""),
            "highlighted_abstract": ab.get("highlighted_text", ""),
            "matched_evidence":     ab.get("matched_evidence", []),
            "highlighted_evidence": ab.get("highlighted_evidence", []),
            "relevance_score":      round(ab.get("vector_score", ab.get("bm25_score", 0.0)), 4),
            "why_relevant":         ab.get("why_matched", ""),
        })

    return {
        "interpreted_query": query.to_display_dict(),
        "matching_notes": formatted_notes,
        "research_results": formatted_research,
        "total_results": len(formatted_notes),
        "total_research": len(formatted_research),
        "search_time_ms": round(search_time_ms, 1),
        "approach_used": approach_used,
    }
