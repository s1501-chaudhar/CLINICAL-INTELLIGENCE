import os
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent

# Embedding Model
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# Reranking Settings (Bug 5)
OPENAI_API_KEY = ""
OPENROUTER_API_KEY = ""
USE_LLM_RERANKER = False
USE_CROSS_ENCODER = False
CROSS_ENCODER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"

# File Paths
NOTES_DATA_PATH = ROOT_DIR / "data" / "raw" / "clinical_notes"
RESEARCH_DATA_PATH = ROOT_DIR / "data" / "raw" / "research_abstracts"

FAISS_NOTES_INDEX_PATH = ROOT_DIR / "indexing" / "index_store" / "faiss" / "notes"
BM25_NOTES_INDEX_PATH = ROOT_DIR / "indexing" / "index_store" / "bm25" / "notes"

FAISS_RESEARCH_INDEX_PATH = ROOT_DIR / "indexing" / "index_store" / "faiss" / "research"
BM25_RESEARCH_INDEX_PATH = ROOT_DIR / "indexing" / "index_store" / "bm25" / "research"

# Ensure directories exist
FAISS_NOTES_INDEX_PATH.mkdir(parents=True, exist_ok=True)
BM25_NOTES_INDEX_PATH.mkdir(parents=True, exist_ok=True)
FAISS_RESEARCH_INDEX_PATH.mkdir(parents=True, exist_ok=True)
BM25_RESEARCH_INDEX_PATH.mkdir(parents=True, exist_ok=True)
