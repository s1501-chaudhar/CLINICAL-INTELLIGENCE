"""
request_models.py
=================
Pydantic request schemas for the search API.
"""

# pyrefly: ignore [missing-import]
from pydantic import BaseModel, Field
from typing import Optional


class SearchRequest(BaseModel):
    query: str = Field(..., description="Natural language or Boolean query string", min_length=2)
    approach: str = Field(
        default="hybrid",
        description="Search approach: 'keyword', 'boolean', 'semantic', or 'hybrid'",
        pattern="^(keyword|boolean|semantic|hybrid)$",
    )
    mode: str = Field(
        default="clinical_concept",
        description="Negation mode: 'literal' or 'clinical_concept'",
        pattern="^(literal|clinical_concept)$",
    )
    top_k: int = Field(default=10, ge=1, le=50, description="Max results to return")
    include_research: bool = Field(
        default=True, description="Whether to include research abstract results"
    )
    use_reranker: bool = Field(default=False, description="Enable cross-encoder reranking (opt-in, off by default)")

    model_config = {"json_schema_extra": {
        "examples": [
            {
                "query": "pneumonia AND ibuprofen",
                "approach": "hybrid",
                "mode": "clinical_concept",
                "top_k": 10,
                "include_research": True,
            }
        ]
    }}
