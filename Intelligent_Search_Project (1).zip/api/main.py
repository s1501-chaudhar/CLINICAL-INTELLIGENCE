import sys
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

sys.path.insert(0, str(Path(__file__).parent.parent))

from api.routes.search import router as search_router
from api.routes.data import router as data_router

app = FastAPI(title="Student Project API")
app.include_router(search_router, prefix="/api")
app.include_router(data_router, prefix="/api/data")

# Serve the frontend UI
UI_DIR = Path(__file__).parent.parent / "ui"
if UI_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(UI_DIR)), name="static")

    @app.get("/")
    async def serve_ui():
        return FileResponse(str(UI_DIR / "index.html"))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.main:app", host="0.0.0.0", port=8000, reload=True)
