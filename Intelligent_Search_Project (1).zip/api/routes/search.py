import time
import sys
from pathlib import Path
from fastapi import APIRouter

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from api.models.request_models import SearchRequest
from query.query_parser import QueryParser
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.bm25_retriever import BM25Retriever
from retrieval.semantic_retriever import SemanticRetriever
from research.research_retriever import ResearchRetriever
from postprocess.result_formatter import format_response
from retrieval.reranker import LLMReranker, CrossEncoderReranker

router = APIRouter()

# Instantiate singletons
_parser = QueryParser()
_hybrid_retriever = HybridRetriever()
_bm25_retriever = BM25Retriever()
_semantic_retriever = SemanticRetriever()
_research_retriever = ResearchRetriever()
_llm_reranker = LLMReranker()
_cross_encoder_reranker = CrossEncoderReranker()

@router.post("/search")
async def search(req: SearchRequest) -> dict:
    t0 = time.perf_counter()

    # 1. Parse the query
    structured_query = _parser.parse(req.query, top_k=req.top_k)

    # 2. Search using correct Retriever based on approach
    if req.approach == "keyword":
        notes = _bm25_retriever.retrieve(structured_query)
    elif req.approach == "semantic":
        notes = _semantic_retriever.retrieve(structured_query)
    else:
        # Default to hybrid
        notes = _hybrid_retriever.retrieve(
            structured_query, 
            approach="hybrid",
            mode_str=req.mode
        )

    # Optional Reranking
    if _cross_encoder_reranker.enabled and req.use_reranker:
        notes = _cross_encoder_reranker.rerank(structured_query, notes)
    if _llm_reranker.enabled:
        notes = _llm_reranker.rerank(structured_query, notes)

    # 3. Search Research
    research = []
    if req.include_research:
        research = _research_retriever.retrieve(structured_query, approach=req.approach)

    elapsed_ms = (time.perf_counter() - t0) * 1000

    # 4. Format and return exactly as the UI expects (with highlights!)
    return format_response(
        query=structured_query,
        notes=notes,
        research=research,
        search_time_ms=elapsed_ms,
        approach_used=req.approach
    )

@router.get("/health")
async def health() -> dict:
    return {"status": "ok", "service": "Intelligent Clinical Search"}

