import json
import os
import sys
from pathlib import Path

# Fix import path
sys.path.insert(0, str(Path(__file__).parent.parent))

from whoosh import index
from whoosh.fields import Schema, TEXT, ID
from whoosh.qparser import QueryParser

from config.settings import BM25_NOTES_INDEX_PATH, NOTES_DATA_PATH
from config.settings import BM25_RESEARCH_INDEX_PATH, RESEARCH_DATA_PATH

class BM25Indexer:
    def __init__(self):
        self.notes_index_path = BM25_NOTES_INDEX_PATH
        self.research_index_path = BM25_RESEARCH_INDEX_PATH
        
        # Simple schemas
        self.notes_schema = Schema(
            note_id=ID(stored=True, unique=True),
            text=TEXT(stored=True)
        )
        self.research_schema = Schema(
            abstract_id=ID(stored=True, unique=True),
            title=TEXT(stored=True),
            abstract=TEXT(stored=True)
        )

    def index_exists(self, index_type: str) -> bool:
        if index_type == "notes":
            return index.exists_in(str(self.notes_index_path))
        elif index_type == "research":
            return index.exists_in(str(self.research_index_path))
        return False

    def build_notes_index(self):
        print("Building BM25 Notes Index...")
        notes_file = Path(NOTES_DATA_PATH) / "notes.json"
        with open(notes_file) as f:
            notes = json.load(f)

        self.notes_index_path.mkdir(parents=True, exist_ok=True)
        ix = index.create_in(str(self.notes_index_path), self.notes_schema)
        writer = ix.writer()

        for note in notes:
            writer.add_document(
                note_id=note["note_id"],
                text=note["text"]
            )
        writer.commit()
        print("BM25 Notes Index Built!")

    def build_research_index(self):
        print("Building BM25 Research Index...")
        research_file = Path(RESEARCH_DATA_PATH) / "abstracts.json"
        if not research_file.exists():
            print("No research data found.")
            return
            
        with open(research_file) as f:
            abstracts = json.load(f)

        self.research_index_path.mkdir(parents=True, exist_ok=True)
        ix = index.create_in(str(self.research_index_path), self.research_schema)
        writer = ix.writer()

        for ab in abstracts:
            writer.add_document(
                abstract_id=ab["abstract_id"],
                title=ab["title"],
                abstract=ab["abstract"]
            )
        writer.commit()
        print("BM25 Research Index Built!")

    def search_notes(self, terms: list[str], top_k: int = 50) -> list[dict]:
        if not index.exists_in(str(self.notes_index_path)):
            return []

        ix = index.open_dir(str(self.notes_index_path))
        with ix.searcher() as searcher:
            query_string = " OR ".join(terms)
            parser = QueryParser("text", ix.schema)
            q = parser.parse(query_string)
            results = searcher.search(q, limit=top_k)

            return [
                {
                    "note_id": r["note_id"],
                    "text": r["text"],
                    "bm25_score": float(r.score)
                }
                for r in results
            ]

    def search_research(self, terms: list[str], top_k: int = 50) -> list[dict]:
        if not index.exists_in(str(self.research_index_path)):
            return []

        ix = index.open_dir(str(self.research_index_path))
        with ix.searcher() as searcher:
            query_string = " OR ".join(terms)
            parser = QueryParser("abstract", ix.schema)
            q = parser.parse(query_string)
            results = searcher.search(q, limit=top_k)

            return [
                {
                    "abstract_id": r["abstract_id"],
                    "title": r.get("title", ""),
                    "abstract": r["abstract"],
                    "bm25_score": float(r.score)
                }
                for r in results
            ]

if __name__ == "__main__":
    indexer = BM25Indexer()
    indexer.build_notes_index()
    indexer.build_research_index()
