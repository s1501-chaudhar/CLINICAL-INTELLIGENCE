import json
import pickle
# pyrefly: ignore [missing-import]
import numpy as np
# pyrefly: ignore [missing-import]
import faiss
# pyrefly: ignore [missing-import]
from sentence_transformers import SentenceTransformer
from pathlib import Path
import sys

# Setup paths
sys.path.insert(0, str(Path(__file__).parent.parent))
from config.settings import EMBEDDING_MODEL
from config.settings import FAISS_NOTES_INDEX_PATH, NOTES_DATA_PATH
from config.settings import FAISS_RESEARCH_INDEX_PATH, RESEARCH_DATA_PATH

class VectorIndexer:
    def __init__(self, index_type: str = "notes"):
        self.index_type = index_type
        if index_type == "notes":
            self.index_path = FAISS_NOTES_INDEX_PATH
            self.data_file = Path(NOTES_DATA_PATH) / "notes.json"
        else:
            self.index_path = FAISS_RESEARCH_INDEX_PATH
            self.data_file = Path(RESEARCH_DATA_PATH) / "abstracts.json"
            
        self.index_path.mkdir(parents=True, exist_ok=True)
        
        self.faiss_index = None
        self.metadata = []
        
        # Load the AI Model that turns text into numbers
        self.model = SentenceTransformer(EMBEDDING_MODEL)

    def index_exists(self) -> bool:
        return (self.index_path / "faiss_index.bin").exists()

    def build(self):
        """Step 1 & 2: Convert text into embeddings and store in FAISS."""
        print(f"Loading {self.index_type} data...")
        if not self.data_file.exists():
            print(f"Data file {self.data_file} not found.")
            return
            
        with open(self.data_file) as f:
            data = json.load(f)
            
        if self.index_type == "notes":
            texts = [item["text"] for item in data]
        else:
            texts = [item["title"] + " " + item["abstract"] for item in data]
        
        print("Step 1: Converting to embeddings (this takes a moment)...")
        embeddings = self.model.encode(texts, normalize_embeddings=True)
        
        print("Step 2: Storing embeddings in FAISS...")
        dim = embeddings.shape[1]
        self.faiss_index = faiss.IndexFlatIP(dim)
        self.faiss_index.add(embeddings.astype(np.float32))
        self.metadata = data
        
        faiss.write_index(self.faiss_index, str(self.index_path / "faiss_index.bin"))
        with open(self.index_path / "metadata.pkl", "wb") as f:
            pickle.dump(self.metadata, f)
            
        print(f"FAISS database for {self.index_type} successfully built!")

    def load(self):
        """Loads the FAISS database from the hard drive into memory."""
        self.faiss_index = faiss.read_index(str(self.index_path / "faiss_index.bin"))
        with open(self.index_path / "metadata.pkl", "rb") as f:
            self.metadata = pickle.load(f)

    def search(self, query_text: str, top_k: int = 50) -> list[dict]:
        """Step 3 & 4: Convert query to embedding and search FAISS."""
        if not self.faiss_index:
            self.load()
            
        query_embedding = self.model.encode([query_text], normalize_embeddings=True)
        
        scores, indices = self.faiss_index.search(
            query_embedding.astype(np.float32), 
            min(top_k, len(self.metadata))
        )
        
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if score >= 0.40:
                doc = dict(self.metadata[idx])
                doc["vector_score"] = float(score)
                results.append(doc)
                
        return results

if __name__ == "__main__":
    # Build notes
    indexer = VectorIndexer("notes")
    indexer.build()
    
    # Build research
    research_indexer = VectorIndexer("research")
    research_indexer.build()
