# Enable Cross-Encoder Reranking

**1. Turn it on in settings**
Open `config/settings.py` and set:
```python
USE_CROSS_ENCODER = True
```

**2. Restart the Server**
Stop and restart your API so the model loads:
```bash
uvicorn api.main:app --reload --port 8000
```

**3. Test via API**
Send a POST request to `/api/search` with `"use_reranker": true`.
```bash
curl -X 'POST' \
  'http://localhost:8000/api/search' \
  -H 'Content-Type: application/json' \
  -d '{
  "query": "heart attack",
  "approach": "hybrid",
  "use_reranker": true
}'
```
