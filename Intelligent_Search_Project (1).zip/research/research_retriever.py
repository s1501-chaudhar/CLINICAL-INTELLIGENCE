import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.bm25_indexer import BM25Indexer
from indexing.vector_indexer import VectorIndexer
from postprocess.score_fusion import pool_results, fuse_scores
from corpus.clinical_synonyms import get_synonyms

class ResearchRetriever:
    """
    Very simple research retriever.
    Combines BM25 and FAISS search for research abstracts.
    """

    def __init__(self):
        self._bm25 = BM25Indexer() 
        self._vector = VectorIndexer("research")
        try:
            self._vector.load()
            self._vector_loaded = True
        except Exception:
            self._vector_loaded = False

    def retrieve(self, query: StructuredQuery, approach: str = "hybrid") -> list[dict]:
        
        # Step 1: Keyword search (BM25)
        bm25_candidates = []
        if approach in ["keyword", "hybrid"]:
            if approach == "keyword":
                terms = query.raw_query.split()
            else:
                terms = query.must_include + query.or_include
                
            clean_terms = [t for t in terms if t.upper() not in ("AND", "OR", "NOT")]
            
            if clean_terms:
                bm25_candidates = self._bm25.search_research(clean_terms, top_k=query.top_k * 2)

        # Step 2: Semantic search (FAISS)
        vector_candidates = []
        if approach in ["semantic", "hybrid"] and self._vector_loaded and query.semantic_intent:
            vector_candidates = self._vector.search(query.semantic_intent, top_k=query.top_k * 2)

        # Step 3: Combine them together
        pooled = pool_results(bm25_candidates, vector_candidates)

        if not pooled:
            return []

        # Step 4: Boolean filters (ONLY FOR HYBRID)
        if approach == "hybrid":
            # AND filter
            if query.must_include:
                filtered_and = []
                for note in pooled:
                    text = (note.get("text", "") + " " + note.get("abstract", "")).lower()
                    all_present = True
                    for term in query.must_include:
                        syns = get_synonyms(term)
                        if not any(s.lower() in text for s in syns):
                            all_present = False
                            break
                    if all_present:
                        filtered_and.append(note)
                pooled = filtered_and

            # OR filter
            if query.or_include:
                filtered_or = []
                for note in pooled:
                    text = (note.get("text", "") + " " + note.get("abstract", "")).lower()
                    any_present = False
                    for term in query.or_include:
                        syns = get_synonyms(term)
                        if any(s.lower() in text for s in syns):
                            any_present = True
                            break
                    if any_present:
                        filtered_or.append(note)
                pooled = filtered_or
                
            # NOT filter
            if query.must_exclude:
                filtered_not = []
                for note in pooled:
                    text = (note.get("text", "") + " " + note.get("abstract", "")).lower()
                    exclude = False
                    for bad_word in query.must_exclude:
                        syns = get_synonyms(bad_word)
                        if any(s.lower() in text for s in syns):
                            exclude = True
                            break
                    if not exclude:
                        filtered_not.append(note)
                pooled = filtered_not

        # Step 5: Mix the scores and sort
        fused = fuse_scores(pooled)

        return fused[: query.top_k]
