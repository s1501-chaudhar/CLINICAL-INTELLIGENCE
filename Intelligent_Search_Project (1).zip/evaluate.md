```text
============================================================
INTELLIGENT CLINICAL SEARCH EVALUATION SUITE
============================================================

Evaluating: Keyword (BM25)
----------------------------------------
    Query: 'chronic kidney disease' -> MRR: 1.00
    Query: 'heart attack' -> MRR: 1.00
    Query: 'asthma NOT pneumonia' -> MRR: 0.50
Metrics (Average over 3 queries):
  Precision@5 : 0.27
  Recall@5    : 0.78
  MRR         : 0.83
  F1-Score    : 0.40

Evaluating: Semantic (FAISS)
----------------------------------------
    Query: 'chronic kidney disease' -> MRR: 1.00
    Query: 'heart attack' -> MRR: 1.00
    Query: 'asthma NOT pneumonia' -> MRR: 0.50
Metrics (Average over 3 queries):
  Precision@5 : 0.33
  Recall@5    : 0.89
  MRR         : 0.83
  F1-Score    : 0.48

Evaluating: Hybrid Search
----------------------------------------
    Query: 'chronic kidney disease' -> MRR: 1.00
    Query: 'heart attack' -> MRR: 1.00
    Query: 'asthma NOT pneumonia' -> MRR: 1.00
Metrics (Average over 3 queries):
  Precision@5 : 0.40
  Recall@5    : 1.00
  MRR         : 1.00
  F1-Score    : 0.57
```
