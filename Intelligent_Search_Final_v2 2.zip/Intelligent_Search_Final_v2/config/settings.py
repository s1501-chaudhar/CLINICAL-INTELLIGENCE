from __future__ import annotations
"""
config/settings.py
==================
Global configuration for the Intelligent Search system.
All tuneable parameters live here; override via .env file.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ---- Project root ----
ROOT_DIR = Path(__file__).parent.parent

# ---- Embedding Model ----
EMBEDDING_MODEL: str = os.getenv(
    "EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
)

# ---- Search Defaults ----
DEFAULT_TOP_K: int = int(os.getenv("DEFAULT_TOP_K", "10"))
DEFAULT_APPROACH: str = os.getenv("DEFAULT_APPROACH", "hybrid")
DEFAULT_NEGATION_MODE: str = os.getenv("DEFAULT_NEGATION_MODE", "clinical_concept")

# ---- Hybrid Score Weights ----
BM25_WEIGHT: float = float(os.getenv("BM25_WEIGHT", "0.40"))
VECTOR_WEIGHT: float = float(os.getenv("VECTOR_WEIGHT", "0.40"))
BOOLEAN_WEIGHT: float = float(os.getenv("BOOLEAN_WEIGHT", "0.20"))

# ---- Index Paths ----
BM25_NOTES_INDEX_PATH: Path = ROOT_DIR / os.getenv("BM25_INDEX_PATH", "indexing/index_store/bm25") / "notes"
BM25_RESEARCH_INDEX_PATH: Path = ROOT_DIR / os.getenv("BM25_INDEX_PATH", "indexing/index_store/bm25") / "research"
FAISS_NOTES_INDEX_PATH: Path = ROOT_DIR / os.getenv("FAISS_INDEX_PATH", "indexing/index_store/faiss") / "notes"
FAISS_RESEARCH_INDEX_PATH: Path = ROOT_DIR / os.getenv("FAISS_INDEX_PATH", "indexing/index_store/faiss") / "research"

# ---- Data Paths ----
NOTES_DATA_PATH: Path = ROOT_DIR / os.getenv("NOTES_DATA_PATH", "data/raw/clinical_notes")
RESEARCH_DATA_PATH: Path = ROOT_DIR / os.getenv("RESEARCH_DATA_PATH", "data/raw/research_abstracts")
TEST_QUERIES_PATH: Path = ROOT_DIR / "data/test_queries"

# ---- Corpus Generation ----
NUM_CLINICAL_NOTES: int = int(os.getenv("NUM_CLINICAL_NOTES", "1500"))
NUM_RESEARCH_ABSTRACTS: int = int(os.getenv("NUM_RESEARCH_ABSTRACTS", "200"))
RANDOM_SEED: int = int(os.getenv("RANDOM_SEED", "42"))

# ---- API ----
API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
API_PORT: int = int(os.getenv("API_PORT", "8000"))
API_DEBUG: bool = os.getenv("API_DEBUG", "true").lower() == "true"

# ---- Negation Detection ----
NEGATION_WINDOW: int = 5  # words after negation cue to check

# ---- LLM Configuration ----
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
OPENROUTER_API_KEY: str = os.getenv("OPENROUTER_API_KEY", "")
USE_LLM_RERANKER: bool = bool(OPENAI_API_KEY or OPENROUTER_API_KEY)

# ---- Cross-Encoder Configuration ----
USE_CROSS_ENCODER: bool = os.getenv("USE_CROSS_ENCODER", "true").lower() == "true"
CROSS_ENCODER_MODEL: str = os.getenv("CROSS_ENCODER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2")


# ---- Ensure index directories exist ----
for path in [
    BM25_NOTES_INDEX_PATH, BM25_RESEARCH_INDEX_PATH,
    FAISS_NOTES_INDEX_PATH, FAISS_RESEARCH_INDEX_PATH,
]:
    path.mkdir(parents=True, exist_ok=True)
