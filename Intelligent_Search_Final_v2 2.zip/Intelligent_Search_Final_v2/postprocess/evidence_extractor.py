from __future__ import annotations
"""
evidence_extractor.py
=====================
Extracts and highlights evidence snippets from clinical note text.

For each matched note, this module:
  1. Splits the note into sentences
  2. Identifies sentences containing matched synonyms
  3. Returns sentence-level snippets with multi-color highlighted terms
  4. Generates a precise "why_matched" explanation naming exact synonyms found
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery

# Color marker tokens — parsed by the frontend into CSS classes
# Format: <<color:term>> — e.g. <<green:CAP>>, <<blue:Brufen>>
COLOR_NAMES = ["green", "blue", "purple", "orange", "teal"]


def _sentence_split(text: str) -> list[str]:
    """Simple sentence splitter handling common clinical abbreviations."""
    text = re.sub(
        r'(Dr|Mr|Mrs|Ms|Prof|No|Hx|Dx|Rx|vs|i\.e|e\.g|Fig|approx|Approx)\.',
        lambda m: m.group(0).replace('.', '<!DOT!>'),
        text
    )
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text)
    return [s.replace('<!DOT!>', '.').strip() for s in sentences if s.strip()]


def _highlight_term(sentence: str, term: str, color: str) -> str:
    """Wrap matched term in color markers (case-insensitive)."""
    # Strip any whitespace/newlines from the synonym term before wrapping
    term = ' '.join(term.strip().split())   # normalise whitespace
    pattern = re.compile(re.escape(term), re.IGNORECASE)
    return pattern.sub(lambda m: f"<<{color}:{m.group(0)}>>", sentence)


def extract_evidence(
    note_text: str,
    matched_concepts_detail: list[dict],   # [{synonym, concept, color_index}]
    max_snippets: int = 3,
) -> list[dict]:
    """
    Extract sentence-level evidence snippets with multi-color highlighting.

    Args:
        note_text:               Full clinical note text
        matched_concepts_detail: List of {synonym, concept, color_index} dicts
        max_snippets:            Maximum snippets to return

    Returns:
        List of {snippet, highlighted_snippet, matched_term, concept, color}
    """
    if not matched_concepts_detail or not note_text:
        return []

    sentences = _sentence_split(note_text)
    evidence: list[dict] = []
    seen: set[str] = set()

    for sentence in sentences:
        sentence_lower = sentence.lower()
        sentence_highlighted = sentence

        matched_in_sentence: list[dict] = []
        for detail in matched_concepts_detail:
            term = ' '.join(detail["synonym"].strip().split())  # normalise whitespace
            if term.lower() in sentence_lower:
                matched_in_sentence.append({**detail, "synonym": term})

        if matched_in_sentence and sentence not in seen:
            # Sort longest synonyms first — prevents substring double-tagging
            # e.g. "non-steroidal anti-inflammatory" before "anti-inflammatory"
            matched_in_sentence.sort(key=lambda d: len(d["synonym"]), reverse=True)

            # Deduplicate: skip a synonym if it is a substring of an already-applied one
            applied_terms: list[str] = []
            filtered: list[dict] = []
            for detail in matched_in_sentence:
                term_lower = detail["synonym"].lower()
                if not any(term_lower in applied.lower() for applied in applied_terms):
                    filtered.append(detail)
                    applied_terms.append(detail["synonym"])

            # Apply highlights longest-first
            for detail in filtered:
                color = COLOR_NAMES[detail.get("color_index", 0)]
                sentence_highlighted = _highlight_term(sentence_highlighted, detail["synonym"], color)

            evidence.append({
                "snippet": sentence.strip(),
                "highlighted_snippet": sentence_highlighted.strip(),
                "matched_terms": [d["synonym"] for d in filtered],
                "concepts":      [d["concept"]  for d in filtered],
            })
            seen.add(sentence)

        if len(evidence) >= max_snippets:
            break

    return evidence


def build_why_matched(
    note: dict,
    query: StructuredQuery,
) -> str:
    """
    Generate a precise explanation naming the EXACT synonym found for each concept.

    Example output:
        "CAP" matched **pneumonia** concept · "Brufen" matched **ibuprofen** concept
        — both required concepts present.
    """
    text_lower = note.get("text", "").lower()
    concept_hits: list[str] = []

    all_concept_groups = list(query.must_include) + list(query.or_include)

    if query.approach == "keyword":
        import re
        from query.query_parser import STOP_WORDS
        tokens = {t for t in re.findall(r'\b\w+\b', query.raw_query.lower()) if t not in STOP_WORDS}
        hits = [t for t in tokens if t in text_lower]
        if hits:
            return f"Keyword match on: {', '.join(hits)}"
        return "Keyword match on raw query."

    for cg in all_concept_groups:
        hits = [s for s in cg.synonyms if s.lower() in text_lower]
        if hits:
            # Use the most specific (longest) match
            best_hit = max(hits, key=len)
            concept_hits.append(f'"{best_hit}" matched **{cg.canonical}** concept')

    if not concept_hits:
        return "Matched via semantic similarity."

    joined = " · ".join(concept_hits)
    if len(all_concept_groups) >= 2 and len(concept_hits) == len(all_concept_groups):
        joined += " — all required concepts present."
    else:
        joined += "."

    # Annotate if an excluded concept was found but negated
    if query.must_exclude:
        for exc_cg in query.must_exclude:
            exc_hits = [s for s in exc_cg.synonyms if s.lower() in text_lower]
            if exc_hits:
                joined += (
                    f" Note: '{exc_hits[0]}' present but negated → retained in clinical mode."
                )

    return joined


def annotate_results_with_evidence(
    results: list[dict],
    query: StructuredQuery,
    max_snippets: int = 3,
) -> list[dict]:
    """
    Annotate a list of result notes with evidence snippets and explanations.

    Args:
        results:      List of matched note dicts
        query:        The StructuredQuery used for retrieval
        max_snippets: Max evidence snippets per note

    Returns:
        Same list with matched_evidence, highlighted_evidence, and why_matched added.
    """
    annotated = []

    for note in results:
        note = dict(note)
        text = note.get("text", "")

        # Get matched_concepts_detail — either from retriever annotation or reconstruct
        detail = note.get("matched_concepts_detail", [])
        if not detail:
            if query.approach == "keyword":
                import re
                from query.query_parser import STOP_WORDS
                tokens = {t for t in re.findall(r'\b\w+\b', query.raw_query.lower()) if t not in STOP_WORDS}
                text_lower = text.lower()
                for idx, t in enumerate(tokens):
                    if t in text_lower:
                        detail.append({
                            "synonym": t,
                            "concept": t,
                            "color_index": idx % len(COLOR_NAMES)
                        })
            else:
                # Reconstruct from all_include synonyms
                all_groups = list(query.must_include) + list(query.or_include)
                text_lower = text.lower()
                for idx, cg in enumerate(all_groups):
                    for syn in sorted(cg.synonyms, key=len, reverse=True):  # longest first
                        syn_norm = ' '.join(syn.strip().split())
                        if syn_norm.lower() in text_lower:
                            detail.append({
                                "synonym": syn_norm,
                                "concept": cg.canonical,
                                "color_index": idx % len(COLOR_NAMES),
                            })
                            break

        evidence_items = extract_evidence(text, detail, max_snippets)

        note["matched_evidence"]     = [e["snippet"]             for e in evidence_items]
        note["highlighted_evidence"] = [e["highlighted_snippet"] for e in evidence_items]
        note["why_matched"]          = build_why_matched(note, query)

        annotated.append(note)

    return annotated
