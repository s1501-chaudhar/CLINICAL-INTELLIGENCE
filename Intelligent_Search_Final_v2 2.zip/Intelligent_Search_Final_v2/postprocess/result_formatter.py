from __future__ import annotations
"""
result_formatter.py
===================
Formats the raw ranked note results + research results into the final
API response JSON matching the schema defined in the project brief.
"""

import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from postprocess.evidence_extractor import annotate_results_with_evidence


def format_response(
    query: StructuredQuery,
    notes: list[dict],
    research: list[dict],
    search_time_ms: float = 0.0,
    approach_used: str = "hybrid",
) -> dict:
    """
    Produce the final structured API response.

    Args:
        query:          The parsed StructuredQuery
        notes:          Ranked note results (from any retriever)
        research:       Ranked research abstract results
        search_time_ms: Total search latency in milliseconds
        approach_used:  Which retrieval approach was used

    Returns:
        Dict matching the project brief output schema
    """
    # Annotate notes with evidence
    annotated_notes = annotate_results_with_evidence(notes, query)

    # Normalise BM25 scores to 0-1 range (raw Whoosh scores can be > 1)
    bm25_max = max((n.get("bm25_score", 0.0) for n in annotated_notes), default=1.0)
    if bm25_max == 0:
        bm25_max = 1.0

    # Format note results
    formatted_notes = []
    for note in annotated_notes:
        bm25_raw = note.get("bm25_score", 0.0)
        bm25_norm = min(1.0, bm25_raw / bm25_max)
        formatted_notes.append({
            "note_id":              note.get("note_id", ""),
            "patient_id":           note.get("patient_id", ""),
            "note_type":            note.get("note_type", ""),
            "department":           note.get("department", ""),
            "doctor":               note.get("doctor", ""),
            "date":                 note.get("date", ""),
            "text":                 note.get("text", ""),
            "score":                round(note.get("hybrid_score", 0.0), 4),
            "bm25_score":           round(bm25_norm, 4),
            "vector_score":         round(note.get("vector_score", 0.0), 4),
            "boolean_score":        round(note.get("boolean_score", 0.0), 4),
            "matched_evidence":     note.get("matched_evidence", []),
            "highlighted_evidence": note.get("highlighted_evidence", []),
            "why_matched":          note.get("why_matched", ""),
        })

    # Normalise research scores
    res_max = max((a.get("bm25_score", a.get("vector_score", 0.0)) for a in research), default=1.0)
    if res_max == 0:
        res_max = 1.0

    # Format research results
    formatted_research = []
    for ab in research:
        raw_score = ab.get("bm25_score", ab.get("vector_score", 0.0))
        norm_score = min(1.0, raw_score / res_max)
        formatted_research.append({
            "abstract_id":    ab.get("abstract_id", ""),
            "title":          ab.get("title", ""),
            "journal":        ab.get("journal", ""),
            "year":           ab.get("year", ""),
            "source":         ab.get("source", "Synthetic PubMed Dataset"),
            "doi":            ab.get("doi", ""),
            "abstract":       ab.get("abstract", ""),
            "relevance_score":round(norm_score, 4),
            "why_relevant":   _why_relevant(ab, query),
        })

    return {
        "interpreted_query": query.to_display_dict(),
        "matching_notes": formatted_notes,
        "research_results": formatted_research,
        "total_results": len(formatted_notes),
        "total_research": len(formatted_research),
        "search_time_ms": round(search_time_ms, 1),
        "approach_used": approach_used,
    }


def _why_relevant(abstract: dict, query: StructuredQuery) -> str:
    """Generate a relevance explanation for a research abstract."""
    title = abstract.get("title", "")
    text = (abstract.get("abstract", "") + " " + " ".join(abstract.get("keywords", []))).lower()

    matched_concepts = []
    for cg in query.must_include:
        if any(s.lower() in text for s in cg.synonyms):
            matched_concepts.append(cg.canonical)

    if matched_concepts:
        return f"Discusses {', '.join(matched_concepts)} in clinical context."
    return f"Semantically related to the query: {query.raw_query!r}"
