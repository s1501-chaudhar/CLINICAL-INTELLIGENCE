from __future__ import annotations
"""
vector_indexer.py
=================
Builds and manages FAISS dense vector indexes for clinical notes and research
abstracts using SentenceTransformers embeddings.

Usage:
    python indexing/vector_indexer.py --build notes
    python indexing/vector_indexer.py --build research
    python indexing/vector_indexer.py --build all
"""

import json
import pickle
import argparse
import sys
import numpy as np
from pathlib import Path
from typing import Optional, TYPE_CHECKING

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import (
    EMBEDDING_MODEL,
    FAISS_NOTES_INDEX_PATH,
    FAISS_RESEARCH_INDEX_PATH,
    NOTES_DATA_PATH,
    RESEARCH_DATA_PATH,
)

# ── Lazy imports (required for Python 3.9 compat with sentence-transformers) ──
def _get_faiss():
    try:
        import faiss
        return faiss
    except ImportError:
        return None

def _get_st_model(model_name: str):
    try:
        from sentence_transformers import SentenceTransformer
        import os
        # Use local_files_only to prevent HuggingFace network timeout errors
        os.environ['HF_HUB_OFFLINE'] = '1'
        return SentenceTransformer(model_name, local_files_only=True)
    except ImportError:
        return None

FAISS_AVAILABLE = _get_faiss() is not None
ST_AVAILABLE = True  # will verify on first call




# ── VectorIndexer ─────────────────────────────────────────────────────────────

class VectorIndexer:
    """
    Builds and queries FAISS vector indexes.

    Files created per index:
        faiss_index.bin   — FAISS flat index (cosine similarity via L2 on normalised vectors)
        metadata.pkl      — list of dicts with all searchable fields, aligned by index position
        id_map.pkl        — {note_id: faiss_position} for lookup
    """

    def __init__(self, index_type: str = "notes"):
        """
        Args:
            index_type: "notes" or "research"
        """
        assert index_type in ("notes", "research")
        self.index_type = index_type
        self.index_path = (
            FAISS_NOTES_INDEX_PATH if index_type == "notes"
            else FAISS_RESEARCH_INDEX_PATH
        )
        self.index_path.mkdir(parents=True, exist_ok=True)

        self._faiss_index: Optional["faiss.Index"] = None
        self._metadata: list[dict] = []
        self._id_map: dict[str, int] = {}

    # ─────────────────────────────────────────────────────────────────────────
    # Build
    # ─────────────────────────────────────────────────────────────────────────

    def build(self) -> None:
        """Build the FAISS index from the corpus JSON file."""
        if not FAISS_AVAILABLE or not ST_AVAILABLE:
            raise RuntimeError("faiss-cpu and sentence-transformers are required.")

        if self.index_type == "notes":
            self._build_notes()
        else:
            self._build_research()

    def _build_notes(self) -> None:
        notes_file = NOTES_DATA_PATH / "notes.json"
        if not notes_file.exists():
            raise FileNotFoundError(
                f"Notes file not found: {notes_file}\n"
                "Please ensure the data is generated."
            )

        print(f"📂 Loading notes from {notes_file}...")
        with open(notes_file) as f:
            notes = json.load(f)

        texts = [note["text"] for note in notes]
        ids = [note["note_id"] for note in notes]

        print(f"🔢 Encoding {len(texts)} notes (this may take a few minutes)...")
        model = _get_st_model(EMBEDDING_MODEL)
        if model is None:
            raise RuntimeError("sentence-transformers not available")
        embeddings = model.encode(
            texts,
            batch_size=64,
            show_progress_bar=True,
            normalize_embeddings=True,  # cosine similarity via inner product
        )

        self._build_index(embeddings, notes, ids, id_field="note_id")
        print(f"✅ Notes FAISS index built → {self.index_path}")

    def _build_research(self) -> None:
        abstracts_file = RESEARCH_DATA_PATH / "abstracts.json"
        if not abstracts_file.exists():
            raise FileNotFoundError(
                f"Abstracts file not found: {abstracts_file}\n"
                "Please ensure the data is generated."
            )

        print(f"📂 Loading research abstracts from {abstracts_file}...")
        with open(abstracts_file) as f:
            abstracts = json.load(f)

        # Concatenate title + abstract for richer embedding
        texts = [f"{a['title']}. {a['abstract']}" for a in abstracts]
        ids = [a["abstract_id"] for a in abstracts]

        print(f"🔢 Encoding {len(texts)} research abstracts...")
        model = _get_st_model(EMBEDDING_MODEL)
        if model is None:
            raise RuntimeError("sentence-transformers not available")
        embeddings = model.encode(
            texts,
            batch_size=32,
            show_progress_bar=True,
            normalize_embeddings=True,
        )

        self._build_index(embeddings, abstracts, ids, id_field="abstract_id")
        print(f"✅ Research FAISS index built → {self.index_path}")

    def _build_index(
        self,
        embeddings: np.ndarray,
        metadata: list[dict],
        ids: list[str],
        id_field: str,
    ) -> None:
        faiss = _get_faiss()
        if faiss is None:
            raise RuntimeError("faiss-cpu not available")
        dim = embeddings.shape[1]

        # Use inner product (cosine on normalised vectors)
        faiss_index = faiss.IndexFlatIP(dim)
        faiss_index.add(embeddings.astype(np.float32))

        self._faiss_index = faiss_index
        self._metadata = metadata
        self._id_map = {doc[id_field]: i for i, doc in enumerate(metadata)}

        # Persist
        faiss.write_index(faiss_index, str(self.index_path / "faiss_index.bin"))

        with open(self.index_path / "metadata.pkl", "wb") as f:
            pickle.dump(metadata, f)

        with open(self.index_path / "id_map.pkl", "wb") as f:
            pickle.dump(self._id_map, f)

    # ─────────────────────────────────────────────────────────────────────────
    # Load
    # ─────────────────────────────────────────────────────────────────────────

    def load(self) -> None:
        """Load a pre-built FAISS index from disk."""
        index_file = self.index_path / "faiss_index.bin"
        if not index_file.exists():
            raise FileNotFoundError(
                f"FAISS index not found at {self.index_path}.\n"
                f"Run: python indexing/vector_indexer.py --build {self.index_type}"
            )

        faiss = _get_faiss()
        if faiss is None:
            raise RuntimeError("faiss-cpu not available")
        self._faiss_index = faiss.read_index(str(index_file))

        with open(self.index_path / "metadata.pkl", "rb") as f:
            self._metadata = pickle.load(f)

        with open(self.index_path / "id_map.pkl", "rb") as f:
            self._id_map = pickle.load(f)

    def _ensure_loaded(self) -> None:
        if self._faiss_index is None:
            self.load()

    # ─────────────────────────────────────────────────────────────────────────
    # Search
    # ─────────────────────────────────────────────────────────────────────────

    def search(self, query_text: str, top_k: int = 50) -> list[dict]:
        """
        Semantic search: encode query and find nearest neighbours.

        Args:
            query_text: Natural language query or semantic intent string
            top_k:      Max candidates to return

        Returns:
            List of dicts with metadata + vector_score (cosine similarity)
        """
        if not FAISS_AVAILABLE or not ST_AVAILABLE:
            return []

        self._ensure_loaded()

        model = _get_st_model(EMBEDDING_MODEL)
        if model is None:
            return []
        query_embedding = model.encode(
            [query_text],
            normalize_embeddings=True,
        ).astype(np.float32)

        scores, indices = self._faiss_index.search(query_embedding, min(top_k, len(self._metadata)))

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            doc = dict(self._metadata[idx])
            doc["vector_score"] = float(score)
            results.append(doc)

        return results

    def index_exists(self) -> bool:
        return (self.index_path / "faiss_index.bin").exists()


# ── CLI ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Build FAISS vector indexes")
    parser.add_argument(
        "--build",
        choices=["notes", "research", "all"],
        default="all",
    )
    args = parser.parse_args()

    if args.build in ("notes", "all"):
        VectorIndexer("notes").build()

    if args.build in ("research", "all"):
        VectorIndexer("research").build()


if __name__ == "__main__":
    main()
