from __future__ import annotations
"""
bm25_indexer.py
===============
Builds and manages BM25 inverted indexes for clinical notes and research abstracts
using Whoosh.

Usage:
    python indexing/bm25_indexer.py --build notes
    python indexing/bm25_indexer.py --build research
    python indexing/bm25_indexer.py --build all
"""

import json
import argparse
import sys
from pathlib import Path

# Allow imports from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from whoosh import index
    from whoosh.fields import Schema, TEXT, ID, KEYWORD, STORED
    from whoosh.analysis import StemmingAnalyzer
    from whoosh.qparser import QueryParser as WhooshQueryParser, MultifieldParser
    from whoosh.qparser import OrGroup
    from whoosh import scoring
    WHOOSH_AVAILABLE = True
except ImportError:
    WHOOSH_AVAILABLE = False
    print("⚠️  Whoosh not installed. Run: pip install whoosh")

from config.settings import (
    BM25_NOTES_INDEX_PATH,
    BM25_RESEARCH_INDEX_PATH,
    NOTES_DATA_PATH,
    RESEARCH_DATA_PATH,
)


# ── Whoosh Schemas ────────────────────────────────────────────────────────────

def _notes_schema() -> "Schema":
    return Schema(
        note_id=ID(stored=True, unique=True),
        patient_id=ID(stored=True),
        note_type=KEYWORD(stored=True),
        department=KEYWORD(stored=True),
        doctor=STORED,
        date=STORED,
        text=TEXT(analyzer=StemmingAnalyzer(), stored=True),
        diagnoses=KEYWORD(stored=True, commas=True),
        medications=KEYWORD(stored=True, commas=True),
        ground_truth_tags=KEYWORD(stored=True, commas=True),
    )


def _research_schema() -> "Schema":
    return Schema(
        abstract_id=ID(stored=True, unique=True),
        title=TEXT(analyzer=StemmingAnalyzer(), stored=True),
        abstract=TEXT(analyzer=StemmingAnalyzer(), stored=True),
        keywords=KEYWORD(stored=True, commas=True),
        journal=STORED,
        year=STORED,
        source=STORED,
        doi=STORED,
        topic=STORED,
    )


# ── Index Builders ────────────────────────────────────────────────────────────

class BM25Indexer:
    """
    Builds and queries BM25 indexes using Whoosh.

    Two separate indexes:
        - notes_index:    Clinical notes corpus
        - research_index: Research abstracts corpus
    """

    def __init__(self):
        self.notes_index_path = BM25_NOTES_INDEX_PATH
        self.research_index_path = BM25_RESEARCH_INDEX_PATH

    # ─────────────────────────────────────────────────────────────────────────
    # Build
    # ─────────────────────────────────────────────────────────────────────────

    def build_notes_index(self, notes_path: Path | None = None) -> None:
        """
        Build/rebuild the Whoosh BM25 index for clinical notes.

        Args:
            notes_path: Path to notes.json. Defaults to settings.NOTES_DATA_PATH/notes.json
        """
        if not WHOOSH_AVAILABLE:
            raise RuntimeError("Whoosh is required. pip install whoosh")

        notes_file = Path(notes_path or NOTES_DATA_PATH) / "notes.json"
        if not notes_file.exists():
            raise FileNotFoundError(
                f"Notes file not found: {notes_file}\n"
                "Please ensure the data is generated."
            )

        print(f"📂 Loading notes from {notes_file}...")
        with open(notes_file) as f:
            notes = json.load(f)

        print(f"🔨 Building BM25 notes index ({len(notes)} notes)...")
        self.notes_index_path.mkdir(parents=True, exist_ok=True)
        ix = index.create_in(str(self.notes_index_path), _notes_schema())

        writer = ix.writer(limitmb=256, procs=1)
        for note in notes:
            meta = note.get("metadata", {})
            writer.add_document(
                note_id=note["note_id"],
                patient_id=note.get("patient_id", ""),
                note_type=note.get("note_type", ""),
                department=note.get("department", ""),
                doctor=note.get("doctor", ""),
                date=note.get("date", ""),
                text=note["text"],
                diagnoses=",".join(meta.get("diagnoses", [])),
                medications=",".join(meta.get("medications", [])),
                ground_truth_tags=",".join(meta.get("ground_truth_tags", [])),
            )
        writer.commit()
        print(f"✅ Notes BM25 index built → {self.notes_index_path}")

    def build_research_index(self, research_path: Path | None = None) -> None:
        """Build/rebuild the Whoosh BM25 index for research abstracts."""
        if not WHOOSH_AVAILABLE:
            raise RuntimeError("Whoosh is required. pip install whoosh")

        abstracts_file = Path(research_path or RESEARCH_DATA_PATH) / "abstracts.json"
        if not abstracts_file.exists():
            raise FileNotFoundError(
                f"Abstracts file not found: {abstracts_file}\n"
                "Please ensure the data is generated."
            )

        print(f"📂 Loading research abstracts from {abstracts_file}...")
        with open(abstracts_file) as f:
            abstracts = json.load(f)

        print(f"🔨 Building BM25 research index ({len(abstracts)} abstracts)...")
        self.research_index_path.mkdir(parents=True, exist_ok=True)
        ix = index.create_in(str(self.research_index_path), _research_schema())

        writer = ix.writer(limitmb=128)
        for ab in abstracts:
            meta = ab.get("metadata", {})
            writer.add_document(
                abstract_id=ab["abstract_id"],
                title=ab["title"],
                abstract=ab["abstract"],
                keywords=",".join(ab.get("keywords", [])),
                journal=ab.get("journal", ""),
                year=str(ab.get("year", "")),
                source=ab.get("source", ""),
                doi=ab.get("doi", ""),
                topic=meta.get("topic", ""),
            )
        writer.commit()
        print(f"✅ Research BM25 index built → {self.research_index_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # Search
    # ─────────────────────────────────────────────────────────────────────────

    def search_notes(
        self,
        terms: list[str],
        top_k: int = 50,
    ) -> list[dict]:
        """
        BM25 search over clinical notes.

        Args:
            terms: Flat list of expanded synonyms to search for (OR'd together)
            top_k: Maximum results to return

        Returns:
            List of dicts with note fields + bm25_score
        """
        if not WHOOSH_AVAILABLE:
            return []

        if not index.exists_in(str(self.notes_index_path)):
            raise RuntimeError(
                "Notes index not found. Run: python indexing/bm25_indexer.py --build notes"
            )

        ix = index.open_dir(str(self.notes_index_path))

        with ix.searcher(weighting=scoring.BM25F()) as searcher:
            # Build OR query across all expanded terms
            query_string = " OR ".join(f'"{t}"' if " " in t else t for t in terms)
            parser = MultifieldParser(
                ["text", "diagnoses", "medications"],
                schema=ix.schema,
                group=OrGroup,
            )
            q = parser.parse(query_string)
            results = searcher.search(q, limit=top_k)

            return [
                {
                    "note_id": r["note_id"],
                    "patient_id": r.get("patient_id", ""),
                    "note_type": r.get("note_type", ""),
                    "department": r.get("department", ""),
                    "doctor": r.get("doctor", ""),
                    "date": r.get("date", ""),
                    "text": r["text"],
                    "bm25_score": r.score,
                    "diagnoses": r.get("diagnoses", "").split(",") if r.get("diagnoses") else [],
                    "medications": r.get("medications", "").split(",") if r.get("medications") else [],
                    "ground_truth_tags": r.get("ground_truth_tags", "").split(",") if r.get("ground_truth_tags") else [],
                }
                for r in results
            ]

    def search_raw(self, query_string: str, top_k: int = 50) -> list[dict]:
        """BM25 search using the raw query string (supports native Whoosh boolean)."""
        if not WHOOSH_AVAILABLE:
            return []
        if not index.exists_in(str(self.notes_index_path)):
            raise RuntimeError("Notes index not found.")

        ix = index.open_dir(str(self.notes_index_path))
        with ix.searcher(weighting=scoring.BM25F()) as searcher:
            parser = MultifieldParser(
                ["text", "diagnoses", "medications"],
                schema=ix.schema,
                group=OrGroup,
            )
            q = parser.parse(query_string)
            results = searcher.search(q, limit=top_k)
            return [
                {
                    "note_id": r["note_id"],
                    "patient_id": r.get("patient_id", ""),
                    "note_type": r.get("note_type", ""),
                    "department": r.get("department", ""),
                    "doctor": r.get("doctor", ""),
                    "date": r.get("date", ""),
                    "text": r["text"],
                    "bm25_score": r.score,
                }
                for r in results
            ]

    def search_research(
        self,
        terms: list[str],
        top_k: int = 10,
    ) -> list[dict]:
        """BM25 search over research abstracts."""
        if not WHOOSH_AVAILABLE:
            return []

        if not index.exists_in(str(self.research_index_path)):
            raise RuntimeError(
                "Research index not found. Run: python indexing/bm25_indexer.py --build research"
            )

        ix = index.open_dir(str(self.research_index_path))

        with ix.searcher(weighting=scoring.BM25F()) as searcher:
            query_string = " OR ".join(f'"{t}"' if " " in t else t for t in terms)
            parser = MultifieldParser(
                ["title", "abstract", "keywords"],
                schema=ix.schema,
                group=OrGroup,
            )
            q = parser.parse(query_string)
            results = searcher.search(q, limit=top_k)

            return [
                {
                    "abstract_id": r["abstract_id"],
                    "title": r["title"],
                    "abstract": r["abstract"],
                    "journal": r.get("journal", ""),
                    "year": r.get("year", ""),
                    "source": r.get("source", ""),
                    "doi": r.get("doi", ""),
                    "bm25_score": r.score,
                }
                for r in results
            ]

    def index_exists(self, index_type: str = "notes") -> bool:
        """Check if the specified index has been built."""
        path = self.notes_index_path if index_type == "notes" else self.research_index_path
        return index.exists_in(str(path)) if WHOOSH_AVAILABLE else False


# ── CLI entry point ───────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Build BM25 indexes")
    parser.add_argument(
        "--build",
        choices=["notes", "research", "all"],
        default="all",
        help="Which index to build",
    )
    args = parser.parse_args()

    indexer = BM25Indexer()

    if args.build in ("notes", "all"):
        indexer.build_notes_index()

    if args.build in ("research", "all"):
        indexer.build_research_index()


if __name__ == "__main__":
    main()
