/* ============================================================
   app.js — ClinicalSearch AI v6
   Keyword · Boolean · Semantic · Hybrid · Comparison mode
   Expandable notes · Expandable research · Full note text
   ============================================================ */

const API_BASE = '/api';
const COLORS = ['green', 'blue', 'purple', 'orange', 'teal'];

// ── Theme Management ──────────────────────────────────────────
function initTheme() {
  document.documentElement.setAttribute('data-theme', 'light');
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const newTheme = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  updateThemeIcon(newTheme);
}

function updateThemeIcon(theme) {
  const btn = document.getElementById('theme-toggle');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

document.addEventListener('DOMContentLoaded', initTheme);
initTheme(); // Run immediately as well

// ── State ─────────────────────────────────────────────────────
const state = {
  approach: 'hybrid',
  mode: 'clinical_concept',
  topK: 10,
  includeResearch: true,
  compareOpen: false,
  lastQuery: '',
};

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('search-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') triggerSearch();
  });
  initSidebar();
});

// ── Sidebar & Navigation ──────────────────────────────────────
async function initSidebar() {
  try {
    const res = await fetch('/api/data/stats');
    if (!res.ok) return;
    const stats = await res.json();
    
    // Populate research count
    // Count hidden per user request
    
    // Populate notes dropdown
    const dropdown = document.getElementById('notes-dropdown');
    dropdown.innerHTML = '';
    
    // Define the order requested by user
    const noteTypes = [
      { id: 'OPD', label: 'OPD notes' },
      { id: 'ICU Progress', label: 'Inpatient progress' },
      { id: 'Emergency', label: 'Emergency notes' },
      { id: 'Discharge Summary', label: 'Discharge summaries' },
      { id: 'Nursing', label: 'Nursing notes' },
      { id: 'Radiology', label: 'Radiology impressions' },
      { id: 'Referral', label: 'Referral notes' }
    ];
    
    noteTypes.forEach(nt => {
      const count = stats.notes[nt.id] || 0;
      const btn = document.createElement('button');
      btn.className = 'sidebar-sub-item';
      btn.innerHTML = `${nt.label}`;
      btn.onclick = (e) => loadDataExplorer(e, nt.id, nt.label);
      dropdown.appendChild(btn);
    });
    
  } catch (err) {
    console.error('Failed to init sidebar', err);
  }
}

function toggleSidebarDropdown(id) {
  const el = document.getElementById(id);
  const icon = document.getElementById(id + '-icon');
  if (el.style.display === 'none' || !el.style.display) {
    el.style.display = 'block';
    if(icon) icon.textContent = '▲';
  } else {
    el.style.display = 'none';
    if(icon) icon.textContent = '▼';
  }
}

function showSearchView() {
  document.getElementById('search-view').style.display = 'block';
  document.getElementById('explorer-view').style.display = 'none';
  
  // Update active states
  document.querySelectorAll('.sidebar-nav-item, .sidebar-sub-item').forEach(b => b.classList.remove('active'));
  document.getElementById('nav-search').classList.add('active');
}

async function loadDataExplorer(e, typeId, typeLabel) {
  document.getElementById('search-view').style.display = 'none';
  document.getElementById('explorer-view').style.display = 'block';
  
  // Update active states
  document.querySelectorAll('.sidebar-nav-item, .sidebar-sub-item').forEach(b => b.classList.remove('active'));
  if (e && e.currentTarget) {
    e.currentTarget.classList.add('active');
  }
  
  const title = document.getElementById('explorer-title');
  const sub = document.getElementById('explorer-subtitle');
  const grid = document.getElementById('explorer-grid');
  
  grid.innerHTML = '<div class="loading-spinner"></div>';
  
  if (typeId === 'Medical research') {
    title.textContent = 'Medical research';
    sub.textContent = 'Linked literature surfaced alongside matching clinical notes.';
    
    try {
      const data = [
        { title: 'Pneumonia outcomes in ICU', journal: 'NEJM', year: '2023', abstract: 'Summary of recent trends...' },
        { title: 'Advil usage in respiratory infections', journal: 'Lancet', year: '2024', abstract: 'Analysis of NSAID interactions.' }
      ];
      grid.innerHTML = data.map(renderResearchCardExplorer).join('');
    } catch(err) {
      grid.innerHTML = '<div class="error">Failed to load research data.</div>';
    }
  } else {
    title.textContent = typeLabel;
    // Map subtypes to subheadings
    const subs = {
      'OPD': 'Outpatient consults',
      'Emergency': 'ER admissions',
      'ICU Progress': 'Ward day-to-day',
      'Discharge Summary': 'End of stay',
      'Nursing': 'Observation logs',
      'Radiology': 'Imaging reads',
      'Referral': 'Specialist handoff'
    };
    sub.textContent = subs[typeId] || 'Clinical records';
    
    try {
      if (typeId === 'OPD') {
        // We use hardcoded notes to demonstrate search approach comparisons for OPD
        const data = [
          { note_id: 'N-010', department: 'Pulmonology', date: '2024-05-10', text: 'Patient diagnosed with pneumonia. Took ibuprofen for fever before admission.', doctor: 'Dr. Smith', patient_id: 'P-110' },
          { note_id: 'N-011', department: 'OPD', date: '2024-05-12', text: 'Patient treated for lower respiratory tract infection. Advil taken at home.', doctor: 'Dr. Jones', patient_id: 'P-111' },
          { note_id: 'N-012', department: 'Oncology', date: '2024-05-14', text: 'History of lung cancer with chemotherapy-related blisters.', doctor: 'Dr. Lee', patient_id: 'P-112' },
          { note_id: 'N-013', department: 'Dermatology', date: '2024-05-15', text: 'Blister over left foot. No history of cancer.', doctor: 'Dr. Patel', patient_id: 'P-113' }
        ];
        grid.innerHTML = data.map(renderNoteCardExplorer).join('');
      } else {
        const res = await fetch(`/api/data/notes?type=${typeId}&limit=3`);
        const data = await res.json();
        grid.innerHTML = data.map(renderNoteCardExplorer).join('');
      }
    } catch(err) {
      grid.innerHTML = '<div class="error">Failed to load note data.</div>';
    }
  }
}

function renderNoteCardExplorer(note) {

  return `
    <div style="background:rgba(255,255,255,0.72);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(28,34,48,0.06);border-radius:14px;padding:16px 18px;box-shadow:0 6px 24px rgba(28,34,48,0.04);display:flex;flex-direction:column;">
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <div style="display:flex;gap:8px;align-items:baseline;">
          <span style="font-size:13px;font-weight:600;color:#1c2230;">${note.note_id}</span>
          <span style="font-size:12px;color:#a4abb8;">${note.department}</span>
        </div>
        <span style="font-size:11.5px;color:#a4abb8;">${note.date}</span>
      </div>
      <p style="font-size:13.5px;line-height:1.65;color:#3d4456;margin:0 0 10px;">${note.text}</p>
      <div style="font-size:11px;color:#a4abb8;margin-top:auto;">
        ${note.doctor || 'Dr. Mehta'} · ${note.patient_id || 'P-219'}
      </div>
    </div>
  `;
}

function renderResearchCardExplorer(doc) {
  return `
    <div style="background:rgba(255,255,255,0.72);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(28,34,48,0.06);border-radius:14px;padding:18px 20px;box-shadow:0 6px 24px rgba(28,34,48,0.04);display:flex;flex-direction:column;">
      <div style="font-size:14px;font-weight:600;margin-bottom:4px;color:var(--text-primary);">${doc.title}</div>
      <div style="font-size:11.5px;color:#a4abb8;margin-bottom:10px;">
        ${(doc.authors || []).join(', ')} · ${doc.journal} · ${doc.year}
      </div>
      <p style="font-size:13.5px;line-height:1.65;color:#3d4456;margin:0 0 10px;">${doc.abstract}</p>
    </div>
  `;
}

// ── Control setters ───────────────────────────────────────────
function setApproach(a) {
  state.approach = a;
  ['keyword','hybrid','semantic'].forEach(x =>
    document.getElementById(`btn-${x}`).classList.toggle('active', x === a)
  );
  
  // If there is an active search, re-trigger it with the new approach
  const currentQuery = document.getElementById('search-input').value.trim();
  if (currentQuery && currentQuery === state.lastQuery) {
    triggerSearch();
  }
}

function useExample(query) {
  document.getElementById('search-input').value = query;
  triggerSearch();
}

// ── Search ────────────────────────────────────────────────────
async function triggerSearch() {
  const query = document.getElementById('search-input').value.trim();
  if (!query) return;

  state.topK = 10; // Hardcoded default since UI dropdown was removed
  state.lastQuery = query;
  setLoading(true);
  document.getElementById('empty-state').style.display = 'none';

  try {
    const dynamicMode = (state.approach === 'keyword' || state.approach === 'boolean') ? 'literal' : 'clinical_concept';
    const data = await doSearch(query, state.approach, dynamicMode, state.topK, state.includeResearch);
    render(data);
  } catch (err) {
    renderError(err.message);
  } finally {
    setLoading(false);
  }
}

async function doSearch(query, approach, mode, topK, includeResearch) {
  const res = await fetch(`${API_BASE}/search`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, approach, mode, top_k: topK, include_research: includeResearch }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || 'Search failed');
  }
  return res.json();
}

// ── Comparison ────────────────────────────────────────────────
async function runComparison(query) {
  // Show loading state in compare columns
  ['keyword','boolean','semantic','hybrid'].forEach(a => {
    document.getElementById(`cmp-${a}`).innerHTML = '<div class="compare-empty">Loading…</div>';
    const miss = document.getElementById(`cmp-${a}-miss`);
    if (miss) miss.textContent = '';
    const insight = document.getElementById('cmp-hybrid-insight');
    if (insight) insight.textContent = '';
  });

  // Fetch all 4 approaches in parallel (top_k=5 for speed)
  const approaches = ['keyword','boolean','semantic','hybrid'];
  const results = await Promise.all(
    approaches.map(a => {
      const dynamicMode = (a === 'keyword' || a === 'boolean') ? 'literal' : 'clinical_concept';
      return doSearch(query, a, dynamicMode, 5, false).catch(() => null);
    })
  );

  const [kwData, boolData, semData, hybData] = results;
  const idSets = {
    keyword:  new Set((kwData?.matching_notes   || []).map(n => n.note_id)),
    boolean:  new Set((boolData?.matching_notes  || []).map(n => n.note_id)),
    semantic: new Set((semData?.matching_notes   || []).map(n => n.note_id)),
    hybrid:   new Set((hybData?.matching_notes   || []).map(n => n.note_id)),
  };

  // Render each column
  renderCompareCol('keyword',  kwData,   idSets, 'Keyword misses synonyms and concept variations');
  renderCompareCol('boolean',  boolData, idSets, 'Boolean may miss semantically related notes');
  renderCompareCol('semantic', semData,  idSets, 'Semantic may ignore hard Boolean constraints');

  // Hybrid — show what it got that others missed
  const hybridOnly = [...idSets.hybrid].filter(id =>
    !idSets.keyword.has(id) && !idSets.boolean.has(id) && !idSets.semantic.has(id)
  );
  const boolOnly = [...idSets.boolean].filter(id => !idSets.keyword.has(id));
  const semOnly  = [...idSets.semantic].filter(id => !idSets.keyword.has(id));

  renderCompareColHybrid(hybData, idSets, hybridOnly);

  // Show miss reasons
  const kwMissed = [...idSets.hybrid].filter(id => !idSets.keyword.has(id));
  const boolMissed = [...idSets.hybrid].filter(id => !idSets.boolean.has(id));
  const semMissed  = [...idSets.hybrid].filter(id => !idSets.semantic.has(id));

  const kwEl = document.getElementById('cmp-keyword-miss');
  const boolEl = document.getElementById('cmp-boolean-miss');
  const semEl  = document.getElementById('cmp-semantic-miss');
  if (kwEl && kwMissed.length)   kwEl.textContent   = `❌ Missed ${kwMissed.length} notes found by Hybrid`;
  if (boolEl && boolMissed.length) boolEl.textContent = `❌ Missed ${boolMissed.length} notes found by Hybrid`;
  if (semEl  && semMissed.length)  semEl.textContent  = `❌ Missed ${semMissed.length} notes found by Hybrid`;
}

function renderCompareCol(approach, data, idSets, missReason) {
  const el = document.getElementById(`cmp-${approach}`);
  const notes = data?.matching_notes || [];
  if (!notes.length) {
    el.innerHTML = '<div class="compare-empty">No results</div>';
    return;
  }
  // Mark notes unique to this approach vs keyword baseline
  el.innerHTML = notes.map(n => {
    const isUnique = approach !== 'keyword' && !idSets.keyword.has(n.note_id);
    return `<div class="compare-note-row ${isUnique ? 'unique' : ''}">
      <span class="compare-note-id">${esc(n.note_id)}</span>
      <span>${esc((n.note_type||'') + ' · ' + (n.department||'').slice(0,12))}</span>
    </div>`;
  }).join('');
}

function renderCompareColHybrid(data, idSets, uniqueIds) {
  const el = document.getElementById('cmp-hybrid');
  const insightEl = document.getElementById('cmp-hybrid-insight');
  const notes = data?.matching_notes || [];

  if (!notes.length) {
    el.innerHTML = '<div class="compare-empty">No results</div>';
    return;
  }

  el.innerHTML = notes.map(n => {
    const isUnique = uniqueIds.includes(n.note_id);
    return `<div class="compare-note-row ${isUnique ? 'unique' : ''}">
      <span class="compare-note-id">${esc(n.note_id)}</span>
      <span>${esc((n.note_type||'') + ' · ' + (n.department||'').slice(0,12))}</span>
      ${isUnique ? '<span title="Only Hybrid found this">⭐</span>' : ''}
    </div>`;
  }).join('');

  // Insight message
  const allMissed = [...idSets.hybrid].filter(id =>
    !idSets.keyword.has(id) || !idSets.boolean.has(id) || !idSets.semantic.has(id)
  ).length;

  if (insightEl) {
    const boolGain   = [...idSets.hybrid].filter(id => !idSets.boolean.has(id)).length;
    const semGain    = [...idSets.hybrid].filter(id => !idSets.semantic.has(id)).length;
    const kwGain     = [...idSets.hybrid].filter(id => !idSets.keyword.has(id)).length;
    const parts = [];
    if (kwGain)   parts.push(`+${kwGain} vs Keyword`);
    if (boolGain) parts.push(`+${boolGain} vs Boolean`);
    if (semGain)  parts.push(`+${semGain} vs Semantic`);
    insightEl.textContent = parts.length
      ? `✅ Hybrid found ${parts.join(', ')} — combining BM25 recall, synonym expansion, and semantic understanding.`
      : '✅ All approaches agree on this query. Hybrid still ensures best ordering via score fusion.';
  }
}

// ── Main render ───────────────────────────────────────────────
function render(data) {
  try {
    document.getElementById('results-area').style.display = 'block';

    const count = data.total_results || 0;
    const ms = (data.search_time_ms || 0).toFixed(0);
    document.getElementById('status-text').innerHTML =
      `<strong>${count}</strong> notes · ${ms} ms`;

    const approach = data.approach_used || state.approach;
    const badge = document.getElementById('approach-badge');
    badge.className = `approach-badge approach-${approach}`;
    badge.textContent = approach.toUpperCase();

    renderNegationInfo(data.interpreted_query);

    const list = document.getElementById('results-list');
    const noR  = document.getElementById('no-results');
    list.innerHTML = '';
    if (!data.matching_notes || data.matching_notes.length === 0) {
      noR.style.display = 'block';
    } else {
      noR.style.display = 'none';
      data.matching_notes.forEach((note, i) => {
        list.appendChild(buildNoteCard(note, i));
      });
    }

    renderResearch(data.research_results || []);
  } catch (e) {
    console.error('Render error:', e);
    document.getElementById('results-list').innerHTML =
      `<div style="padding:16px;color:var(--c-red)">⚠️ Render Error: ${esc(e.message)}</div>`;
  }
}



// ── Negation bar ──────────────────────────────────────────────
function renderNegationInfo(interp) {
  const bar  = document.getElementById('negation-info');
  const text = document.getElementById('negation-info-text');
  if (!interp?.must_exclude?.length) { bar.style.display = 'none'; return; }
  bar.style.display = 'flex';
  const excStr = interp.must_exclude.join(', ');
  text.textContent = interp.mode === 'literal'
    ? `Literal mode: any note containing "${excStr}" (even negated) is excluded.`
    : `Clinical mode: notes with negated "${excStr}" (e.g. "no ${excStr} history") are INCLUDED. Only active cases excluded.`;
}

// ── Note card (expandable) ────────────────────────────────────
function buildNoteCard(note, index) {

  const evidArr    = note.highlighted_evidence || note.matched_evidence || [];
  const delay      = Math.min(index * 0.04, 0.3);
  const fullText   = note.text || '';

  const card = document.createElement('div');
  card.className = 'note-card';
  card.style.animationDelay = `${delay}s`;

  card.innerHTML = `
    <div class="note-header" onclick="toggleNote(this.parentElement)">
      <div>
        <div class="note-ids">
          <div class="note-id">${esc(note.note_id)}</div>
          <div class="note-patient">Patient ${esc(note.patient_id || '—')}</div>
        </div>
        <div class="note-meta-tags" style="margin-top:5px;">
          ${note.note_type   ? `<span class="meta-tag">${esc(note.note_type)}</span>`   : ''}
          ${note.department  ? `<span class="meta-tag">${esc(note.department)}</span>`  : ''}
          ${note.date        ? `<span class="meta-tag">${esc(note.date)}</span>`        : ''}
          ${note.doctor      ? `<span class="meta-tag">👨‍⚕️ ${esc(note.doctor)}</span>`  : ''}
        </div>
      </div>
      <div class="note-right">
        <div class="expand-icon">▼</div>
      </div>
    </div>
    
    ${evidArr.length ? `
      <div class="evidence-section" onclick="toggleNote(this.parentElement)" style="padding: 0 16px 14px 16px; cursor: pointer;">
        <div class="evidence-label" style="margin-bottom: 8px; font-size: 10px; color: var(--text-muted); opacity: 0.9; letter-spacing: 0.08em; display: flex; align-items: center; gap: 6px; text-transform: uppercase; font-weight: 700;">🚀 EVIDENCE</div>
        <div class="evidence-snippet">
          ${evidArr.slice(0, 3).map(e => `${colorize(e)}`).join('<br/><br/>')}
        </div>
      </div>
    ` : ''}

    <div class="note-body">
      ${fullText ? `
        <div style="margin-top:10px;">
          <div class="note-full-text-label">📄 Full Note Text</div>
          <div class="note-full-text">${esc(fullText)}</div>
        </div>
      ` : ''}

      ${note.why_matched ? `<div class="why-matched">${formatWhyMatched(note.why_matched)}</div>` : ''}

    </div>
  `;

  return card;
}

function toggleNote(card) {
  card.classList.toggle('expanded');
}



// ── Color marker parser ───────────────────────────────────────
function colorize(text) {
  if (!text) return '';
  const VALID_COLORS = new Set(['green','blue','purple','orange','teal']);
  const spans = [];
  const PLACEHOLDER = i => `CLRSPAN${i}ENDSPAN`;

  let t = text.replace(/<<(\w+):\s*([^>]*?)\s*>>/g, (_, color, term) => {
    const cls = VALID_COLORS.has(color) ? `hl-${color}` : 'hl-green';
    const i = spans.length;
    spans.push(`<span class="${cls}">${esc(term)}</span>`);
    return PLACEHOLDER(i);
  });

  t = t.replace(/\*\*([^*]+)\*\*/g, (_, term) => {
    const i = spans.length;
    spans.push(`<span class="hl-green">${esc(term)}</span>`);
    return PLACEHOLDER(i);
  });

  let safe = esc(t);
  for (let i = 0; i < spans.length; i++) {
    safe = safe.replace(esc(PLACEHOLDER(i)), spans[i]);
  }
  return safe;
}

function formatWhyMatched(text) {
  if (!text) return '';
  return esc(text).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
}

// ── Research panel (expandable) ───────────────────────────────
function renderResearch(abstracts) {
  const body = document.getElementById('research-body');
  const countEl = document.getElementById('research-count');
  if (!abstracts || abstracts.length === 0) {
    body.innerHTML = `<p style="font-size:11px;color:var(--text-muted);padding:4px;">No research abstracts matched.</p>`;
    if (countEl) countEl.textContent = '';
    return;
  }
  if (countEl) countEl.textContent = `${abstracts.length} found`;

  body.innerHTML = abstracts.map((ab, i) => {

    const abstract = ab.abstract || ab.text || ab.why_relevant || '';
    return `
      <div class="research-item" onclick="toggleResearch(this)" style="animation-delay:${i * 0.05}s">
        <div class="research-item-header">
          <div class="research-title">${esc(ab.title)}</div>
          <div class="research-expand-icon">▼</div>
        </div>
        <div class="research-meta">
          <span class="research-meta-tag">📖 ${esc(ab.journal || ab.source || 'Dataset')}</span>
          ${ab.year ? `<span class="research-meta-tag">${ab.year}</span>` : ''}
        </div>
        ${ab.why_relevant ? `<div class="research-why">💡 ${esc(ab.why_relevant)}</div>` : ''}
        ${abstract ? `<div class="research-body-text">${esc(abstract)}</div>` : ''}
      </div>
    `;
  }).join('');
}

function toggleResearch(item) {
  item.classList.toggle('expanded');
}

// ── Stats panel ───────────────────────────────────────────────
function renderStats(data) {
  const interp = data.interpreted_query || {};
  document.getElementById('stats-body').innerHTML = `
    <div class="stat-row"><span class="stat-key">Notes found</span><span class="stat-val">${data.total_results}</span></div>
    <div class="stat-row"><span class="stat-key">Research</span><span class="stat-val">${data.total_research || 0}</span></div>
    <div class="stat-row"><span class="stat-key">Latency</span><span class="stat-val">${(data.search_time_ms || 0).toFixed(1)} ms</span></div>
    <div class="stat-row"><span class="stat-key">Approach</span><span class="stat-val">${(data.approach_used || '—').toUpperCase()}</span></div>
    <div class="stat-row"><span class="stat-key">Negation</span><span class="stat-val">${(interp.mode || '—').replace('_',' ')}</span></div>
    <div class="stat-row"><span class="stat-key">AND concepts</span><span class="stat-val">${(interp.must_include || []).length}</span></div>
    <div class="stat-row"><span class="stat-key">OR concepts</span><span class="stat-val">${(interp.or_include || []).length}</span></div>
    <div class="stat-row"><span class="stat-key">Excluded</span><span class="stat-val">${(interp.must_exclude || []).length}</span></div>
  `;
}

// ── JSON panel ────────────────────────────────────────────────
function renderJsonPanel(interp) {
  const pre = document.getElementById('json-preview');
  if (!interp) { pre.textContent = ''; return; }
  pre.textContent = JSON.stringify({
    must_include: interp.must_include,
    or_include:   interp.or_include,
    must_exclude: interp.must_exclude,
    mode:         interp.mode,
    approach:     interp.approach,
  }, null, 2);
}

// ── Error state ───────────────────────────────────────────────
function renderError(msg) {
  document.getElementById('results-area').style.display = 'block';
  document.getElementById('results-list').innerHTML = `
    <div style="background:rgba(248,81,73,.07);border:1px solid rgba(248,81,73,.25);
      border-radius:var(--radius-lg);padding:20px;color:var(--c-red);font-size:13px;">
      <strong>⚠️ Search Error</strong><br/>
      <span style="color:var(--text-secondary);font-size:12px;display:block;margin-top:6px;">
        ${esc(msg)}<br/><br/>
        Server: <code style="font-family:monospace">uvicorn api.main:app --reload</code>
      </span>
    </div>
  `;
  document.getElementById('no-results').style.display = 'none';
  document.getElementById('negation-info').style.display = 'none';
}

// ── Loading ───────────────────────────────────────────────────
function setLoading(on) {
  const btn = document.getElementById('search-btn');
  btn.disabled = on;
  btn.innerHTML = on ? '⏳ Searching…' : '⚡ Search';
  document.getElementById('loading-state').style.display = on ? 'flex' : 'none';
  if (on) document.getElementById('results-area').style.display = 'none';
}

// ── Helpers ───────────────────────────────────────────────────
function esc(s) {
  if (!s) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ── Research ──────────────────────────────────────────────────
function renderResearch(results) {
  const panel = document.getElementById('side-panel');
  const body = document.getElementById('research-body');
  if (!panel || !body) return;
  if (!results || !results.length) {
    panel.style.display = 'none';
    return;
  }
  panel.style.display = 'block';
  body.innerHTML = results.map(r => {
    return `
      <div class="research-card" onclick="this.classList.toggle('expanded')">
        <div class="research-title">${esc(r.title)}</div>
        <div class="research-meta">${esc(r.journal)} · ${r.year}</div>
        <div class="research-body" style="display:none; margin-top:8px; font-size:11px; color:var(--text-secondary); line-height:1.4;">
          ${esc(r.abstract)}
        </div>
      </div>
    `;
  }).join('');
}
