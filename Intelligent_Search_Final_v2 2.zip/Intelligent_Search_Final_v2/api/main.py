from __future__ import annotations
"""
main.py
=======
FastAPI application entry point for the Intelligent Clinical Search API.

Run with:
    uvicorn api.main:app --reload --port 8000
"""

import sys
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

sys.path.insert(0, str(Path(__file__).parent.parent))

from api.routes.search import router as search_router
from api.routes.data import router as data_router
from config.settings import API_HOST, API_PORT, API_DEBUG

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Intelligent Clinical Search API",
    description=(
        "Hybrid search across clinical notes and medical research. "
        "Supports Boolean logic, synonym expansion, semantic embeddings, "
        "and negation-aware filtering."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routes ────────────────────────────────────────────────────────────────────
app.include_router(search_router, prefix="/api")
app.include_router(data_router, prefix="/api/data")

# ── Serve UI ──────────────────────────────────────────────────────────────────
UI_DIR = Path(__file__).parent.parent / "ui"

if UI_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(UI_DIR)), name="static")

    @app.get("/", include_in_schema=False)
    async def serve_ui():
        return FileResponse(str(UI_DIR / "index.html"))

# ── Startup event ─────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    print("=" * 60)
    print("  🏥 Intelligent Clinical Search API")
    print("  http://localhost:8000")
    print("  Swagger docs: http://localhost:8000/docs")
    print("=" * 60)


# ── Dev runner ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api.main:app",
        host=API_HOST,
        port=API_PORT,
        reload=API_DEBUG,
    )
