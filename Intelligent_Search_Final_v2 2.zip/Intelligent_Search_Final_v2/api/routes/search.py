from __future__ import annotations
"""
search.py
=========
FastAPI router: POST /api/search
"""

import time
import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from api.models.request_models import SearchRequest
from query.query_parser import QueryParser
from query.structured_query import NegationMode, SearchApproach
from retrieval.boolean_retriever import BooleanRetriever
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.reranker import LLMReranker, CrossEncoderReranker
from config.settings import USE_CROSS_ENCODER
from research.research_retriever import ResearchRetriever
from postprocess.result_formatter import format_response

# Lazy import for semantic retriever (requires sentence-transformers / torch)
_SemanticRetriever = None
def _get_semantic_retriever():
    global _SemanticRetriever
    if _SemanticRetriever is None:
        try:
            from retrieval.semantic_retriever import SemanticRetriever
            _SemanticRetriever = SemanticRetriever()
        except Exception as e:
            raise HTTPException(status_code=500,
                detail=f"Semantic retriever unavailable: {e}. Install sentence-transformers.")
    return _SemanticRetriever



router = APIRouter()

# ── Singleton instances (loaded once at startup) ──────────────────────────────
_parser = QueryParser()
_boolean_retriever = BooleanRetriever()
_hybrid_retriever = HybridRetriever()
_research_retriever = ResearchRetriever()

if USE_CROSS_ENCODER:
    _reranker = CrossEncoderReranker()
else:
    _reranker = LLMReranker()


@router.post("/search")
async def search(req: SearchRequest) -> dict:
    """
    Main search endpoint.

    Accepts a query string and returns matching clinical notes + research abstracts.
    """
    t0 = time.perf_counter()

    # ── Parse query ────────────────────────────────────────────────────────────
    try:
        structured_query = _parser.parse(
            raw_query=req.query,
            mode=NegationMode(req.mode),
            approach=SearchApproach(req.approach),
            top_k=req.top_k,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Query parsing failed: {e}")

    # ── Retrieve notes ─────────────────────────────────────────────────────────
    approach_used = req.approach
    try:
        if req.approach == "keyword":
            # Pure BM25 keyword search — no synonym expansion, no Boolean filters
            from indexing.bm25_indexer import BM25Indexer
            _bm25_raw = BM25Indexer()
            raw_notes = _bm25_raw.search_raw(req.query, top_k=req.top_k)
            notes = [{**n, "bm25_score": n.get("bm25_score", 0), "vector_score": 0, "boolean_score": 0,
                      "hybrid_score": n.get("bm25_score", 0), "score": n.get("bm25_score", 0),
                      "why_matched": f"Keyword match on raw query",
                      "highlighted_evidence": [n.get("text","")[:200]]} for n in raw_notes]
        elif req.approach == "boolean":
            notes = _boolean_retriever.retrieve(structured_query)
        elif req.approach == "semantic":
            try:
                notes = _get_semantic_retriever().retrieve(structured_query)
            except HTTPException:
                notes = _hybrid_retriever.retrieve(structured_query)
                approach_used = "hybrid"
        else:  # hybrid
            notes = _hybrid_retriever.retrieve(structured_query)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Retrieval failed: {e}")

    # ── Retrieve research ──────────────────────────────────────────────────────
    research = []
    if req.include_research:
        try:
            research = _research_retriever.retrieve(structured_query, top_k=5)
        except Exception:
            research = []  # Gracefully degrade if research index not built

    # ── Rerank notes ───────────────────────────────────────────────────────────
    if notes and _reranker.enabled:
        notes = _reranker.rerank(structured_query, notes)

    elapsed_ms = (time.perf_counter() - t0) * 1000

    return format_response(
        query=structured_query,
        notes=notes,
        research=research,
        search_time_ms=elapsed_ms,
        approach_used=approach_used,
    )


@router.get("/health")
async def health() -> dict:
    """Health check endpoint."""
    return {"status": "ok", "service": "Intelligent Clinical Search"}
