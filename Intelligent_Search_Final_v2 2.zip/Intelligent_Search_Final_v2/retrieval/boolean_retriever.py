from __future__ import annotations
"""
boolean_retriever.py
====================
Approach 1: Pure Boolean / keyword retrieval with synonym expansion.

Algorithm:
  1. Gather all synonyms from must_include AND or_include groups
  2. BM25 search for candidates matching ANY expanded term
  3. Apply hard AND filter: ALL must_include groups must be present
  4. Apply OR filter: at least one or_include group must be present (if any)
  5. Apply negation filter: no must_exclude groups active (per mode)
  6. Score by synonym match count + BM25 score
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery, NegationMode
from query.negation_handler import apply_exclusion_filter, is_concept_negated
from indexing.bm25_indexer import BM25Indexer


class BooleanRetriever:
    """
    Keyword + Boolean retriever using BM25 index and synonym expansion.

    Supports:
      - Hard AND constraints (ALL must_include groups present)
      - Soft OR constraints (ANY or_include group present)
      - Negation-aware NOT via apply_exclusion_filter
    """

    def __init__(self):
        self._indexer = BM25Indexer()

    def retrieve(self, query: StructuredQuery) -> list[dict]:
        """
        Execute Boolean retrieval.

        Args:
            query: Fully parsed and synonym-expanded StructuredQuery

        Returns:
            Ranked list of matching note dicts with scores and evidence fields
        """
        has_and = bool(query.must_include)
        has_or  = bool(query.or_include)

        if not has_and and not has_or:
            return []

        # Fetch broad candidate set using ALL synonyms (AND + OR)
        all_include_syns = query.all_include_synonyms
        candidates = self._indexer.search_notes(all_include_syns, top_k=500)

        if not candidates:
            return []

        # ── Hard AND filter: ALL must_include groups must appear ──────────────
        if has_and:
            candidates = [
                n for n in candidates
                if all(
                    cg.matches(n["text"]) and not is_concept_negated(n["text"], cg.synonyms)
                    for cg in query.must_include
                )
            ]

        # ── Soft OR filter: AT LEAST ONE or_include group must appear ─────────
        if has_or:
            candidates = [
                n for n in candidates
                if any(
                    cg.matches(n["text"]) and not is_concept_negated(n["text"], cg.synonyms)
                    for cg in query.or_include
                )
            ]

        # ── Exclusion / NOT filter ────────────────────────────────────────────
        if query.must_exclude:
            candidates, _ = apply_exclusion_filter(
                candidates,
                query.must_exclude,
                mode=query.negation_mode,
            )

        # ── Score and annotate ────────────────────────────────────────────────
        scored = self._score_and_annotate(candidates, query)
        scored.sort(key=lambda x: (-x["boolean_score"], -x.get("bm25_score", 0)))
        return scored[: query.top_k]

    # ─────────────────────────────────────────────────────────────────────────

    def _score_and_annotate(self, notes: list[dict], query: StructuredQuery) -> list[dict]:
        """
        Add boolean_score, matched_synonyms (with concept tag), and why_matched.

        boolean_score:
          - AND queries: groups_matched / total_and_groups
          - OR queries: 1.0 if any OR group matched, 0.5 if partial
          - Mixed: weighted combination
        """
        and_groups = query.must_include
        or_groups  = query.or_include
        total_and  = len(and_groups)
        result     = []

        for note in notes:
            text_lower = note["text"].lower()
            matched_syns_tagged: list[dict] = []   # {synonym, concept, color_index}
            and_matched = 0

            # AND groups
            for idx, cg in enumerate(and_groups):
                hits = [s for s in cg.synonyms if s.lower() in text_lower]
                if hits:
                    and_matched += 1
                    for h in hits:
                        matched_syns_tagged.append({
                            "synonym": h,
                            "concept": cg.canonical,
                            "color_index": idx % 3,  # 0=green, 1=blue, 2=purple
                        })

            # OR groups
            or_matched = 0
            for idx, cg in enumerate(or_groups):
                hits = [s for s in cg.synonyms if s.lower() in text_lower]
                if hits:
                    or_matched += 1
                    for h in hits:
                        matched_syns_tagged.append({
                            "synonym": h,
                            "concept": cg.canonical,
                            "color_index": (total_and + idx) % 3,
                        })

            # Compute score
            if total_and > 0:
                and_score = and_matched / total_and
            else:
                and_score = 1.0

            if or_groups:
                or_score = 1.0 if or_matched > 0 else 0.0
                bool_score = (and_score + or_score) / 2
            else:
                bool_score = and_score

            note = dict(note)
            note["boolean_score"]    = bool_score
            note["matched_synonyms"] = [t["synonym"] for t in matched_syns_tagged]
            note["matched_concepts_detail"] = matched_syns_tagged
            note["hybrid_score"]     = bool_score
            result.append(note)

        return result
