from __future__ import annotations
"""
semantic_retriever.py
=====================
Approach 2: Pure dense vector / semantic retrieval using FAISS.

Algorithm:
  1. Encode the semantic_intent string using the embedding model
  2. Search FAISS notes index for nearest neighbours
  3. Apply soft exclusion filter (semantic proximity check)

Strengths:
  - Captures meaning, handles paraphrase and unseen synonyms
  - Works for vague clinical exploratory queries
  - Retrieves notes with no exact keyword match

Weaknesses:
  - No hard Boolean enforcement (may violate NOT constraints)
  - Requires index build time + GPU/CPU inference
  - Low interpretability
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from query.negation_handler import apply_exclusion_filter
from indexing.vector_indexer import VectorIndexer


class SemanticRetriever:
    """
    Dense vector retriever using FAISS.

    Uses the semantic_intent field from the StructuredQuery as the query text,
    which gives richer context than the raw query alone.
    """

    def __init__(self):
        self._notes_indexer = VectorIndexer("notes")
        self._loaded = False

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self._notes_indexer.load()
            self._loaded = True

    def retrieve(self, query: StructuredQuery) -> list[dict]:
        """
        Execute semantic retrieval.

        Args:
            query: Parsed StructuredQuery (uses semantic_intent for embedding)

        Returns:
            Ranked list of note dicts with vector_score and hybrid_score
        """
        self._ensure_loaded()

        # Use semantic intent if available, otherwise fall back to raw query
        search_text = query.semantic_intent or query.raw_query
        candidates = self._notes_indexer.search(search_text, top_k=query.top_k * 3)

        if not candidates:
            return []

        # Apply soft exclusion: remove obvious hard constraint violations
        # (semantic search doesn't enforce Boolean, but we try our best)
        if query.must_exclude:
            candidates, _ = apply_exclusion_filter(
                candidates,
                query.must_exclude,
                mode=query.negation_mode,
            )

        # Annotate with hybrid_score (= vector_score for this approach)
        for note in candidates:
            note["boolean_score"] = 0.0
            note["bm25_score"] = 0.0
            note["hybrid_score"] = note.get("vector_score", 0.0)
            note["matched_synonyms"] = []

        return candidates[: query.top_k]
