from __future__ import annotations
"""
research_retriever.py
=====================
Retrieves relevant research abstracts for a given StructuredQuery.

Uses both BM25 (keyword match) and vector similarity, then fuses results.
Returns the top-k most relevant abstracts alongside clinical note results.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import StructuredQuery
from indexing.bm25_indexer import BM25Indexer
from indexing.vector_indexer import VectorIndexer
from postprocess.score_fusion import pool_results, fuse_scores


class ResearchRetriever:
    """
    Retrieves relevant research abstracts in parallel with clinical note search.

    Uses both BM25 and vector search against the separate research index.
    """

    def __init__(self):
        self._bm25 = BM25Indexer()
        self._vector = VectorIndexer("research")
        self._vector_loaded = False

    def _ensure_vector_loaded(self) -> None:
        if not self._vector_loaded:
            try:
                self._vector.load()
                self._vector_loaded = True
            except FileNotFoundError:
                self._vector_loaded = False

    def retrieve(self, query: StructuredQuery, top_k: int = 5) -> list[dict]:
        """
        Retrieve top-k relevant research abstracts.

        Args:
            query:  The StructuredQuery (uses synonyms + semantic intent)
            top_k:  Maximum abstracts to return

        Returns:
            List of abstract dicts with relevance scores
        """
        all_syns = query.all_include_synonyms or [query.raw_query]

        # BM25 search
        bm25_results = self._bm25.search_research(all_syns, top_k=top_k * 3)

        # Vector search
        self._ensure_vector_loaded()
        search_text = query.semantic_intent or query.raw_query
        vector_results = (
            self._vector.search(search_text, top_k=top_k * 2)
            if self._vector_loaded
            else []
        )

        # Pool and fuse
        pooled = pool_results(bm25_results, vector_results, id_field="abstract_id")
        fused = fuse_scores(pooled)

        return fused[:top_k]
