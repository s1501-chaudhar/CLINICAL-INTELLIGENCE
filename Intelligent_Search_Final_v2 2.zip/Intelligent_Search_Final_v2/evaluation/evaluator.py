from __future__ import annotations
"""
evaluator.py
============
Evaluation framework for the Intelligent Search PoC.

Computes:
  - Precision@k
  - Recall@k
  - MRR (Mean Reciprocal Rank)
  - Boolean accuracy (AND/NOT constraint satisfaction rate)
  - Synonym recall (% of synonym variants retrieved)
  - Negation accuracy (literal vs clinical_concept mode)
"""

import json
import sys
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.query_parser import QueryParser
from query.structured_query import NegationMode, SearchApproach
from retrieval.boolean_retriever import BooleanRetriever
from retrieval.hybrid_retriever import HybridRetriever


class SearchEvaluator:
    """
    Evaluates retrieval quality against ground-truth tag-based test sets.

    Since we don't have explicit 'relevant note IDs', we use ground_truth_tags
    attached to each note to determine relevance:
      - A result is RELEVANT if its ground_truth_tags intersect expected_tags_include
      - A result is IRRELEVANT if its ground_truth_tags intersect expected_tags_exclude
    """

    def __init__(self, notes_path: Path | str = "data/raw/clinical_notes/notes.json"):
        self._parser = QueryParser()
        self._boolean_retriever = BooleanRetriever()
        self._hybrid_retriever = HybridRetriever()

        notes_file = Path(notes_path)
        if not notes_file.exists():
            raise FileNotFoundError(
                f"Notes corpus not found: {notes_file}\n"
                "Please ensure the data is generated."
            )
        with open(notes_file) as f:
            self._all_notes = json.load(f)

    def _is_relevant(self, note: dict, expected_include_tags: list[str]) -> bool:
        """A note is relevant if ANY of its ground_truth_tags are in expected_include_tags."""
        note_tags = set(note.get("ground_truth_tags", note.get("metadata", {}).get("ground_truth_tags", [])))
        return bool(note_tags & set(expected_include_tags))

    def _should_be_excluded(self, note: dict, expected_exclude_tags: list[str]) -> bool:
        """A note should be excluded if ANY of its tags are in expected_exclude_tags."""
        note_tags = set(note.get("ground_truth_tags", note.get("metadata", {}).get("ground_truth_tags", [])))
        return bool(note_tags & set(expected_exclude_tags))

    def precision_at_k(self, results: list[dict], expected_include: list[str], k: int) -> float:
        """Precision@k: fraction of top-k results that are relevant."""
        if not results:
            return 0.0
        top_k = results[:k]
        relevant = sum(1 for r in top_k if self._is_relevant(r, expected_include))
        return relevant / len(top_k)

    def recall_at_k(self, results: list[dict], expected_include: list[str], k: int) -> float:
        """Recall@k: fraction of all relevant notes in corpus retrieved in top-k."""
        total_relevant = sum(
            1 for n in self._all_notes
            if self._is_relevant(n, expected_include)
        )
        if total_relevant == 0:
            return 1.0
        top_k = results[:k]
        retrieved_relevant = sum(1 for r in top_k if self._is_relevant(r, expected_include))
        return retrieved_relevant / total_relevant

    def mrr(self, results: list[dict], expected_include: list[str]) -> float:
        """Mean Reciprocal Rank: 1/rank of first relevant result."""
        for i, result in enumerate(results):
            if self._is_relevant(result, expected_include):
                return 1.0 / (i + 1)
        return 0.0

    def boolean_accuracy(self, results: list[dict], expected_exclude: list[str]) -> float:
        """
        Boolean accuracy: fraction of results that do NOT violate NOT constraints.
        i.e., none of the returned notes should have excluded tags.
        """
        if not expected_exclude:
            return 1.0
        violations = sum(
            1 for r in results if self._should_be_excluded(r, expected_exclude)
        )
        return 1.0 - (violations / len(results)) if results else 1.0

    def evaluate_test_case(self, test: dict, k: int = 10) -> dict:
        """Run a single test case and return metrics."""
        query = test["query"]
        approach = test.get("approach", "boolean")
        mode = test.get("mode", "literal")
        expected_include = test.get("expected_tags_include", [])
        expected_exclude = test.get("expected_tags_exclude", [])

        # Parse
        sq = self._parser.parse(
            query,
            mode=NegationMode(mode),
            approach=SearchApproach(approach),
            top_k=50,
        )

        # Retrieve
        if approach == "boolean":
            results = self._boolean_retriever.retrieve(sq)
        else:
            results = self._hybrid_retriever.retrieve(sq)

        # Metrics
        p_at_5 = self.precision_at_k(results, expected_include, k=5)
        p_at_10 = self.precision_at_k(results, expected_include, k=10)
        r_at_10 = self.recall_at_k(results, expected_include, k=10)
        mrr_score = self.mrr(results, expected_include)
        bool_acc = self.boolean_accuracy(results, expected_exclude)

        return {
            "test_id": test["test_id"],
            "query": query,
            "approach": approach,
            "mode": mode,
            "num_results": len(results),
            "precision@5": round(p_at_5, 3),
            "precision@10": round(p_at_10, 3),
            "recall@10": round(r_at_10, 3),
            "mrr": round(mrr_score, 3),
            "boolean_accuracy": round(bool_acc, 3),
            "description": test.get("description", ""),
        }

    def evaluate_all(self, test_path: str = "data/test_queries/boolean_test_set.json") -> list[dict]:
        """Run all test cases and return results."""
        test_file = Path(test_path)
        if not test_file.exists():
            print(f"⚠️  Test file not found: {test_file}")
            return []

        with open(test_file) as f:
            test_cases = json.load(f)

        print(f"\n🧪 Running {len(test_cases)} evaluation test cases...\n")
        results = []
        for test in test_cases:
            try:
                metrics = self.evaluate_test_case(test)
                results.append(metrics)
                status = "✅" if metrics["boolean_accuracy"] >= 0.9 else "⚠️ "
                print(
                    f"{status} [{metrics['test_id']}] {metrics['query'][:50]:52s} "
                    f"P@5={metrics['precision@5']:.2f} MRR={metrics['mrr']:.2f} "
                    f"BoolAcc={metrics['boolean_accuracy']:.2f}"
                )
            except Exception as e:
                print(f"❌ [{test['test_id']}] Error: {e}")

        self._print_summary(results)
        return results

    def _print_summary(self, results: list[dict]) -> None:
        if not results:
            return

        def avg(key):
            vals = [r[key] for r in results if key in r]
            return sum(vals) / len(vals) if vals else 0.0

        print("\n" + "=" * 70)
        print("  EVALUATION SUMMARY")
        print("=" * 70)
        print(f"  Tests run          : {len(results)}")
        print(f"  Avg Precision@5    : {avg('precision@5'):.3f}")
        print(f"  Avg Precision@10   : {avg('precision@10'):.3f}")
        print(f"  Avg Recall@10      : {avg('recall@10'):.3f}")
        print(f"  Avg MRR            : {avg('mrr'):.3f}")
        print(f"  Avg Boolean Acc    : {avg('boolean_accuracy'):.3f}")
        print("=" * 70)


if __name__ == "__main__":
    evaluator = SearchEvaluator()
    evaluator.evaluate_all()
