from __future__ import annotations
"""
query_parser.py
===============
Converts a natural language or Boolean query string into a StructuredQuery.

Supports:
  - Explicit Boolean: "pneumonia AND ibuprofen", "blister NOT cancer", "A OR B"
  - Natural language: "notes that do not contain cancer but contain blister"
  - Multi-include NL: "notes containing pneumonia and ibuprofen"
  - OR: "notes containing pneumonia or bronchitis"
  - Quoted phrases: "chest pain" AND troponin
  - Negation trap: "notes containing no chest pain"
  - Triple: "notes containing rash and ibuprofen but not cancer"
  - Semantic-only: "patients with respiratory infection using painkillers"
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from query.structured_query import (
    BooleanOperator, ConceptGroup, NegationMode, SearchApproach, StructuredQuery
)
from query.synonym_expander import SynonymExpander


# ── Negation cue words (start of phrase) ─────────────────────────────────────
NEGATION_LEAD_WORDS = {
    "no", "not", "without", "denies", "deny", "negative", "absent",
    "absence", "never", "non", "exclude", "excluding", "excluded"
}

# ── Stop words to strip from extracted concept text ──────────────────────────
STOP_WORDS = {
    "notes", "note", "patients", "patient", "with", "that", "the", "a",
    "an", "is", "are", "was", "were", "have", "has", "but", "also",
    "only", "any", "about", "containing", "contain", "contains",
    "showing", "showing", "which", "who", "where", "find", "search",
    "for", "of", "in",
}


def _clean_concept(text: str) -> str:
    text = text.strip().strip("'\",.").strip()
    tokens = [t for t in text.split() if t.lower() not in STOP_WORDS]
    return " ".join(tokens).strip().lower()


def _is_negation_phrase(phrase: str) -> bool:
    """Returns True if a phrase starts with a negation word."""
    first_word = phrase.strip().lower().split()[0] if phrase.strip() else ""
    return first_word in NEGATION_LEAD_WORDS


class QueryParser:
    """
    Rule-based query parser supporting:
      1. Structured Boolean: "A AND B NOT C", "A OR B"
      2. Natural language: "notes containing X and Y but not Z"
      3. Negation trap: "notes containing no chest pain"
      4. Semantic fall-through: vague phrases go to semantic retrieval
    """

    def __init__(self, expander: SynonymExpander | None = None):
        self.expander = expander or SynonymExpander()

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    def parse(
        self,
        raw_query: str,
        mode: NegationMode = NegationMode.CLINICAL_CONCEPT,
        approach: SearchApproach = SearchApproach.HYBRID,
        top_k: int = 10,
    ) -> StructuredQuery:
        """
        Parse the raw query string into a StructuredQuery.

        Returns:
            StructuredQuery with fully expanded concept groups
        """
        q = raw_query.strip()

        # Keyword approach bypasses NLP and synonym expansion
        if approach == SearchApproach.KEYWORD:
            return StructuredQuery(
                raw_query=raw_query,
                must_include=[],
                or_include=[],
                must_exclude=[],
                semantic_intent=raw_query,
                negation_mode=mode,
                approach=approach,
                top_k=top_k,
            )

        # Decide parsing strategy
        if self._is_explicit_boolean(q):
            include_terms, or_terms, exclude_terms = self._parse_explicit_boolean(q)
        else:
            include_terms, or_terms, exclude_terms = self._parse_natural_language(q)

        # If nothing was extracted, treat entire query as semantic
        if not include_terms and not or_terms and not exclude_terms:
            return StructuredQuery(
                raw_query=raw_query,
                must_include=[],
                or_include=[],
                must_exclude=[],
                semantic_intent=raw_query,
                negation_mode=mode,
                approach=approach,
                top_k=top_k,
            )

        # Expand synonyms for each concept
        must_include = [self.expander.expand(t) for t in include_terms]
        or_include   = [self.expander.expand(t) for t in or_terms]
        must_exclude = [self.expander.expand(t) for t in exclude_terms]

        semantic_intent = self._build_semantic_intent(include_terms + or_terms, exclude_terms)

        return StructuredQuery(
            raw_query=raw_query,
            must_include=must_include,
            or_include=or_include,
            must_exclude=must_exclude,
            semantic_intent=semantic_intent,
            negation_mode=mode,
            approach=approach,
            top_k=top_k,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Strategy 1: Explicit Boolean (uppercase AND / OR / NOT)
    # ─────────────────────────────────────────────────────────────────────────

    def _is_explicit_boolean(self, q: str) -> bool:
        return bool(re.search(r'\b(AND|OR|NOT)\b', q))

    def _parse_explicit_boolean(self, q: str) -> tuple[list[str], list[str], list[str]]:
        """
        Parse structured Boolean queries like:
            "pneumonia AND ibuprofen NOT cancer"
            "pneumonia OR bronchitis"
            '"chest pain" AND troponin'
        """
        include_terms: list[str] = []
        or_terms: list[str] = []
        exclude_terms: list[str] = []

        tokens = self._tokenise_boolean(q)

        i = 0
        current_op = "AND"  # first token defaults to AND
        while i < len(tokens):
            token = tokens[i]

            if token.upper() in ("AND",):
                current_op = "AND"
                i += 1
                continue
            elif token.upper() == "OR":
                current_op = "OR"
                i += 1
                continue
            elif token.upper() == "NOT":
                current_op = "NOT"
                i += 1
                continue
            else:
                term = _clean_concept(token)
                if term:
                    if current_op == "NOT":
                        exclude_terms.append(term)
                        current_op = "AND"  # reset
                    elif current_op == "OR":
                        or_terms.append(term)
                    else:
                        include_terms.append(term)
                i += 1

        return include_terms, or_terms, exclude_terms

    def _tokenise_boolean(self, q: str) -> list[str]:
        """Split on Boolean operators, preserving quoted phrases and multi-word synonyms."""
        tokens: list[str] = []
        remaining = q

        # Extract quoted phrases first
        quoted_phrases: list[str] = []
        for ph in re.findall(r'"[^"]+"', remaining):
            remaining = remaining.replace(ph, f"__PHRASE_{len(quoted_phrases)}__")
            quoted_phrases.append(ph.strip('"'))

        # Extract known multi-word clinical synonyms so they don't get split
        multi_word_syns: set[str] = set()
        for syns in self.expander.synonyms.values():
            for syn in syns:
                syn_clean = syn.strip()
                if " " in syn_clean:
                    multi_word_syns.add(syn_clean.lower())
        
        sorted_mw_syns = sorted(list(multi_word_syns), key=len, reverse=True)
        
        for mw_syn in sorted_mw_syns:
            pattern = re.compile(rf'\b{re.escape(mw_syn)}\b', re.IGNORECASE)
            
            def repl(m):
                quoted_phrases.append(m.group(0))
                return f" __PHRASE_{len(quoted_phrases)-1}__ "
                
            if pattern.search(remaining):
                remaining = pattern.sub(repl, remaining)

        # Split on whitespace
        parts = remaining.split()
        result = []
        for part in parts:
            if part.startswith("__PHRASE_"):
                idx = int(re.search(r'\d+', part).group())
                result.append(quoted_phrases[idx])
            elif part.upper() in ("AND", "OR", "NOT"):
                result.append(part.upper())
            elif part:
                result.append(part)

        return result

    # ─────────────────────────────────────────────────────────────────────────
    # Strategy 2: Natural Language
    # ─────────────────────────────────────────────────────────────────────────

    def _parse_natural_language(self, q: str) -> tuple[list[str], list[str], list[str]]:
        """
        Handle natural language queries. Priority order:
          1. "do not contain X but contain Y" pattern
          2. "contain X but not Y" / "contain X and Y but not Z"
          3. "X or Y" splitting
          4. "contain X and Y" splitting
          5. Negation trap: "contain no X"
          6. Fallback patterns
        """
        include_terms: list[str] = []
        or_terms: list[str] = []
        exclude_terms: list[str] = []
        q_lower = q.lower()

        # ── Pattern A: "do not contain X but contain Y" ───────────────────────
        dnc = re.search(
            r"do(?:es)?\s+not\s+contain\s+([\w\s]+?)\s+but\s+contain\s+([\w\s]+?)(?:\.|$)",
            q_lower
        )
        if dnc:
            excl = _clean_concept(dnc.group(1))
            incl = _clean_concept(dnc.group(2))
            if excl: exclude_terms.append(excl)
            if incl: include_terms.append(incl)
            return include_terms, or_terms, exclude_terms

        # ── Pattern B: "contain X and Y but not Z" ───────────────────────────
        # e.g. "notes containing rash and ibuprofen but not cancer"
        but_not = re.search(
            r"contain(?:s|ing)?\s+([\w\s,]+?)\s+but\s+not\s+([\w\s]+?)(?:\.|$)",
            q_lower
        )
        if but_not:
            incl_raw = but_not.group(1)
            excl_raw = but_not.group(2)
            # Split include side on " and " or ", "
            for part in re.split(r'\s+and\s+|,\s*', incl_raw):
                t = _clean_concept(part)
                if t: include_terms.append(t)
            excl = _clean_concept(excl_raw)
            if excl: exclude_terms.append(excl)
            return include_terms, or_terms, exclude_terms

        # ── Pattern C: Look for OR first ──────────────────────────────────────
        # "notes containing X or Y"
        or_match = re.search(
            r"contain(?:s|ing)?\s+([\w\s]+?)\s+or\s+([\w\s]+?)(?:\s+but|\s+not|\.|$)",
            q_lower
        )
        if or_match:
            t1 = _clean_concept(or_match.group(1))
            t2 = _clean_concept(or_match.group(2))
            if t1: or_terms.append(t1)
            if t2: or_terms.append(t2)
            # Check for trailing NOT
            not_match = re.search(r'\bnot\s+([\w\s]+?)(?:\.|$)', q_lower[or_match.end():])
            if not_match:
                excl = _clean_concept(not_match.group(1))
                if excl: exclude_terms.append(excl)
            return include_terms, or_terms, exclude_terms

        # ── Pattern D: "contain X and Y and Z" (multi-AND) ───────────────────
        multi_and = re.search(
            r"contain(?:s|ing)?\s+([\w\s]+?)(?:\s+(?:but\s+)?not\s+([\w\s]+?))?(?:\.|$)",
            q_lower
        )
        if multi_and:
            incl_raw = multi_and.group(1)
            excl_raw = multi_and.group(2) if multi_and.group(2) else ""

            # Split on " and " for multiple include concepts
            parts = re.split(r'\s+and\s+', incl_raw)
            for part in parts:
                t = _clean_concept(part)
                if t and not _is_negation_phrase(t):
                    include_terms.append(t)
                elif t and _is_negation_phrase(t):
                    # Negation trap: "containing no chest pain"
                    # The include concept is what comes AFTER the negation word
                    actual = _clean_concept(" ".join(t.split()[1:]))
                    if actual:
                        exclude_terms.append(actual)

            if excl_raw:
                excl = _clean_concept(excl_raw)
                if excl: exclude_terms.append(excl)

            if include_terms or exclude_terms:
                return include_terms, or_terms, exclude_terms

        # ── Pattern E: "without X" exclusion ─────────────────────────────────
        without_m = re.search(r'\bwithout\s+([\w\s]+?)(?:\s+but|\s+and|\s+containing|\.|$)', q_lower)
        if without_m:
            t = _clean_concept(without_m.group(1))
            if t: exclude_terms.append(t)

        # ── Pattern F: "with X and Y" / "with X taking Y" ────────────────────
        if not include_terms:
            with_m = re.search(r'\bwith\s+([\w\s]+?)(?:\s+without|\s+but\s+not|\.|$)', q_lower)
            if with_m:
                parts = re.split(r'\s+and\s+|\s+taking\s+|\s+using\s+', with_m.group(1))
                for part in parts:
                    t = _clean_concept(part)
                    if t: include_terms.append(t)

        # ── Pattern G: "X and not Y" (lowercase and not) ─────────────────────
        if not include_terms and not exclude_terms:
            and_not = re.search(r'([\w\s]+?)\s+and\s+not\s+([\w\s]+?)(?:\.|$)', q_lower)
            if and_not:
                t1 = _clean_concept(and_not.group(1))
                t2 = _clean_concept(and_not.group(2))
                if t1: include_terms.append(t1)
                if t2: exclude_terms.append(t2)

        # ── Pattern H: "X but not Y" / "X not Y" / "X without Y" ─────────────────
        if not include_terms and not exclude_terms:
            not_m = re.search(r'([\w\s]+?)\s+(?:but\s+not|not|without)\s+([\w\s]+?)(?:\.|$)', q_lower)
            if not_m:
                t1 = _clean_concept(not_m.group(1))
                t2 = _clean_concept(not_m.group(2))
                if t1: include_terms.append(t1)
                if t2: exclude_terms.append(t2)

        # ── Pattern I: Simple "X and Y" ──────────────────────────────────────────
        if not include_terms and not exclude_terms:
            and_m = re.search(r'^([\w\s]+?)\s+and\s+([\w\s]+?)$', q_lower)
            if and_m:
                t1 = _clean_concept(and_m.group(1))
                t2 = _clean_concept(and_m.group(2))
                if t1: include_terms.append(t1)
                if t2: include_terms.append(t2)

        # ── Pattern J: Simple "X or Y" ───────────────────────────────────────────
        if not include_terms and not exclude_terms and not or_terms:
            or_m = re.search(r'^([\w\s]+?)\s+or\s+([\w\s]+?)$', q_lower)
            if or_m:
                t1 = _clean_concept(or_m.group(1))
                t2 = _clean_concept(or_m.group(2))
                if t1: or_terms.append(t1)
                if t2: or_terms.append(t2)

        # Deduplicate
        include_terms = list(dict.fromkeys(include_terms))
        or_terms      = list(dict.fromkeys(or_terms))
        exclude_terms = list(dict.fromkeys(exclude_terms))

        return include_terms, or_terms, exclude_terms

    # ─────────────────────────────────────────────────────────────────────────
    # Semantic intent builder
    # ─────────────────────────────────────────────────────────────────────────

    def _build_semantic_intent(self, include_terms: list[str], exclude_terms: list[str]) -> str:
        parts = []
        if include_terms:
            parts.append("Find clinical notes about " + " and ".join(include_terms))
        if exclude_terms:
            parts.append("excluding " + " and ".join(exclude_terms))
        return ". ".join(parts) + "." if parts else ""


# ── Module-level convenience function ────────────────────────────────────────
_default_parser: QueryParser | None = None


def parse_query(
    raw_query: str,
    mode: NegationMode = NegationMode.CLINICAL_CONCEPT,
    approach: SearchApproach = SearchApproach.HYBRID,
    top_k: int = 10,
) -> StructuredQuery:
    """Module-level convenience wrapper around QueryParser."""
    global _default_parser
    if _default_parser is None:
        _default_parser = QueryParser()
    return _default_parser.parse(raw_query, mode=mode, approach=approach, top_k=top_k)


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = QueryParser()

    test_queries = [
        # 1 Basic AND
        "notes containing pneumonia and ibuprofen",
        # 2 OR logic
        "notes containing pneumonia or bronchitis",
        # 3 Classic NOT
        "notes that contain blister but not cancer",
        # 4 Negation trap
        "notes containing no chest pain",
        # 5 Triple AND + NOT
        "notes containing rash and ibuprofen but not cancer",
        # 6 Semantic
        "patients with respiratory infection who used anti-inflammatory pain medication",
        # 7 Quoted phrase
        '"chest pain" AND troponin',
        # 8 diabetes without insulin
        "diabetes and not insulin",
    ]

    for q in test_queries:
        sq = parser.parse(q)
        print(f"\nQuery: {q!r}")
        print(f"  AND include : {[cg.canonical for cg in sq.must_include]}")
        print(f"  OR  include : {[cg.canonical for cg in sq.or_include]}")
        print(f"  exclude     : {[cg.canonical for cg in sq.must_exclude]}")
        print(f"  intent      : {sq.semantic_intent[:80]}")
