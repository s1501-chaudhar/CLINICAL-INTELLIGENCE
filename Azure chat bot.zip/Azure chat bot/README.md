# CodeChat — AI Code Assistant

A ChatGPT-style code assistant with persistent multi-session chat, streaming responses, and a VS Code-inspired dark UI.

**Stack:** ReactJS (Vite) · Python FastAPI · Azure OpenAI · localStorage

---

## Project Structure

```
Chat-bot/
├── backend/
│   ├── main.py              # FastAPI app: /api/health + /api/chat (SSE stream)
│   ├── azure_client.py      # AzureOpenAI client + async streaming generator
│   ├── requirements.txt
│   └── .env.example         # Copy to .env and fill in your credentials
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── Sidebar.jsx        # Session list, new chat, clear history
    │   │   ├── ChatWindow.jsx     # Message list, empty state, typing indicator
    │   │   ├── MessageBubble.jsx  # User/assistant bubbles with markdown
    │   │   ├── MessageInput.jsx   # Auto-grow textarea, send/stop buttons
    │   │   └── CodeBlock.jsx      # Syntax-highlighted code + copy button
    │   ├── hooks/
    │   │   ├── useChatSessions.js # All localStorage + session CRUD logic
    │   │   └── useChatStream.js   # SSE fetch + AbortController
    │   ├── App.jsx
    │   ├── main.jsx
    │   └── index.css
    ├── index.html
    ├── package.json
    └── vite.config.js         # /api proxy → localhost:8000
```

---

## Prerequisites

- **Python 3.10+**
- **Node.js 18+** and npm
- An **Azure OpenAI** resource with a deployed model (GPT-4o recommended)

---

## 1 · Get Your Azure OpenAI Credentials

1. Go to [Azure Portal](https://portal.azure.com) → your Azure OpenAI resource.
2. Under **Keys and Endpoint**, copy:
   - **KEY 1** (your API key)
   - **Endpoint** (e.g. `https://my-resource.openai.azure.com/`)
3. In **Azure OpenAI Studio** → Deployments, note your **deployment name** (e.g. `gpt-4o`).
4. The recommended API version is `2024-02-01`.

---

## 2 · Backend Setup

```bash
# From the project root
cd backend

# Create and activate a virtual environment
python -m venv venv
source venv/bin/activate          # macOS / Linux
# venv\Scripts\activate           # Windows

# Install dependencies
pip install -r requirements.txt

# Configure credentials
cp .env.example .env
# Open .env and fill in:
#   AZURE_OPENAI_API_KEY
#   AZURE_OPENAI_ENDPOINT
#   AZURE_OPENAI_API_VERSION
#   AZURE_OPENAI_DEPLOYMENT_NAME
```

**Start the backend:**

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Verify it's running:
```
GET http://localhost:8000/api/health
→ {"status":"ok","service":"ai-code-assistant"}
```

---

## 3 · Frontend Setup

```bash
# From the project root
cd frontend

# Install dependencies
npm install

# Start the Vite dev server
npm run dev
```

Open **http://localhost:5173** in your browser.

> The Vite dev server proxies all `/api/*` requests to `http://localhost:8000`,
> so no CORS configuration is needed in the browser.

---

## 4 · How It Works

### Memory & Context
The frontend stores **all messages** for each chat session in `localStorage`.  
On every message send, the **entire history** of the active session is sent to the backend → forwarded to Azure OpenAI → giving the model full conversational context within that session.

Switching sessions never mixes histories — each session's `messages[]` array is independent.

### Streaming
Responses stream back via **Server-Sent Events (SSE)**. Each `data:` event carries either:
- `{"token": "..."}` — a text chunk to append
- `{"done": true}` — stream complete
- `{"error": "..."}` — an error message to display

### Session Persistence
Sessions survive page reloads via `localStorage` under the key `chatSessions`.  
The last active session is restored from `activeSessionId`.

---

## 5 · Production Build

```bash
cd frontend
npm run build          # outputs to frontend/dist/
```

Serve `dist/` with any static host (Nginx, Vercel, etc.) and point your backend URL via an environment variable or build-time replace.

---

## 6 · Environment Variables Reference

| Variable | Description |
|---|---|
| `AZURE_OPENAI_API_KEY` | Your Azure OpenAI API key |
| `AZURE_OPENAI_ENDPOINT` | Resource endpoint URL |
| `AZURE_OPENAI_API_VERSION` | API version (e.g. `2024-02-01`) |
| `AZURE_OPENAI_DEPLOYMENT_NAME` | Your model deployment name |

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `Authentication failed` | Double-check `AZURE_OPENAI_API_KEY` in `.env` |
| `Deployment not found` | Verify `AZURE_OPENAI_DEPLOYMENT_NAME` matches Azure Studio |
| `CORS error in browser` | Ensure both servers are running; Vite proxy handles dev CORS |
| `Rate limit exceeded` | Wait a moment; your Azure quota may be low |
| Messages not persisting | Check browser's localStorage isn't disabled or in private mode |
