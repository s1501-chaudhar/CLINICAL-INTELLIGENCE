/**
 * App.jsx
 *
 * Root layout component.
 * Wires together:
 *   - useChatSessions (all session state + localStorage)
 *   - useChatStream   (SSE fetch + abort)
 *   - Sidebar
 *   - ChatWindow
 * Manages input state and sidebar collapsed state (mobile).
 */

import { useState, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatWindow } from './components/ChatWindow';
import { useChatSessions } from './hooks/useChatSessions';
import { useChatStream } from './hooks/useChatStream';

const MenuIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <line x1="3" y1="12" x2="21" y2="12" />
    <line x1="3" y1="6"  x2="21" y2="6"  />
    <line x1="3" y1="18" x2="21" y2="18" />
  </svg>
);

export default function App() {
  const [inputValue, setInputValue] = useState('');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // ----------------------------------------------------------------
  // Session management (state + localStorage)
  // ----------------------------------------------------------------
  const {
    sessions,
    activeSessionId,
    activeSession,
    createSession,
    switchSession,
    deleteSession,
    renameSession,
    clearAllSessions,
    appendUserMessage,
    startAssistantMessage,
    appendToken,
    finaliseAssistantMessage,
    setAssistantMessageContent,
  } = useChatSessions();

  // ----------------------------------------------------------------
  // Streaming
  // ----------------------------------------------------------------
  const { isStreaming, isThinking, sendMessage, stopStreaming } = useChatStream({
    activeSession,
    activeSessionId,
    appendUserMessage,
    startAssistantMessage,
    appendToken,
    finaliseAssistantMessage,
    setAssistantMessageContent,
  });

  // ----------------------------------------------------------------
  // Send handler — ensure there's an active session first
  // ----------------------------------------------------------------
  const handleSend = useCallback(() => {
    if (!inputValue.trim()) return;

    let sessionId = activeSessionId;
    if (!sessionId) {
      sessionId = createSession();
    }

    const text = inputValue;
    setInputValue('');
    sendMessage(text);
  }, [inputValue, activeSessionId, createSession, sendMessage]);

  // ----------------------------------------------------------------
  // Example prompt clicked on empty state
  // ----------------------------------------------------------------
  const handlePrompt = useCallback(
    (promptText) => {
      // Always create a new session for example prompts
      createSession();
      setInputValue(promptText);
    },
    [createSession]
  );

  // ----------------------------------------------------------------
  // New chat
  // ----------------------------------------------------------------
  const handleNewChat = useCallback(() => {
    createSession();
    setInputValue('');
    // Auto-close sidebar on mobile after selecting
    if (window.innerWidth <= 768) setSidebarCollapsed(true);
  }, [createSession]);

  // ----------------------------------------------------------------
  // Switch session
  // ----------------------------------------------------------------
  const handleSwitch = useCallback(
    (id) => {
      switchSession(id);
      setInputValue('');
      if (window.innerWidth <= 768) setSidebarCollapsed(true);
    },
    [switchSession]
  );

  return (
    <div className="app">
      {/* Mobile hamburger toggle */}
      <button
        className="sidebar-toggle"
        onClick={() => setSidebarCollapsed((c) => !c)}
        title={sidebarCollapsed ? 'Open sidebar' : 'Close sidebar'}
        id="sidebar-toggle-btn"
      >
        <MenuIcon />
      </button>

      {/* Mobile overlay — clicking it closes the sidebar */}
      {!sidebarCollapsed && (
        <div
          className="sidebar-overlay visible"
          onClick={() => setSidebarCollapsed(true)}
        />
      )}

      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        collapsed={sidebarCollapsed}
        onNewChat={handleNewChat}
        onSwitch={handleSwitch}
        onDelete={deleteSession}
        onRename={renameSession}
        onClearAll={clearAllSessions}
      />

      <ChatWindow
        session={activeSession}
        isStreaming={isStreaming}
        isThinking={isThinking}
        inputValue={inputValue}
        onInputChange={setInputValue}
        onSend={handleSend}
        onStop={stopStreaming}
        onPrompt={handlePrompt}
      />
    </div>
  );
}
