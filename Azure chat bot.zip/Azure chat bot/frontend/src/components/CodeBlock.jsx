/**
 * CodeBlock.jsx
 *
 * Renders a fenced code block with:
 *   - Language label in the header
 *   - Syntax highlighting (react-syntax-highlighter / Prism)
 *   - "Copy" button with clipboard API
 */

import { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

// Clipboard icon
const CopyIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
    <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" />
  </svg>
);

const CheckIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

export function CodeBlock({ language = 'text', children }) {
  const [copied, setCopied] = useState(false);

  const code = String(children).replace(/\n$/, '');

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for browsers without clipboard API
      const el = document.createElement('textarea');
      el.value = code;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="code-block">
      <div className="code-block-header">
        <span className="code-language">{language || 'text'}</span>
        <button
          className={`copy-code-btn ${copied ? 'copied' : ''}`}
          onClick={handleCopy}
          title="Copy code"
          id={`copy-btn-${Math.random().toString(36).slice(2, 8)}`}
        >
          {copied ? <CheckIcon /> : <CopyIcon />}
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
      <SyntaxHighlighter
        language={language}
        style={vscDarkPlus}
        customStyle={{
          margin: 0,
          borderRadius: 0,
          background: 'var(--bg-code)',
        }}
        showLineNumbers={code.split('\n').length > 4}
        lineNumberStyle={{ color: '#4a4a60', fontSize: '11px', minWidth: '2.5em' }}
        PreTag="div"
      >
        {code}
      </SyntaxHighlighter>
    </div>
  );
}
