/**
 * ChatWindow.jsx
 *
 * The right panel: message list + empty state + typing indicator.
 * Auto-scrolls to bottom on new messages.
 * Shows a "scroll to bottom" button when user has scrolled up.
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { MessageBubble } from './MessageBubble';
import { MessageInput } from './MessageInput';

/* ------------------------------------------------------------------ */
/* Empty State                                                          */
/* ------------------------------------------------------------------ */
const EXAMPLE_PROMPTS = [
  { icon: '🐛', label: 'Fix a Python TypeError', text: 'Why am I getting a TypeError in this Python code? ' },
  { icon: '🔍', label: 'Write binary search in Java', text: 'Write a binary search function in Java with comments.' },
  { icon: '🔬', label: 'Explain a regex pattern', text: 'Explain what this regex does: ^(?=.*[A-Z])(?=.*\\d).{8,}$' },
  { icon: '⚡', label: 'Optimise a SQL query', text: 'How can I optimise this slow SQL query? ' },
  { icon: '🎯', label: 'Debug a React useEffect', text: 'My React useEffect keeps causing an infinite loop. Here is the code: ' },
  { icon: '📝', label: 'Generate unit tests', text: 'Generate unit tests for this Python function: ' },
];

function EmptyState({ onPrompt }) {
  return (
    <div className="empty-state">
      <div className="empty-state-logo">
        <div className="logo-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9eff" strokeWidth="1.5">
            <polyline points="16 18 22 12 16 6" />
            <polyline points="8 6 2 12 8 18" />
          </svg>
        </div>
        <h1>CodeChat</h1>
      </div>

      <p className="empty-state-subtitle">
        Your AI coding assistant for debugging, code generation, and explanation.
        Ask anything — paste code, describe a bug, or pick an example below.
      </p>

      <div className="example-prompts">
        {EXAMPLE_PROMPTS.map((p) => (
          <button
            key={p.label}
            className="example-prompt-btn"
            onClick={() => onPrompt(p.text)}
            id={`example-prompt-${p.label.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <span className="example-prompt-icon">{p.icon}</span>
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Typing Indicator                                                     */
/* ------------------------------------------------------------------ */
function TypingIndicator({ isThinking }) {
  return (
    <div className="typing-indicator">
      <div className="typing-dots">
        <div className="typing-dot" />
        <div className="typing-dot" />
        <div className="typing-dot" />
      </div>
      <span>{isThinking ? 'Thinking…' : 'Responding…'}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Scroll-to-bottom button icon                                         */
/* ------------------------------------------------------------------ */
const ChevronDownIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* ChatWindow                                                           */
/* ------------------------------------------------------------------ */
export function ChatWindow({
  session,
  isStreaming,
  isThinking,
  inputValue,
  onInputChange,
  onSend,
  onStop,
  onPrompt,
}) {
  const bottomRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);

  const messages = session?.messages ?? [];
  const hasMessages = messages.length > 0;

  // Auto-scroll on new content
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isStreaming]);

  // Also scroll during streaming (token append)
  const lastMsgContent = messages[messages.length - 1]?.content ?? '';
  useEffect(() => {
    if (isStreaming) {
      bottomRef.current?.scrollIntoView({ behavior: 'instant' });
    }
  }, [lastMsgContent, isStreaming]);

  // Show/hide scroll button
  const handleScroll = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollBtn(distanceFromBottom > 200);
  }, []);

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="chat-window">
      {/* Header */}
      <div className="chat-header">
        <span className="chat-header-title">
          {session ? session.title : 'CodeChat'}
        </span>
      </div>

      {/* Message list OR empty state */}
      {hasMessages ? (
        <div
          className="message-list"
          ref={scrollContainerRef}
          onScroll={handleScroll}
        >
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}

          {/* Typing indicator shown only when streaming starts (before first token)
              or during active streaming before content starts */}
          {(isStreaming && isThinking) && (
            <TypingIndicator isThinking={isThinking} />
          )}

          <div ref={bottomRef} style={{ height: '1px' }} />
        </div>
      ) : (
        <EmptyState onPrompt={onPrompt} />
      )}

      {/* Scroll-to-bottom button */}
      {showScrollBtn && hasMessages && (
        <button
          className="scroll-bottom-btn"
          onClick={scrollToBottom}
          title="Scroll to bottom"
          id="scroll-to-bottom-btn"
        >
          <ChevronDownIcon />
        </button>
      )}

      {/* Input */}
      <MessageInput
        value={inputValue}
        onChange={onInputChange}
        onSend={onSend}
        onStop={onStop}
        isStreaming={isStreaming}
        disabled={!session}
      />
    </div>
  );
}
