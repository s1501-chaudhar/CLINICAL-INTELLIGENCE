/**
 * MessageInput.jsx
 *
 * Auto-growing textarea at the bottom of the chat window.
 *   - Enter → send
 *   - Shift+Enter → newline
 *   - Send button (disabled while streaming)
 *   - Stop button (visible while streaming)
 */

import { useRef, useEffect, useCallback } from 'react';

const SendIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="22" y1="2" x2="11" y2="13" />
    <polygon points="22 2 15 22 11 13 2 9 22 2" />
  </svg>
);

const StopIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
    <rect x="4" y="4" width="16" height="16" rx="2" />
  </svg>
);

export function MessageInput({ value, onChange, onSend, onStop, isStreaming, disabled }) {
  const textareaRef = useRef(null);

  // Auto-grow the textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 200) + 'px';
  }, [value]);

  // Focus on mount
  useEffect(() => {
    textareaRef.current?.focus();
  }, []);

  const handleKeyDown = useCallback(
    (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!isStreaming && value.trim()) onSend();
      }
    },
    [isStreaming, value, onSend]
  );

  const canSend = !isStreaming && !disabled && value.trim().length > 0;

  return (
    <div className="input-area">
      <div className="input-wrapper">
        <textarea
          ref={textareaRef}
          id="message-input"
          className="message-textarea"
          placeholder="Ask about a bug or paste your code…"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          rows={1}
          aria-label="Chat message input"
        />
        {isStreaming ? (
          <button
            className="stop-btn"
            onClick={onStop}
            title="Stop generating"
            id="stop-generating-btn"
          >
            <StopIcon />
          </button>
        ) : (
          <button
            className="send-btn"
            onClick={onSend}
            disabled={!canSend}
            title="Send message"
            id="send-message-btn"
          >
            <SendIcon />
          </button>
        )}
      </div>
      <p className="input-hint">
        {isStreaming
          ? 'AI is responding… click ■ to stop.'
          : 'Enter to send · Shift+Enter for newline'}
      </p>
    </div>
  );
}
