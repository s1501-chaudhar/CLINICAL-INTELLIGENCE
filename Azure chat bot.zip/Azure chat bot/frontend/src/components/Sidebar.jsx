/**
 * Sidebar.jsx
 *
 * Left panel with:
 *   - "+ New Chat" button
 *   - Scrollable session list (grouped by date: Today / Yesterday / Older)
 *     - Title, relative timestamp
 *     - Hover: delete button (with confirmation) + rename (double-click)
 *   - "Clear all history" footer (with confirmation)
 *   - Collapsible via `collapsed` prop
 */

import { useState, useRef, useEffect, useCallback } from 'react';

/* ------------------------------------------------------------------ */
/* Relative time                                                        */
/* ------------------------------------------------------------------ */
const relativeTime = (isoString) => {
  const diff = (Date.now() - new Date(isoString)) / 1000; // seconds
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 172800) return '1d ago';
  return `${Math.floor(diff / 86400)}d ago`;
};

/* ------------------------------------------------------------------ */
/* Date grouping                                                        */
/* ------------------------------------------------------------------ */
const groupByDate = (sessions) => {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterdayStart = new Date(todayStart);
  yesterdayStart.setDate(todayStart.getDate() - 1);

  const groups = { Today: [], Yesterday: [], Older: [] };
  for (const s of sessions) {
    const d = new Date(s.updatedAt);
    if (d >= todayStart) groups.Today.push(s);
    else if (d >= yesterdayStart) groups.Yesterday.push(s);
    else groups.Older.push(s);
  }
  return groups;
};

/* ------------------------------------------------------------------ */
/* Icons                                                               */
/* ------------------------------------------------------------------ */
const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);
const TrashIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6l-1 14H6L5 6" />
    <path d="M10 11v6M14 11v6" />
    <path d="M9 6V4h6v2" />
  </svg>
);
const EditIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
  </svg>
);
const ClearIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6l-1 14H6L5 6M10 11v6M14 11v6M9 6V4h6v2" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Confirmation dialog                                                  */
/* ------------------------------------------------------------------ */
function ConfirmDialog({ title, message, onConfirm, onCancel }) {
  return (
    <div className="confirm-overlay" onClick={onCancel}>
      <div className="confirm-dialog" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        <p>{message}</p>
        <div className="confirm-actions">
          <button className="btn-cancel" onClick={onCancel} id="confirm-cancel-btn">Cancel</button>
          <button className="btn-confirm-danger" onClick={onConfirm} id="confirm-delete-btn">Delete</button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Session item                                                         */
/* ------------------------------------------------------------------ */
function SessionItem({ session, isActive, onSwitch, onDelete, onRename }) {
  const [renaming, setRenaming] = useState(false);
  const [renameValue, setRenameValue] = useState(session.title);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const renameInputRef = useRef(null);

  useEffect(() => {
    if (renaming) renameInputRef.current?.focus();
  }, [renaming]);

  const commitRename = () => {
    onRename(session.id, renameValue || session.title);
    setRenaming(false);
  };

  return (
    <>
      <div
        className={`session-item ${isActive ? 'active' : ''}`}
        onClick={() => !renaming && onSwitch(session.id)}
        onDoubleClick={() => { setRenameValue(session.title); setRenaming(true); }}
        title={session.title}
        id={`session-${session.id}`}
      >
        <div className="session-item-content">
          {renaming ? (
            <input
              ref={renameInputRef}
              className="session-rename-input"
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onBlur={commitRename}
              onKeyDown={(e) => {
                if (e.key === 'Enter') commitRename();
                if (e.key === 'Escape') setRenaming(false);
              }}
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <div className="session-title-row">
              <span className="session-title">{session.title}</span>
            </div>
          )}
          <div className="session-time">{relativeTime(session.updatedAt)}</div>
        </div>

        {!renaming && (
          <div className="session-actions">
            <button
              className="session-action-btn"
              title="Rename"
              id={`rename-session-${session.id}`}
              onClick={(e) => {
                e.stopPropagation();
                setRenameValue(session.title);
                setRenaming(true);
              }}
            >
              <EditIcon />
            </button>
            <button
              className="session-action-btn delete"
              title="Delete"
              id={`delete-session-${session.id}`}
              onClick={(e) => {
                e.stopPropagation();
                setConfirmDelete(true);
              }}
            >
              <TrashIcon />
            </button>
          </div>
        )}
      </div>

      {confirmDelete && (
        <ConfirmDialog
          title="Delete this chat?"
          message={`"${session.title}" will be permanently deleted.`}
          onConfirm={() => { setConfirmDelete(false); onDelete(session.id); }}
          onCancel={() => setConfirmDelete(false)}
        />
      )}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Main Sidebar component                                               */
/* ------------------------------------------------------------------ */
export function Sidebar({
  sessions,
  activeSessionId,
  collapsed,
  onNewChat,
  onSwitch,
  onDelete,
  onRename,
  onClearAll,
}) {
  const [confirmClear, setConfirmClear] = useState(false);
  const groups = groupByDate(sessions);

  return (
    <>
      <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
        {/* Header */}
        <div className="sidebar-header">
          <button className="btn-new-chat" onClick={onNewChat} id="new-chat-btn">
            <PlusIcon /> New Chat
          </button>
        </div>

        {/* Session list */}
        <div className="sidebar-sessions">
          {sessions.length === 0 && (
            <p style={{ color: 'var(--text-muted)', fontSize: '12px', padding: '16px 8px' }}>
              No chats yet. Start one above!
            </p>
          )}

          {Object.entries(groups).map(([label, group]) =>
            group.length === 0 ? null : (
              <div key={label}>
                <div className="session-group-label">{label}</div>
                {group.map((s) => (
                  <SessionItem
                    key={s.id}
                    session={s}
                    isActive={s.id === activeSessionId}
                    onSwitch={onSwitch}
                    onDelete={onDelete}
                    onRename={onRename}
                  />
                ))}
              </div>
            )
          )}
        </div>

        {/* Footer */}
        {sessions.length > 0 && (
          <div className="sidebar-footer">
            <button
              className="btn-clear-history"
              onClick={() => setConfirmClear(true)}
              id="clear-history-btn"
            >
              <ClearIcon /> Clear all history
            </button>
          </div>
        )}
      </aside>

      {/* Clear All confirmation */}
      {confirmClear && (
        <ConfirmDialog
          title="Clear all chat history?"
          message="All chat sessions will be permanently deleted. This cannot be undone."
          onConfirm={() => { setConfirmClear(false); onClearAll(); }}
          onCancel={() => setConfirmClear(false)}
        />
      )}
    </>
  );
}
