/**
 * MessageBubble.jsx
 *
 * Renders a single chat message.
 *   - User messages: right-aligned blue bubble
 *   - Assistant messages: left-aligned, full markdown rendering with
 *     code blocks delegated to <CodeBlock>
 *   - Error messages: styled in red
 */

import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { CodeBlock } from './CodeBlock';

const formatTime = (iso) => {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

// Custom components passed to react-markdown
const markdownComponents = {
  code({ node, inline, className, children, ...props }) {
    const match = /language-(\w+)/.exec(className || '');
    const lang = match ? match[1] : '';

    if (inline) {
      // Inline code — styled via CSS, not SyntaxHighlighter
      return <code className={className} {...props}>{children}</code>;
    }

    return <CodeBlock language={lang}>{children}</CodeBlock>;
  },
  // Open links in new tab
  a({ href, children }) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    );
  },
};

export function MessageBubble({ message }) {
  const { role, content, timestamp, error, streaming } = message;
  const isUser = role === 'user';

  return (
    <div className={`message-wrapper ${isUser ? 'user' : 'assistant'}`}>
      {isUser ? (
        <div className="message-bubble">
          <span style={{ whiteSpace: 'pre-wrap' }}>{content}</span>
        </div>
      ) : (
        <div className={`message-bubble ${error ? 'error' : ''}`}>
          <div className="assistant-content">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={markdownComponents}
            >
              {content || (streaming ? '' : '​')}
            </ReactMarkdown>
          </div>
        </div>
      )}
      {timestamp && (
        <div className="message-meta">{formatTime(timestamp)}</div>
      )}
    </div>
  );
}
