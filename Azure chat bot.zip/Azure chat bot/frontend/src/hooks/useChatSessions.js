/**
 * useChatSessions.js
 *
 * All session state + localStorage persistence lives here.
 * This hook is the single source of truth for:
 *   - The list of chat sessions
 *   - The currently active session ID
 *   - CRUD: create, switch, delete, rename sessions
 *   - Appending / updating messages within a session
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';

const SESSIONS_KEY = 'chatSessions';
const ACTIVE_ID_KEY = 'activeSessionId';

/* ------------------------------------------------------------------ */
/* Local-storage helpers                                                */
/* ------------------------------------------------------------------ */
const loadSessions = () => {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

const loadActiveId = () => {
  try {
    return localStorage.getItem(ACTIVE_ID_KEY) || null;
  } catch {
    return null;
  }
};

const saveSessions = (sessions) => {
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  } catch (e) {
    console.warn('Could not persist sessions to localStorage:', e);
  }
};

const saveActiveId = (id) => {
  try {
    if (id) localStorage.setItem(ACTIVE_ID_KEY, id);
    else localStorage.removeItem(ACTIVE_ID_KEY);
  } catch { /* ignore */ }
};

/* ------------------------------------------------------------------ */
/* Title helper — first 40 chars of the first user message             */
/* ------------------------------------------------------------------ */
const deriveTitle = (content) => {
  const trimmed = content.trim().replace(/\n+/g, ' ');
  return trimmed.length > 40 ? trimmed.slice(0, 40) + '…' : trimmed;
};

/* ------------------------------------------------------------------ */
/* Hook                                                                 */
/* ------------------------------------------------------------------ */
export function useChatSessions() {
  const [sessions, setSessions] = useState(() => loadSessions());
  const [activeSessionId, setActiveSessionIdState] = useState(
    () => loadActiveId()
  );

  // Keep a stable ref so callbacks don't stale-close over old state
  const sessionsRef = useRef(sessions);
  sessionsRef.current = sessions;

  // Validate that stored activeId still exists; fall back to newest session
  useEffect(() => {
    const exists = sessions.some((s) => s.id === activeSessionId);
    if (!exists) {
      const newest = sessions[0]?.id ?? null;
      setActiveSessionIdState(newest);
      saveActiveId(newest);
    }
  }, []); // only on mount

  /* -- internal write helper -- */
  const commit = useCallback((nextSessions) => {
    setSessions(nextSessions);
    sessionsRef.current = nextSessions;
    saveSessions(nextSessions);
  }, []);

  const setActiveId = useCallback((id) => {
    setActiveSessionIdState(id);
    saveActiveId(id);
  }, []);

  /* ---------------------------------------------------------------- */
  /* Computed: active session object                                   */
  /* ---------------------------------------------------------------- */
  const activeSession = sessions.find((s) => s.id === activeSessionId) ?? null;

  /* ---------------------------------------------------------------- */
  /* Create a new empty session                                        */
  /* ---------------------------------------------------------------- */
  const createSession = useCallback(() => {
    const newSession = {
      id: uuidv4(),
      title: 'New Chat',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    const next = [newSession, ...sessionsRef.current];
    commit(next);
    setActiveId(newSession.id);
    return newSession.id;
  }, [commit, setActiveId]);

  /* ---------------------------------------------------------------- */
  /* Switch to a session                                               */
  /* ---------------------------------------------------------------- */
  const switchSession = useCallback(
    (id) => {
      if (sessionsRef.current.some((s) => s.id === id)) {
        setActiveId(id);
      }
    },
    [setActiveId]
  );

  /* ---------------------------------------------------------------- */
  /* Delete a session                                                  */
  /* ---------------------------------------------------------------- */
  const deleteSession = useCallback(
    (id) => {
      const next = sessionsRef.current.filter((s) => s.id !== id);
      commit(next);

      if (activeSessionId === id) {
        const fallback = next[0]?.id ?? null;
        setActiveId(fallback);
      }
    },
    [activeSessionId, commit, setActiveId]
  );

  /* ---------------------------------------------------------------- */
  /* Rename a session                                                  */
  /* ---------------------------------------------------------------- */
  const renameSession = useCallback(
    (id, newTitle) => {
      const next = sessionsRef.current.map((s) =>
        s.id === id ? { ...s, title: newTitle.trim() || 'Chat' } : s
      );
      commit(next);
    },
    [commit]
  );

  /* ---------------------------------------------------------------- */
  /* Clear all sessions                                                */
  /* ---------------------------------------------------------------- */
  const clearAllSessions = useCallback(() => {
    commit([]);
    setActiveId(null);
  }, [commit, setActiveId]);

  /* ---------------------------------------------------------------- */
  /* Append a user message (optimistic) and return a placeholder ID    */
  /* for the assistant message that will be streamed in next           */
  /* ---------------------------------------------------------------- */
  const appendUserMessage = useCallback(
    (sessionId, content) => {
      const userMsg = {
        id: uuidv4(),
        role: 'user',
        content,
        timestamp: new Date().toISOString(),
      };

      let isFirstMessage = false;

      const next = sessionsRef.current.map((s) => {
        if (s.id !== sessionId) return s;
        isFirstMessage = s.messages.length === 0;
        return {
          ...s,
          updatedAt: new Date().toISOString(),
          title:
            isFirstMessage ? deriveTitle(content) : s.title,
          messages: [...s.messages, userMsg],
        };
      });

      commit(next);
      return userMsg.id;
    },
    [commit]
  );

  /* ---------------------------------------------------------------- */
  /* Start an assistant message placeholder (empty, streaming)         */
  /* Returns the new assistant message ID                              */
  /* ---------------------------------------------------------------- */
  const startAssistantMessage = useCallback(
    (sessionId) => {
      const assistantMsg = {
        id: uuidv4(),
        role: 'assistant',
        content: '',
        timestamp: new Date().toISOString(),
        streaming: true,
      };

      const next = sessionsRef.current.map((s) => {
        if (s.id !== sessionId) return s;
        return {
          ...s,
          updatedAt: new Date().toISOString(),
          messages: [...s.messages, assistantMsg],
        };
      });

      commit(next);
      return assistantMsg.id;
    },
    [commit]
  );

  /* ---------------------------------------------------------------- */
  /* Append a token to a streaming assistant message                   */
  /* ---------------------------------------------------------------- */
  const appendToken = useCallback(
    (sessionId, messageId, token) => {
      const next = sessionsRef.current.map((s) => {
        if (s.id !== sessionId) return s;
        return {
          ...s,
          messages: s.messages.map((m) =>
            m.id === messageId
              ? { ...m, content: m.content + token }
              : m
          ),
        };
      });
      // Don't call commit() here — that would flood localStorage with
      // one write per token. We write in bulk on finalise.
      setSessions(next);
      sessionsRef.current = next;
    },
    []
  );

  /* ---------------------------------------------------------------- */
  /* Finalise a streamed message (mark streaming:false, persist)       */
  /* ---------------------------------------------------------------- */
  const finaliseAssistantMessage = useCallback(
    (sessionId, messageId) => {
      const next = sessionsRef.current.map((s) => {
        if (s.id !== sessionId) return s;
        return {
          ...s,
          messages: s.messages.map((m) =>
            m.id === messageId ? { ...m, streaming: false } : m
          ),
        };
      });
      commit(next);
    },
    [commit]
  );

  /* ---------------------------------------------------------------- */
  /* Replace the last assistant message content (error or full text)   */
  /* ---------------------------------------------------------------- */
  const setAssistantMessageContent = useCallback(
    (sessionId, messageId, content, isError = false) => {
      const next = sessionsRef.current.map((s) => {
        if (s.id !== sessionId) return s;
        return {
          ...s,
          messages: s.messages.map((m) =>
            m.id === messageId
              ? { ...m, content, streaming: false, error: isError }
              : m
          ),
        };
      });
      commit(next);
    },
    [commit]
  );

  return {
    sessions,
    activeSessionId,
    activeSession,
    createSession,
    switchSession,
    deleteSession,
    renameSession,
    clearAllSessions,
    appendUserMessage,
    startAssistantMessage,
    appendToken,
    finaliseAssistantMessage,
    setAssistantMessageContent,
  };
}
