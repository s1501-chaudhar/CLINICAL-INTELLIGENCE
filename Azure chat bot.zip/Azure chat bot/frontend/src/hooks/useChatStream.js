/**
 * useChatStream.js
 *
 * Handles the streaming SSE fetch to POST /api/chat.
 * Uses the AbortController API so the user can stop generation mid-stream.
 *
 * Usage:
 *   const { isStreaming, sendMessage, stopStreaming } = useChatStream({
 *     activeSession,
 *     activeSessionId,
 *     appendUserMessage,
 *     startAssistantMessage,
 *     appendToken,
 *     finaliseAssistantMessage,
 *     setAssistantMessageContent,
 *   });
 */

import { useState, useRef, useCallback } from 'react';

export function useChatStream({
  activeSession,
  activeSessionId,
  appendUserMessage,
  startAssistantMessage,
  appendToken,
  finaliseAssistantMessage,
  setAssistantMessageContent,
}) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [isThinking, setIsThinking] = useState(false);  // waiting for first token
  const abortControllerRef = useRef(null);

  const stopStreaming = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  const sendMessage = useCallback(
    async (userContent) => {
      if (!activeSessionId || !userContent.trim()) return;
      if (isStreaming) return;

      // 1. Optimistically add the user message to the session.
      appendUserMessage(activeSessionId, userContent.trim());

      // 2. Build the messages array to send (existing history + new user msg).
      //    We read from activeSession.messages *before* we appended (the hook
      //    call above updates React state asynchronously, so we build manually).
      const historyMessages = activeSession?.messages ?? [];
      const apiMessages = [
        ...historyMessages.map((m) => ({ role: m.role, content: m.content })),
        { role: 'user', content: userContent.trim() },
      ];

      // 3. Start an empty assistant message placeholder.
      const assistantMsgId = startAssistantMessage(activeSessionId);

      // 4. Kick off the stream.
      setIsStreaming(true);
      setIsThinking(true);

      const controller = new AbortController();
      abortControllerRef.current = controller;

      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: apiMessages }),
          signal: controller.signal,
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData?.detail || `HTTP ${response.status}`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        // eslint-disable-next-line no-constant-condition
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });

          // SSE lines are separated by double newlines; process complete events.
          const parts = buffer.split('\n\n');
          buffer = parts.pop() ?? ''; // keep the incomplete chunk

          for (const part of parts) {
            const line = part.trim();
            if (!line.startsWith('data:')) continue;

            const jsonStr = line.slice('data:'.length).trim();
            let parsed;
            try {
              parsed = JSON.parse(jsonStr);
            } catch {
              continue; // skip malformed lines
            }

            if (parsed.error) {
              setAssistantMessageContent(
                activeSessionId,
                assistantMsgId,
                `⚠️ ${parsed.error}`,
                true
              );
              setIsStreaming(false);
              setIsThinking(false);
              return;
            }

            if (parsed.done) break;

            if (parsed.token) {
              setIsThinking(false); // first token arrived
              appendToken(activeSessionId, assistantMsgId, parsed.token);
            }
          }
        }

        // 5. Mark the message as fully received.
        finaliseAssistantMessage(activeSessionId, assistantMsgId);
      } catch (err) {
        if (err.name === 'AbortError') {
          // User clicked "Stop generating" — finalise with whatever came in
          finaliseAssistantMessage(activeSessionId, assistantMsgId);
        } else {
          console.error('Stream error:', err);
          setAssistantMessageContent(
            activeSessionId,
            assistantMsgId,
            `⚠️ Failed to connect to the server. Make sure the backend is running on port 8000.\n\nError: ${err.message}`,
            true
          );
        }
      } finally {
        setIsStreaming(false);
        setIsThinking(false);
        abortControllerRef.current = null;
      }
    },
    [
      activeSession,
      activeSessionId,
      isStreaming,
      appendUserMessage,
      startAssistantMessage,
      appendToken,
      finaliseAssistantMessage,
      setAssistantMessageContent,
    ]
  );

  return { isStreaming, isThinking, sendMessage, stopStreaming };
}
