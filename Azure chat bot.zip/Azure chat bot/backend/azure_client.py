"""
Azure OpenAI client module.

Reads credentials from environment variables (via .env) and exposes
`stream_chat_completion`, an async generator that yields text tokens
one at a time from the Azure OpenAI streaming API.
"""

import os
import asyncio
from typing import List, Dict, AsyncIterator

from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Custom exception
# ---------------------------------------------------------------------------

class AzureClientError(Exception):
    """Raised when the Azure OpenAI API returns an error."""


# ---------------------------------------------------------------------------
# Client initialisation
# ---------------------------------------------------------------------------

def _build_client() -> AzureOpenAI:
    """Create and return an AzureOpenAI client from environment variables."""
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")

    if not api_key:
        raise AzureClientError(
            "AZURE_OPENAI_API_KEY is not set. Please configure your .env file."
        )
    if not endpoint:
        raise AzureClientError(
            "AZURE_OPENAI_ENDPOINT is not set. Please configure your .env file."
        )

    return AzureOpenAI(
        api_key=api_key,
        azure_endpoint=endpoint,
        api_version=api_version,
    )


# Singleton client — initialised once at module load.
# If credentials are missing we raise early (caught by the endpoint handler).
try:
    _client = _build_client()
    _deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
except AzureClientError:
    _client = None  # type: ignore[assignment]
    _deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")


# ---------------------------------------------------------------------------
# Streaming generator
# ---------------------------------------------------------------------------

async def stream_chat_completion(
    messages: List[Dict[str, str]],
) -> AsyncIterator[str]:
    """
    Async generator that streams text tokens from Azure OpenAI.

    Parameters
    ----------
    messages:
        Full conversation history in OpenAI format, including the system prompt.

    Yields
    ------
    str — individual text tokens as they arrive from the API.

    Raises
    ------
    AzureClientError — on authentication, rate-limit, or API errors.
    """
    if _client is None:
        raise AzureClientError(
            "Azure OpenAI client could not be initialised. "
            "Check your AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT."
        )

    try:
        # The openai SDK's streaming is synchronous under the hood for AzureOpenAI,
        # so we run it in a thread pool to keep the FastAPI event loop free.
        loop = asyncio.get_event_loop()

        def _sync_stream():
            # Use max_completion_tokens to support newer reasoning models (e.g. o1/gpt-5-mini)
            # and avoid setting temperature as reasoning models restrict it.
            return _client.chat.completions.create(
                model=_deployment,
                messages=messages,  # type: ignore[arg-type]
                stream=True,
                max_completion_tokens=2048,
            )

        stream = await loop.run_in_executor(None, _sync_stream)

        for chunk in stream:
            if chunk.choices:
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    yield delta.content
                    # Yield control back to the event loop briefly so FastAPI
                    # can flush data to the client between chunks.
                    await asyncio.sleep(0)

    except Exception as exc:
        error_msg = str(exc)

        # Surface common Azure-specific errors with friendly messages.
        if "AuthenticationError" in type(exc).__name__ or "401" in error_msg:
            raise AzureClientError(
                "Authentication failed. Please check your AZURE_OPENAI_API_KEY."
            ) from exc
        elif "RateLimitError" in type(exc).__name__ or "429" in error_msg:
            raise AzureClientError(
                "Rate limit exceeded. Please wait a moment and try again."
            ) from exc
        elif "ContentFilterError" in type(exc).__name__ or "content_filter" in error_msg:
            raise AzureClientError(
                "Your request was blocked by the content filter. "
                "Please rephrase your message."
            ) from exc
        elif "DeploymentNotFound" in error_msg or "404" in error_msg:
            raise AzureClientError(
                f"Deployment '{_deployment}' not found. "
                "Check AZURE_OPENAI_DEPLOYMENT_NAME in your .env file."
            ) from exc
        else:
            raise AzureClientError(f"Azure OpenAI error: {error_msg}") from exc
