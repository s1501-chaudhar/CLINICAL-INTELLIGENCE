"""
FastAPI backend for the AI Code Assistant chatbot.
Exposes:
  GET  /api/health  — health check
  POST /api/chat    — streams Azure OpenAI completions via SSE
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List
import json
import logging

from azure_client import stream_chat_completion, AzureClientError

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = FastAPI(
    title="AI Code Assistant API",
    description="FastAPI backend that proxies streaming Azure OpenAI responses.",
    version="1.0.0",
)

# Allow both the Vite dev-server and any local port used during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# System prompt — defines the assistant's coding-focused persona
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = (
    "You are an expert coding assistant specialized in code generation, debugging, "
    "and code explanation. When the user shares code or describes a bug, analyze it "
    "carefully, identify root causes, and provide corrected code with brief "
    "explanations. Use markdown code blocks with language annotations for all code. "
    "Be concise but thorough. Ask clarifying questions if the user's request or "
    "error is ambiguous."
)

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class Message(BaseModel):
    role: str          # "user" | "assistant" | "system"
    content: str


class ChatRequest(BaseModel):
    messages: List[Message]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/health")
async def health_check():
    """Simple liveness probe."""
    return {"status": "ok", "service": "ai-code-assistant"}


@app.post("/api/chat")
async def chat(request: ChatRequest):
    """
    Accept the full message history for the current session, prepend the
    system prompt, and stream the Azure OpenAI response back as SSE.

    SSE format:
        data: {"token": "..."}\n\n   — for each streamed token
        data: {"done": true}\n\n     — when the stream ends
        data: {"error": "..."}\n\n   — on error
    """
    # Build the messages array: system prompt first, then the conversation.
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for msg in request.messages:
        messages.append({"role": msg.role, "content": msg.content})

    logger.info("Chat request received — %d messages in history", len(messages))

    async def event_generator():
        try:
            async for token in stream_chat_completion(messages):
                payload = json.dumps({"token": token})
                yield f"data: {payload}\n\n"

            # Signal the end of the stream
            yield f"data: {json.dumps({'done': True})}\n\n"

        except AzureClientError as exc:
            logger.error("Azure OpenAI error: %s", exc)
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"

        except Exception as exc:
            logger.error("Unexpected error during streaming: %s", exc)
            yield f"data: {json.dumps({'error': 'An unexpected server error occurred.'})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",   # Disable nginx buffering if behind a proxy
        },
    )
